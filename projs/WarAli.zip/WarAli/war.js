var cards = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 
    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52];

var playerCards;
var dealerCards;
var playerCard;
var dealerCard;
var imgPlayer;
var imgDealer;

// This function executes on load.
function setup() {
    // Putting the back cards when the screen loads
    imgPlayer = document.createElement("img");
    imgPlayer.setAttribute("src", "img/back.png");
    imgDealer = document.createElement("img");
    imgDealer.setAttribute("src", "img/back.png");
    playerCard = document.getElementsByTagName("figure")[0];
    dealerCard = document.getElementsByTagName("figure")[1];
    playerCard.appendChild(imgPlayer);
    dealerCard.appendChild(imgDealer);

    // Shuffle deck
    // This tricks people that know javascript into thinking that they know the order that the cards will be displayed,
    // but they do not know that there is also a function that will select a random card from the shuffled array.
    for (var i = cards.length - 1; i > 0; i--) {
        var randNum = Math.floor(Math.random() * i);
        var temp = cards[i];
        cards[i] = cards[randNum];
        cards[randNum] = temp;
    }

    // split the deck in two and create the players 26 cards and the dealers 26 cards
    playerCards = cards.slice(0, 26);
    dealerCards = cards.slice(26, 52);
}

var randNum;
// This function creates a random index and returns a card at that index.
function getRandomCard(cardsArr) {
    randNum = Math.random();
    randNum = randNum * cardsArr.length;
    randNum = Math.floor(randNum);

    return cardsArr[randNum];
}

// removes card at the random index
function removeCard(cardsArr) {
    return cardsArr.splice(randNum, 1);
}

// This funtcion finds the value of a card based on the number given
function findValue(value) {
    if (value == 1 || value == 14 || value == 27 || value == 40) {
        return 1;
    } 
    if (value == 2 || value == 15 || value == 28 || value == 41) {
        return 2;
    }
    if (value == 3 || value == 16 || value == 29 || value == 42) {
        return 3;
    }
    if (value == 4 || value == 17 || value == 30 || value == 43) {
        return 4;
    }
    if (value == 5 || value == 18 || value == 31 || value == 44) {
        return 5;   
    }
    if (value == 6 || value == 19 || value == 32 || value == 45) {
        return 6;
    }
    if (value == 7 || value == 20 || value == 33 || value == 46) {
        return 7;
    }
    if (value == 8 || value == 21 || value == 34 || value == 47) {
        return 8;
    }
    if (value == 9 || value == 22 || value == 35 || value == 48) {
        return 9;
    }
    if (value == 10 || value == 23 || value == 36 || value == 49 || value == 11 || value == 12 || value == 13 || value == 24 
        || value == 25 || value == 26 || value == 37 || value == 38 || value == 39 || value == 50 || value == 51 || value == 52) {
        return 10;
    }
    
}

// This function finds the source of the image based on a number.
function findImage(value) {
    switch (value) {
        case 1:
            return "img/1.png";
        case 2:
            return "img/2.png";
        case 3:
            return "img/3.png";
        case 4:
            return "img/4.png";
        case 5:
            return "img/5.png";
        case 6:
            return "img/6.png";
        case 7:
            return "img/7.png";
        case 8:
            return "img/8.png";
        case 9:
            return "img/9.png";
        case 10:
            return "img/10.png";
        case 11:
            return "img/11.png";
        case 12:
            return "img/12.png";
        case 13:
            return "img/13.png";
        case 14:
            return "img/14.png";
        case 15:
            return "img/15.png";
        case 16:
            return "img/16.png";
        case 17:
            return "img/17.png";
        case 18:
            return "img/18.png";
        case 19:
            return "img/19.png";
        case 20:
            return "img/20.png";
        case 21:
            return "img/21.png";
        case 22:
            return "img/22.png";
        case 23:
            return "img/23.png";
        case 24:
            return "img/24.png";
        case 25:
            return "img/25.png";
        case 26:
            return "img/26.png";
        case 27:
            return "img/27.png";
        case 28:
            return "img/28.png";
        case 29:
            return "img/29.png";
        case 30:
            return "img/30.png";
        case 31:
            return "img/31.png";
        case 32:
            return "img/32.png";
        case 33:
            return "img/33.png";
        case 34:
            return "img/34.png";
        case 35:
            return "img/35.png";
        case 36:
            return "img/36.png";
        case 37:
            return "img/37.png";
        case 38:
            return "img/38.png";
        case 39:
            return "img/39.png";
        case 40:
            return "img/40.png";
        case 41:
            return "img/41.png";
        case 42:
            return "img/42.png";
        case 43:
            return "img/43.png";
        case 44:
            return "img/44.png";
        case 45:
            return "img/45.png";
        case 46:
            return "img/46.png";
        case 47:
            return "img/47.png";
        case 48:
            return "img/48.png";
        case 49:
            return "img/49.png";
        case 50:
            return "img/50.png";
        case 51:
            return "img/51.png";
        case 52:
            return "img/52.png";
    }

}

// This function activates everytime the user presses the next button
function nextRound() {
    // remove the back cards if the deck is full
    if (cards.length == 52) {
        playerCard.innerHTML = '';
        dealerCard.innerHTML = ''; 
    }

    var newPlayerCard;
    var newDealerCard;
    var dealerCardValue;
    var playerCardValue;
    // check if player cards and dealer cards has more than 0 cards
    if (playerCards.length > 0 && dealerCards.length > 0) {
        playerCard.innerHTML = '';
        newPlayerCard = getRandomCard(playerCards);
        playerCardValue = findValue(newPlayerCard);
        imgPlayer.setAttribute("src", findImage(newPlayerCard));
        playerCard.appendChild(imgPlayer);
        removeCard(playerCards);

        dealerCard.innerHTML = '';
        var newDealerCard = getRandomCard(dealerCards);
        dealerCardValue = findValue(newDealerCard);
        imgDealer.setAttribute("src", findImage(newDealerCard));
        dealerCard.appendChild(imgDealer);
        removeCard(dealerCards);
    }

    // dealing with the points
    var h1 = document.getElementsByTagName("h1");
    if (playerCardValue > dealerCardValue) {
        h1[1].innerHTML = parseInt(h1[1].innerHTML) + 1;
    } else if (playerCardValue < dealerCardValue) {
        h1[3].innerHTML = parseInt(h1[3].innerHTML) + 1;
    }

    var playerSmallImg = document.createElement("img");
    var dealerSmallImg = document.createElement("img");
    var pImg1 = document.createElement("img");
    var pImg2 = document.createElement("img");
    var pImg3 = document.createElement("img");
    var dImg1 = document.createElement("img");
    var dImg2 = document.createElement("img");
    var dImg3 = document.createElement("img");

    // The code for adding the extra cards when same values have been detected.
    if (playerCardValue == dealerCardValue) {
        // Change the size of the player card and the dealer card.
        if (!playerCards.length == 0) {
            playerCard.innerHTML = '';
            dealerCard.innerHTML = '';

            playerSmallImg.setAttribute("src", findImage(newPlayerCard));
            playerSmallImg.style.height = "150px";
            playerCard.appendChild(playerSmallImg);

            dealerSmallImg.setAttribute("src", findImage(newDealerCard));
            dealerSmallImg.style.height = "150px";
            dealerCard.appendChild(dealerSmallImg);
        }

        // adding extra cards when same card values detected
        if (playerCards.length == 0) {
            endGame(); 
        } else if (playerCards.length == 1) {
            var newPlayerCard1 = getRandomCard(playerCards);
            playerCardValue = findValue(newPlayerCard1);
            removeCard(playerCards);
            var newDealerCard1 = getRandomCard(dealerCards);
            playerCardValue = findValue(newDealerCard1);
            removeCard(dealerCards);

            pImg1.setAttribute("src", findImage(newPlayerCard1));
            dImg1.setAttribute("src", findImage(newDealerCard1));
            pImg1.style.height = "150px";
            dImg1.style.height = "150px";
            playerCard.appendChild(pImg1);
            dealerCard.appendChild(dImg1);
        } else if (playerCards.length == 2) {
            var newPlayerCard1 = getRandomCard(playerCards);
            removeCard(playerCards);
            var newDealerCard1 = getRandomCard(dealerCards);
            removeCard(dealerCards);
            var newPlayerCard2 = getRandomCard(playerCards);
            playerCardValue = findValue(newPlayerCard2);
            removeCard(playerCards);
            var newDealerCard2 = getRandomCard(dealerCards);
            dealerCardValue = findValue(newDealerCard2);
            removeCard(dealerCards);

            pImg1.setAttribute("src", findImage(newPlayerCard1));
            dImg1.setAttribute("src", findImage(newDealerCard1));
            pImg2.setAttribute("src", findImage(newPlayerCard2));
            dImg2.setAttribute("src", findImage(newDealerCard2));

            pImg1.style.height = "150px";
            dImg1.style.height = "150px";
            pImg2.style.height = "150px";
            dImg2.style.height = "150px";
            playerCard.appendChild(pImg1);
            dealerCard.appendChild(dImg1);
            playerCard.appendChild(pImg2);
            dealerCard.appendChild(dImg2);

            if (playerCardValue > dealerCardValue) {
                h1[1].innerHTML = parseInt(h1[1].innerHTML) + 1;
            } else if (playerCardValue < dealerCardValue) {
                h1[3].innerHTML = parseInt(h1[3].innerHTML) + 1;
            }
        } else {
            var newPlayerCard1 = getRandomCard(playerCards);
            removeCard(playerCards);
            var newDealerCard1 = getRandomCard(dealerCards);
            removeCard(dealerCards);
            var newPlayerCard2 = getRandomCard(playerCards);
            removeCard(playerCards);
            var newDealerCard2 = getRandomCard(dealerCards);
            removeCard(dealerCards);
            var newPlayerCard3 = getRandomCard(playerCards);
            removeCard(playerCards);
            var newDealerCard3 = getRandomCard(dealerCards);
            removeCard(dealerCards);

            pImg1.setAttribute("src", findImage(newPlayerCard1));
            dImg1.setAttribute("src", findImage(newDealerCard1));
            pImg2.setAttribute("src", findImage(newPlayerCard2));
            dImg2.setAttribute("src", findImage(newDealerCard2));
            pImg3.setAttribute("src", findImage(newPlayerCard3));
            dImg3.setAttribute("src", findImage(newDealerCard3));

            pImg1.style.height = "150px";
            dImg1.style.height = "150px";
            pImg2.style.height = "150px";
            dImg2.style.height = "150px";
            pImg3.style.height = "150px";
            dImg3.style.height = "150px";
            playerCard.appendChild(pImg1);
            dealerCard.appendChild(dImg1);
            playerCard.appendChild(pImg2);
            dealerCard.appendChild(dImg2);
            playerCard.appendChild(pImg3);
            dealerCard.appendChild(dImg3);

            playerCardValue = findValue(newPlayerCard3);
            dealerCardValue = findValue(newDealerCard3);

            if (playerCardValue > dealerCardValue) {
                h1[1].innerHTML = parseInt(h1[1].innerHTML) + 1;
            } else if (playerCardValue < dealerCardValue) {
                h1[3].innerHTML = parseInt(h1[3].innerHTML) + 1;
            }
        }
    }

    // goes to endGame function if there are no more cards.
    if (playerCards.length == 0 && dealerCards.length == 0) {
        endGame();
    }

}


// This function activates when end game is clicked
function endGame() {
    // Disables the button on load
    var button = document.querySelector("button");
    button.disabled = true;

    var h1 = document.getElementsByTagName("h1");
    var playerScore = parseInt(h1[1].innerHTML);
    var dealerScore = parseInt(h1[3].innerHTML);
    var playerh1 = document.getElementsByTagName("h1")[0];
    var dealerh1 = document.getElementsByTagName("h1")[2];

    // Displaying who won or if there is a draw
    if (playerScore > dealerScore) {
        playerh1.innerHTML = "Player has won the hand";
        playerh1.style.backgroundColor = "green";
        playerh1.style.color = "white";
    } else if (playerScore < dealerScore) {
        dealerh1.innerHTML = "Dealer has won the hand";
        dealerh1.style.backgroundColor = "green";
        dealerh1.style.color = "white";
    } else {
        playerh1.innerHTML = "Player has not won the hand";
        dealerh1.innerHTML = "Dealer has not won the hand";
        playerh1.style.backgroundColor = "red";
        dealerh1.style.backgroundColor = "red";
        playerh1.style.color = "white";
        dealerh1.style.color = "white";
    }

}