import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthBar2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar2 extends Actor
{
    int health = 10;
    int healthWidth = 100;
    int healthHeight = 10;
    int pixelsPerHealth = (int) healthWidth/health;
    GreenfootSound bgMusic = new GreenfootSound ("music3.mp3");
    /**
     * Act - do whatever the HealthBar2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        healthUpdate();
        player1Win();   

    }    
    //The color and size of the healthbar.
    public void healthUpdate(){
        setImage(new GreenfootImage(healthWidth +2 , healthHeight + 2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.BLACK);
        myImage.drawRect(0, 0, healthWidth + 1, healthHeight + 1);
        myImage.setColor(Color.BLUE);
        myImage.fillRect(1, 1, health*pixelsPerHealth, healthHeight);
    }
    //returns the health 
    public int getHealth(){
        return health;
    }
    // reduce health by 1.
    public void loseHealth(){
        health--;
    }
    //gain health by 3.
    public void gainHealth(){
        health += 3;
    }
    //When the health reaches 0 it will move to the P1EndScreen.
    public void player1Win (){
        if (health == 0){
            P1EndScreen end1 = new P1EndScreen();
            Greenfoot.setWorld(end1);
        }
    }
}
