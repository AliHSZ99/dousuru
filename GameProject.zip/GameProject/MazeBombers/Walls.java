import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Walls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Walls extends Actor
{
    public int numberOfHits =0;
    /**
     * Act - do whatever the Walls wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {

    }    
    //Removes this when hit by the explosion.
    public void hitByExplosion(){
        Actor explosion = getOneIntersectingObject(Explosion.class);
        if  (explosion != null){
            getWorld().removeObject(this);
        }
    }
    //Destroy the wall when hit by the bullet.
      public void hitByBullet1(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        Actor bullet2 = getOneIntersectingObject(Bullet2.class);
        Actor explosion = getOneIntersectingObject(Explosion.class);
        if (bullet != null || bullet2 != null || explosion != null){
            setImage("MetalWall2.png");
            getWorld().removeObject(bullet);
            getWorld().removeObject(bullet2);
            Greenfoot.playSound("metalbullet.mp3");
            numberOfHits++;
            if  (numberOfHits == 2){
                getWorld().removeObject(this);
            }
        } 
        
    }
    //Destroy the wall when hit by the bullet.
     public void hitByBullet2(){
        Actor bullet = getOneIntersectingObject(Bullet.class);
        Actor bullet2 = getOneIntersectingObject(Bullet2.class);
        Actor explosion = getOneIntersectingObject(Explosion.class);
        if (bullet != null || bullet2 != null || explosion != null){
            setImage("RedWall2.png");
            getWorld().removeObject(bullet);
            getWorld().removeObject(bullet2);
            Greenfoot.playSound("metalbullet.mp3");
            numberOfHits++;
            if  (numberOfHits == 2){
                getWorld().removeObject(this);
            }
        } 
        
    }
    //Deflect the bullet or remove from the world.
    public void removeBullet(){
     Actor bullet = getOneIntersectingObject(Bullet.class);
     if (bullet != null){
        getWorld().removeObject(bullet);
        Greenfoot.playSound("normalbullet.mp3");
    }
    Actor bullet2 = getOneIntersectingObject(Bullet2.class);
     if (bullet2 != null){
        getWorld().removeObject(bullet2);
        Greenfoot.playSound("normalbullet.mp3");
    }
    }
}
