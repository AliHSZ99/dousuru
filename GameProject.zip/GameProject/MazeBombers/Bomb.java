import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bomb here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bomb extends Powerups
{
    public int time = 200; //Works as an explosion timer for the bomb.
    /**
     * Act - do whatever the Bomb wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        time--;
        Walls wall = (Walls) getOneIntersectingObject(Walls.class);
        Explosion explosion = new Explosion();
        int x = getX();
        int y = getY();
        if (time == 50){ //When the time reaches 50 it will the explosion class and removes the bomb from the world.
            getWorld().addObject(explosion, x, y);
            Greenfoot.playSound("bombbullet.mp3");
        }
        if  (time == 0){
            getWorld().removeObject(this);//remove this object when reaches 0.
            }
    }    

}
