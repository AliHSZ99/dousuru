import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MagmaWall here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MagmaWall extends Walls
{
    /**
     * Act - do whatever the MagmaWall wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        removeBullet();
    }    
}
