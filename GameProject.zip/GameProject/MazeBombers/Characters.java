import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Characters here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Characters extends Actor
{
    public boolean firing = true;
    private boolean shiftDown;
    private boolean spaceDown;
    private int rotation = 0;
    private int rotation2 = 0;
    private int speed = 1;
    /**
     * Act - do whatever the Characters wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {

    }
    
    //Controls for the player 2.
    public void Player2Keys(){
        moveAround2();
    }
    
    //Controls for the player 1.
    public void Player1Keys(){
        moveAround();
    }
    
    //Provide the movement and shooting control for the player 1.
    public void moveAround(){
        int x = getX();
        int y = getY();
        if (Greenfoot.isKeyDown("D")){
            setRotation(90);
            setLocation(x+speed, y);
            if (hittingWalls()){
                setLocation(x -2, y);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("A")){
            setRotation(-90);
            setLocation(x - speed, y); 
            if (hittingWalls()){
                setLocation(x + 2, y);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("W")){
            setRotation(0);
            setLocation(x, y - speed);
            if (hittingWalls()){
                setLocation(x , y + 2);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("S")){
            setRotation(180);
            setLocation(x, y+ speed);
            if (hittingWalls()){
                setLocation(x, y -2);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if  (!spaceDown &&"space".equals(Greenfoot.getKey())){
            shooting();
            spaceDown = true;
        } else if (spaceDown && !"space".equals(Greenfoot.getKey())){
            spaceDown = false;
        }
    }
    
    
    //Removes the speedup object from the world when it touches a player.
    public boolean hitSpeedUp(){
        SpeedUp speedUp =  (SpeedUp)getOneIntersectingObject(SpeedUp.class);
        if  (speedUp != null){
            getWorld().removeObject(speedUp);
            return true;
        } else {
            return false;
        }
    }
    
    //Code that prevent players pass through the walls.
    public boolean hittingWalls(){
        if  (isTouching(Walls.class)){
            return true;
        } else {
            return false;
        }       
    }
    
    //Code that allows the bullet to appear in the head of the character whenever it rotate.
    private void shooting(){
        rotation = getRotation();
        Bullet bullet = new Bullet();
        getWorld().addObject(bullet, getX(), getY());
        if (rotation == 90){
            bullet.setRotation(0);
        }else if (rotation == 0){
            bullet.setRotation(270);
        }else if (rotation == 180){
            bullet.setRotation(90);
        }else if (rotation == 270){
            bullet.setRotation(180);
        }  
        
    }
    
    //Provide the movement and shooting control for the player 2.
    public void moveAround2(){
        int x = getX();
        int y = getY();
        if (Greenfoot.isKeyDown("Right")){
            setRotation(90);
            setLocation(x+ speed, y);
            if (hittingWalls()){
                setLocation(x -2, y);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("Left")){
            setRotation(-90);
            setLocation(x-speed, y); 
            if (hittingWalls()){
                setLocation(x + 2, y);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("Up")){
            setRotation(0);
            setLocation(x, y -speed);
            if (hittingWalls()){
                setLocation(x , y + 2);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if (Greenfoot.isKeyDown("Down")){
            setRotation(180);
            setLocation(x, y+speed);
            if (hittingWalls()){
                setLocation(x, y -2);
                Greenfoot.playSound("bump.wav");
            }
            if ( hitSpeedUp()){
                speed++;
            }
        }
        if  (!shiftDown && Greenfoot.isKeyDown("shift")){
            shooting2();
            shiftDown = true;
        } else if (shiftDown && !Greenfoot.isKeyDown("shift")){
             shiftDown = false;
        }
    }
    
    //Code that allows the bullet to appear in the head of the character whenever it rotate.
    private void shooting2(){
        rotation2 = getRotation();
        Bullet2 bullet2 = new Bullet2();
        getWorld().addObject(bullet2, getX(), getY());
        if (rotation2 == 90){
            bullet2.setRotation(0);
        }else if (rotation2 == 0){
            bullet2.setRotation(270);
        }else if (rotation2 == 180){
            bullet2.setRotation(90);
        }else if (rotation2 == 270){
            bullet2.setRotation(180);
        }  
    }    
}