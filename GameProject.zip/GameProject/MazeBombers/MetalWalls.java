import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MetalWalls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MetalWalls extends Walls
{
    public int numberOfHits = 0;
   
    /**
     * Act - do whatever the MetalWalls wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        hitByBullet1();
    }
}