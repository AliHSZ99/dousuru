import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class P2EndScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class P2EndScreen extends World
{
    GreenfootSound myMusic = new GreenfootSound ("winningmusic.mp3");
    int time = 360;// Create a variable time and set it as an integer. This variable works as a timer on how long it will stay on the P2EndScreen.
    /**
     * Constructor for objects of class P2EndScreen.
     * 
     */
    public P2EndScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 800, 1);      
    }

    public void act (){
        myMusic.play();//Plays the music while in the P2Endscreen.
        time--;
        if (time == 0){//When the timer reaches 0, the screen will go back to main screen.
            StartScreenWorld s = new StartScreenWorld();
            Greenfoot.setWorld(s);
            myMusic.stop();
        }
    }
}
