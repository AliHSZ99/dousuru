import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class StartScreenWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StartScreenWorld extends World
{
    GreenfootSound myMusic = new GreenfootSound ("startmusic.mp3");
    /**
     * Constructor for objects of class StartScreenWorld.
     * 
     */
    public StartScreenWorld()
    {    
        super(800, 600, 1); 
    }
    public void act (){
        myMusic.play();
        if (Greenfoot.isKeyDown("C")){//When the user Pressses "C" it will switch the world to the ControlScreen.
            ControlScreen control = new ControlScreen();
            Greenfoot.setWorld(control);
            myMusic.stop();
        }
        if (Greenfoot.isKeyDown("space")){//When the user Pressses "Space" it will switch the world to the MapSelection Screen.
            MapSelectionWorld mapSelectionWorld = new MapSelectionWorld();
            Greenfoot.setWorld(mapSelectionWorld);
            myMusic.stop();
        }
    }
}
