import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.Color;
/**
 * Write a description of class HealthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar extends Actor
{
    int health = 10;
    int healthWidth = 100;
    int healthHeight = 10;
    int pixelsPerHealth = (int) healthWidth/health;
    static int points = 0;
    GreenfootSound bgMusic = new GreenfootSound ("music3.mp3");
    HealthBar2 healthBar2 = new HealthBar2();
    /**
     * Act - do whatever the HealthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public HealthBar(){
        healthUpdate();
    }
    //method that allow to get the health.
    public int getHealth(){
        return health;
    }

    public void act() 
    {
        healthUpdate();
        player2Win();
    } 

    public void setHealth(int newHealth){
        health = newHealth;
    }

    public int getPoints(){
        return points;
    }
    //the size and color of the healthbar.
    public void healthUpdate(){
        setImage(new GreenfootImage(healthWidth +2 , healthHeight + 2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.WHITE);
        myImage.drawRect(0, 0, healthWidth + 1, healthHeight + 1);
        myImage.setColor(Color.RED);
        myImage.fillRect(1, 1, health*pixelsPerHealth, healthHeight);
    }
    //reduce the health by 1.
    public void loseHealth(){
        health--;
    }
    //gain gain health by 1.
    public void gainHealth(){
        health += 3 ;
    }
    //When the health reaches 0, it will move to the player2EndScreen.
    public void player2Win (){
        if (health == 0){
            P2EndScreen end2 = new P2EndScreen();
            Greenfoot.setWorld(end2);
        }
    } 
}  

