import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    public int numberOfHits = 0;
    public boolean hit2times = false;
    /**
     * Act - do whatever the Bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        move(5); // moves the bullet with a speed of 5.

    }   

    public void removeFromWorld(){
        if (getY() == 0){
            getWorld().removeObject(this);
        }
    }    
}
