import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ControlScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ControlScreen extends World
{
    GreenfootSound myMusic = new GreenfootSound ("startmusic.mp3"); //Create the music for the Control Screen World 
    /**
     * Constructor for objects of class ControlScreen.
     * 
     */
    public ControlScreen()
    {    
        // Create a new world with 800x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        
    }
    
    //Plays the music until the user press "B" from the keyboard.
    public void act(){
        myMusic.play();
        if  (Greenfoot.isKeyDown("B")){
            StartScreenWorld start = new StartScreenWorld();// Create the StartScreenWorld 
            Greenfoot.setWorld(start);// Change the World from Control Screen Start Screen World when the user presses "B".
            myMusic.stop();
        }
    }
}
