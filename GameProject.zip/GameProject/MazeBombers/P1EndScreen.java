import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class P1EndScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class P1EndScreen extends World
{
    GreenfootSound myMusic = new GreenfootSound ("winningmusic.mp3");// Create a music.
    int time = 360;// Create a variable time and set it as an integer. This variable works as a timer on how long it will stay on the P1EndScreen.
    /**
     * Constructor for objects of class P1EndScreen.
     * 
     */
    public P1EndScreen()
    {    
        // Create a new world with 1000x800 cells with a cell size of 1x1 pixels.
        super(1000,800, 1); 
    }

    public void act (){        
        myMusic.play();//Plays the music while in the P2Endscreen.
        time--;
        if (time == 0){ //When the timer reaches 0, the screen will go back to main screen.
            StartScreenWorld s = new StartScreenWorld();
            Greenfoot.setWorld(s);
            myMusic.stop();
        }
    }
}
