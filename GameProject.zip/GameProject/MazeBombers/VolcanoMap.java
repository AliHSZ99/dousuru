import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class VolcanoMap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class VolcanoMap extends World
{
    HealthBar3 healthBar3 = new HealthBar3();
    HealthBar4 healthBar4 = new HealthBar4();
    GreenfootSound bgMusic = new GreenfootSound("music1.mp3");
    /**
     * Constructor for objects of class VolcanoMap.
     * 
     */
    public VolcanoMap()
    {    
        // Create a new world with 1000800 cells with a cell size of 1x1 pixels.
        super(1000, 800, 1); 
        prepare();

    }
    //Plays the music until one of the player reaches a health  of 1.
    public void act (){
        playMusic();
        if (healthBar3.getHealth() == 1 || healthBar4.getHealth() == 1){
            stopMusic();
        }
    }

    // play music
    public void playMusic (){
        bgMusic.play();
    }

    // stop music
    public void stopMusic (){
        bgMusic.stop(); 
    }
    //Get the healthbar class for the players.
    public HealthBar3 getHealthBar3(){
        return healthBar3;
    }
    //Get the healthbar class for the players.
    public HealthBar4 getHealthBar4(){
        return healthBar4;
    }


    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        setPaintOrder(HealthBar3.class,PlayerName1.class,PlayerName2.class,HealthBar4.class,Walls.class,Powerups.class);

        MagmaWall magmaWall = new MagmaWall();
        addObject(magmaWall,24,22);
        MagmaWall magmaWall2 = new MagmaWall();
        addObject(magmaWall2,24,71);
        MagmaWall magmaWall3 = new MagmaWall();
        addObject(magmaWall3,24,121);
        MagmaWall magmaWall4 = new MagmaWall();
        addObject(magmaWall4,25,171);
        MagmaWall magmaWall5 = new MagmaWall();
        addObject(magmaWall5,24,221);
        MagmaWall magmaWall6 = new MagmaWall();
        addObject(magmaWall6,24,271);
        MagmaWall magmaWall7 = new MagmaWall();
        addObject(magmaWall7,25,320);
        MagmaWall magmaWall8 = new MagmaWall();
        addObject(magmaWall8,26,370);

        MagmaWall magmaWall9 = new MagmaWall();
        addObject(magmaWall9,25,420);
        MagmaWall magmaWall10 = new MagmaWall();
        addObject(magmaWall10,25,470);

        MagmaWall magmaWall11 = new MagmaWall();
        addObject(magmaWall11,26,521);
        MagmaWall magmaWall12 = new MagmaWall();
        addObject(magmaWall12,25,571);
        MagmaWall magmaWall13 = new MagmaWall();
        addObject(magmaWall13,24,621);
        MagmaWall magmaWall14 = new MagmaWall();
        addObject(magmaWall14,26,671);
        MagmaWall magmaWall15 = new MagmaWall();
        addObject(magmaWall15,26,722);
        MagmaWall magmaWall16 = new MagmaWall();
        addObject(magmaWall16,24,772);
        MagmaWall magmaWall17 = new MagmaWall();
        addObject(magmaWall17,74,775);
        MagmaWall magmaWall18 = new MagmaWall();
        addObject(magmaWall18,124,776);
        MagmaWall magmaWall19 = new MagmaWall();
        addObject(magmaWall19,174,776);
        MagmaWall magmaWall20 = new MagmaWall();
        addObject(magmaWall20,223,776);
        MagmaWall magmaWall21 = new MagmaWall();
        addObject(magmaWall21,273,777);
        MagmaWall magmaWall22 = new MagmaWall();
        addObject(magmaWall22,323,777);
        MagmaWall magmaWall23 = new MagmaWall();
        addObject(magmaWall23,373,776);
        MagmaWall magmaWall24 = new MagmaWall();
        addObject(magmaWall24,422,776);
        MagmaWall magmaWall25 = new MagmaWall();
        addObject(magmaWall25,472,776);
        MagmaWall magmaWall26 = new MagmaWall();
        addObject(magmaWall26,521,776);
        MagmaWall magmaWall27 = new MagmaWall();
        addObject(magmaWall27,571,776);
        MagmaWall magmaWall28 = new MagmaWall();
        addObject(magmaWall28,620,776);
        MagmaWall magmaWall29 = new MagmaWall();
        addObject(magmaWall29,670,776);
        MagmaWall magmaWall30 = new MagmaWall();
        addObject(magmaWall30,720,776);
        MagmaWall magmaWall31 = new MagmaWall();
        addObject(magmaWall31,770,775);
        MagmaWall magmaWall32 = new MagmaWall();
        addObject(magmaWall32,820,775);
        MagmaWall magmaWall33 = new MagmaWall();
        addObject(magmaWall33,870,775);
        MagmaWall magmaWall34 = new MagmaWall();
        addObject(magmaWall34,920,775);
        MagmaWall magmaWall35 = new MagmaWall();
        addObject(magmaWall35,970,775);
        MagmaWall magmaWall36 = new MagmaWall();
        addObject(magmaWall36,977,774);
        MagmaWall magmaWall37 = new MagmaWall();
        addObject(magmaWall37,976,726);
        MagmaWall magmaWall38 = new MagmaWall();
        addObject(magmaWall38,975,675);
        MagmaWall magmaWall39 = new MagmaWall();
        addObject(magmaWall39,975,624);
        MagmaWall magmaWall40 = new MagmaWall();
        addObject(magmaWall40,975,574);

        MagmaWall magmaWall41 = new MagmaWall();
        addObject(magmaWall41,975,523);
        MagmaWall magmaWall42 = new MagmaWall();
        addObject(magmaWall42,976,473);
        MagmaWall magmaWall43 = new MagmaWall();
        addObject(magmaWall43,975,422);
        MagmaWall magmaWall44 = new MagmaWall();
        addObject(magmaWall44,976,371);
        MagmaWall magmaWall45 = new MagmaWall();
        addObject(magmaWall45,976,320);
        MagmaWall magmaWall46 = new MagmaWall();
        addObject(magmaWall46,976,270);
        MagmaWall magmaWall47 = new MagmaWall();
        addObject(magmaWall47,976,219);
        MagmaWall magmaWall48 = new MagmaWall();
        addObject(magmaWall48,976,169);
        MagmaWall magmaWall49 = new MagmaWall();
        addObject(magmaWall49,975,118);
        MagmaWall magmaWall50 = new MagmaWall();
        addObject(magmaWall50,975,68);
        MagmaWall magmaWall51 = new MagmaWall();
        addObject(magmaWall51,975,17);
        MagmaWall magmaWall52 = new MagmaWall();
        addObject(magmaWall52,74,24);
        MagmaWall magmaWall53 = new MagmaWall();
        addObject(magmaWall53,124,24);
        MagmaWall magmaWall54 = new MagmaWall();
        addObject(magmaWall54,175,25);
        MagmaWall magmaWall55 = new MagmaWall();
        addObject(magmaWall55,225,25);
        MagmaWall magmaWall56 = new MagmaWall();
        addObject(magmaWall56,276,25);
        MagmaWall magmaWall57 = new MagmaWall();
        addObject(magmaWall57,327,26);
        MagmaWall magmaWall58 = new MagmaWall();
        addObject(magmaWall58,377,25);
        MagmaWall magmaWall59 = new MagmaWall();
        addObject(magmaWall59,427,25);
        MagmaWall magmaWall60 = new MagmaWall();
        addObject(magmaWall60,477,24);
        MagmaWall magmaWall61 = new MagmaWall();
        addObject(magmaWall61,527,25);
        MagmaWall magmaWall62 = new MagmaWall();
        addObject(magmaWall62,577,25);
        MagmaWall magmaWall63 = new MagmaWall();
        addObject(magmaWall63,628,25);
        MagmaWall magmaWall64 = new MagmaWall();
        addObject(magmaWall64,680,25);
        MagmaWall magmaWall65 = new MagmaWall();
        addObject(magmaWall65,730,24);
        MagmaWall magmaWall66 = new MagmaWall();
        addObject(magmaWall66,780,24);
        MagmaWall magmaWall67 = new MagmaWall();
        addObject(magmaWall67,831,24);
        MagmaWall magmaWall68 = new MagmaWall();
        addObject(magmaWall68,882,24);
        MagmaWall magmaWall69 = new MagmaWall();
        addObject(magmaWall69,928,24);
        MagmaWall magmaWall70 = new MagmaWall();
        addObject(magmaWall70,387,728);
        MagmaWall magmaWall71 = new MagmaWall();
        addObject(magmaWall71,437,727);
        MagmaWall magmaWall72 = new MagmaWall();
        addObject(magmaWall72,487,728);
        MagmaWall magmaWall73 = new MagmaWall();
        addObject(magmaWall73,537,728);
        MagmaWall magmaWall74 = new MagmaWall();
        addObject(magmaWall74,586,728);

        MagmaWall magmaWall75 = new MagmaWall();
        addObject(magmaWall75,636,728);
        MagmaWall magmaWall76 = new MagmaWall();
        addObject(magmaWall76,370,75);
        MagmaWall magmaWall77 = new MagmaWall();
        addObject(magmaWall77,420,75);
        MagmaWall magmaWall78 = new MagmaWall();
        addObject(magmaWall78,470,74);
        MagmaWall magmaWall79 = new MagmaWall();
        addObject(magmaWall79,520,73);
        MagmaWall magmaWall80 = new MagmaWall();
        addObject(magmaWall80,570,73);
        MagmaWall magmaWall81 = new MagmaWall();
        addObject(magmaWall81,620,72);

        MagmaWall magmaWall83 = new MagmaWall();
        addObject(magmaWall83,75,334);
        MagmaWall magmaWall84 = new MagmaWall();
        addObject(magmaWall84,76,383);
        MagmaWall magmaWall85 = new MagmaWall();
        addObject(magmaWall85,75,432);
        MagmaWall magmaWall86 = new MagmaWall();
        addObject(magmaWall86,74,482);
        MagmaWall magmaWall87 = new MagmaWall();
        addObject(magmaWall87,76,531);

        MagmaWall magmaWall82 = new MagmaWall();
        addObject(magmaWall82,74,284);
        MagmaWall magmaWall88 = new MagmaWall();
        addObject(magmaWall88,926,291);
        MagmaWall magmaWall89 = new MagmaWall();
        addObject(magmaWall89,927,340);
        MagmaWall magmaWall90 = new MagmaWall();
        addObject(magmaWall90,928,390);
        MagmaWall magmaWall91 = new MagmaWall();
        addObject(magmaWall91,928,436);
        MagmaWall magmaWall92 = new MagmaWall();
        addObject(magmaWall92,928,484);
        MagmaWall magmaWall93 = new MagmaWall();
        addObject(magmaWall93,927,533);
        RedWall redWall = new RedWall();
        addObject(redWall,144,647);
        RedWall redWall2 = new RedWall();
        addObject(redWall2,272,646);

        RedWall redWall3 = new RedWall();
        addObject(redWall3,756,644);

        RedWall redWall4 = new RedWall();
        addObject(redWall4,871,644);
        RedWall redWall5 = new RedWall();
        addObject(redWall5,808,522);

        RedWall redWall6 = new RedWall();
        addObject(redWall6,806,413);
        RedWall redWall7 = new RedWall();
        addObject(redWall7,807,298);
        RedWall redWall8 = new RedWall();
        addObject(redWall8,868,146);
        RedWall redWall9 = new RedWall();
        addObject(redWall9,736,146);

        RedWall redWall10 = new RedWall();
        addObject(redWall10,391,673);
        RedWall redWall11 = new RedWall();
        addObject(redWall11,451,673);
        RedWall redWall12 = new RedWall();
        addObject(redWall12,511,673);
        RedWall redWall13 = new RedWall();
        addObject(redWall13,571,673);
        RedWall redWall14 = new RedWall();
        addObject(redWall14,630,673);
        RedWall redWall15 = new RedWall();
        addObject(redWall15,392,613);
        RedWall redWall16 = new RedWall();
        addObject(redWall16,630,613);
        RedWall redWall17 = new RedWall();
        addObject(redWall17,374,130);
        RedWall redWall18 = new RedWall();
        addObject(redWall18,434,129);
        RedWall redWall19 = new RedWall();
        addObject(redWall19,494,129);
        RedWall redWall20 = new RedWall();
        addObject(redWall20,554,129);
        RedWall redWall21 = new RedWall();
        addObject(redWall21,614,128);
        RedWall redWall22 = new RedWall();
        addObject(redWall22,374,190);
        RedWall redWall23 = new RedWall();
        addObject(redWall23,614,188);
        RedWall redWall24 = new RedWall();
        addObject(redWall24,373,334);
        RedWall redWall25 = new RedWall();
        addObject(redWall25,500,333);
        RedWall redWall26 = new RedWall();
        addObject(redWall26,623,331);
        RedWall redWall27 = new RedWall();
        addObject(redWall27,377,485);
        RedWall redWall28 = new RedWall();
        addObject(redWall28,507,482);
        RedWall redWall29 = new RedWall();
        addObject(redWall29,630,481);
        RedWall redWall30 = new RedWall();
        addObject(redWall30,200,523);
        RedWall redWall31 = new RedWall();
        addObject(redWall31,196,411);
        RedWall redWall32 = new RedWall();
        addObject(redWall32,191,288);
        RedWall redWall33 = new RedWall();
        addObject(redWall33,136,147);
        RedWall redWall34 = new RedWall();
        addObject(redWall34,258,148);

        PlayerName1 playerName1 = new PlayerName1();
        addObject(playerName1,511,29);

        addObject(healthBar3,496,60);
        PlayerName2 playerName2 = new PlayerName2();
        addObject(playerName2,521,724);
        addObject(healthBar4,506,756);

        redWall25.setLocation(497,332);
        SpeedUp speedUp = new SpeedUp();
        addObject(speedUp,497,332);
        redWall6.setLocation(808,410);
        Medkit medkit = new Medkit();
        addObject(medkit,808,410);
        redWall2.setLocation(273,642);
        BombKit bombKit = new BombKit();
        addObject(bombKit,273,642);
        BombKit bombKit2 = new BombKit();
        addObject(bombKit2,908,79);
        Medkit medkit2 = new Medkit();
        addObject(medkit2,82,80);
        SpeedUp speedUp2 = new SpeedUp();
        addObject(speedUp2,916,719);
        SpeedUp speedUp3 = new SpeedUp();
        addObject(speedUp3,190,348);
        SpeedUp speedUp4 = new SpeedUp();
        addObject(speedUp4,504,672);
        SpeedUp speedUp5 = new SpeedUp();
        addObject(speedUp5,610,129);
        redWall.setLocation(138,641);
        SpeedUp speedUp6 = new SpeedUp();
        addObject(speedUp6,138,641);
        redWall5.setLocation(809,519);
        SpeedUp speedUp7 = new SpeedUp();
        addObject(speedUp7,809,519);
        redWall34.setLocation(255,146);
        SpeedUp speedUp8 = new SpeedUp();
        addObject(speedUp8,255,146);
        redWall29.setLocation(628,478);
        SpeedUp speedUp9 = new SpeedUp();
        addObject(speedUp9,628,478);
        Beetle beetle = new Beetle();
        addObject(beetle,510,614);
        Ant ant = new Ant();
        addObject(ant,493,178);
    }
}
