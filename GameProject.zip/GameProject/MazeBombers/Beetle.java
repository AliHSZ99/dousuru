import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Beetle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Beetle extends Characters
{   
    public boolean touchingBullet = true;
    public boolean touchingMedkit = false;
    int rotation = 0;
    public boolean lshift = false;
    public boolean haveBomb = false;
    /**
     * Act - do whatever the Beetle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Player2Keys();
        hitByBulletInVolcano();
        medkit();
        bomb();
    }   

    public void hitByBulletInVolcano(){
        Actor bullet = getOneIntersectingObject(Bullet.class);

        if (bullet != null){
            World myWorld = getWorld();
            VolcanoMap volcanoMap = (VolcanoMap)myWorld;
            HealthBar4 healthBar4 = volcanoMap.getHealthBar4();
            getWorld().removeObject(bullet);
            if (touchingBullet == false){
                healthBar4.loseHealth4();
                Greenfoot.playSound("bodybullet.mp3");
                touchingBullet = true;
            }
        } else {
            touchingBullet = false;
        }
    }
    
    // medkit
    public void medkit(){
        Actor medkit = getOneIntersectingObject(Medkit.class);
        if  (medkit != null ){
            World myWorld = getWorld();
            VolcanoMap volcanoMap = (VolcanoMap)myWorld;
            HealthBar4 healthBar2 = volcanoMap.getHealthBar4();
            getWorld().removeObject(medkit);
            if  (touchingMedkit == false){
                healthBar2.gainHealth();
                Greenfoot.playSound("heal.mp3");
                touchingMedkit = true;
            } else {
                touchingMedkit = false;
            }   
        } 
    }

    // The bomb
    public void bomb (){
        int x = getX();
        int y = getY();
        rotation = getRotation();
        Actor bombKit = getOneIntersectingObject(BombKit.class);
        if  (bombKit != null){
            getWorld().removeObject(bombKit);
            haveBomb = true;
        }
        if(!lshift &&Greenfoot.isKeyDown("shift") && haveBomb){
            Bomb bomb2 = new Bomb (); 
            if (rotation == 90){
                getWorld().addObject(bomb2, x - 35 , y );
                lshift = true;
                haveBomb = false;
            }else if (rotation == 0){
                getWorld().addObject(bomb2, x , y +35);
                lshift = true;
                haveBomb = false;
            }else if (rotation == 180){
                getWorld().addObject(bomb2, x , y -35);
                lshift = true;
                haveBomb = false;
            }else if (rotation == 270){
                getWorld().addObject(bomb2, x + 35 , y);
                lshift = true;
                haveBomb = false;
            }  

        } else if (lshift && !Greenfoot.isKeyDown("l")){
            lshift = false;
        }

    }
}
