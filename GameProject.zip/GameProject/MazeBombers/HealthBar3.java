import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**    ****!THE CODES HERE ARE THE SAME IN HEALTHBAR.****
 * Write a description of class HealthBar3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar3 extends Actor
{
    int health = 10;
    int healthWidth = 100;
    int healthHeight = 10;
    int pixelsPerHealth = (int) healthWidth/health;
    /**
     * Act - do whatever the HealthBar3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        healthUpdate();
        player2Win();
    }    

    public void healthUpdate(){
        setImage(new GreenfootImage(healthWidth +2 , healthHeight + 2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.WHITE);
        myImage.drawRect(0, 0, healthWidth + 1, healthHeight + 1);
        myImage.setColor(Color.RED);
        myImage.fillRect(1, 1, health*pixelsPerHealth, healthHeight);
    }
    
    public int getHealth(){
        return health;
    }
    
    public void loseHealth3(){
        health--;
    }

    public void bombDamage(){
        health -= 2;
    }

    public void gainHealth(){
        health += 3 ;
    }

    public void player2Win (){
        if (health == 0){
            P2EndScreen end2 = new P2EndScreen();
            Greenfoot.setWorld(end2);
        }

    } 
}

