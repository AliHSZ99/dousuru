import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SplashScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SplashScreen extends World
{
    GreenfootSound myMusic = new GreenfootSound("vanier.mp3");// Create a music.
    int time = 300;//Works as a timer.
    /**
     * Constructor for objects of class SplashScreen.
     * 
     */
    public SplashScreen()
    {    
        // Create a new world with 1000x800 cells with a cell size of 1x1 pixels.
        super(1000, 800, 1); 
        
    }
    public void act(){
        myMusic.play();
        time--;
        if(time ==0){//When the time reaches zero it will move to the StartScreenWorld.
            StartScreenWorld startScreenWorld = new StartScreenWorld();
            Greenfoot.setWorld(startScreenWorld);
            myMusic.stop();
        }
        
    }
}
