import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MapSelectionWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MapSelectionWorld extends World
{
    GreenfootSound myMusic = new GreenfootSound ("startmusic.mp3");//Create the music.
    /**
     * Constructor for objects of class MapSelectionWorld.
     * 
     */
    public MapSelectionWorld()
    {    
        // Create a new world with 800x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
    }
    
    public void act(){
        myMusic.play();// play the music
        // provides a map selection for the user. If the user press "1", the world will move to the VolcanoMap. 
        //If the user press "2", the world will move to the Classic Map.
        if (Greenfoot.isKeyDown("1")){
            VolcanoMap volcanoMap = new VolcanoMap();
            Greenfoot.setWorld(volcanoMap);
            myMusic.stop();
        }
        if (Greenfoot.isKeyDown("2")){
            ClassicMap classicMap = new ClassicMap();
            Greenfoot.setWorld(classicMap);
            myMusic.stop();
        }
    }
}
