import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spider here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spider extends Characters
{
    public boolean touchingBullet = true;
    public boolean touchingMedkit = false;
    int rotation = 0;
    public boolean lshift = false;
    public boolean haveBomb = false;
    /**
     * Act - do whatever the Spider wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Player2Keys();
        hitByBulletInClassic();
        bomb();
        medkit();
    }

    public void hitByBulletInClassic(){
        Actor bullet2 = getOneIntersectingObject(Bullet.class);
        if (bullet2 != null){
            World myWorld = getWorld();
            ClassicMap classicMap = (ClassicMap)myWorld;
            HealthBar2 healthBar2 = classicMap.getHealthBar2();
            getWorld().removeObject(bullet2);
            if (touchingBullet == false){
                healthBar2.loseHealth();
                Greenfoot.playSound("bodybullet.mp3");
                touchingBullet = true;
            }
        } else {
            touchingBullet = false;
        }
    }

    // medkit
    public void medkit(){
        Actor medkit = getOneIntersectingObject(Medkit.class);
        if  (medkit != null ){
            World myWorld = getWorld();
            ClassicMap classicMap = (ClassicMap)myWorld;
            HealthBar2 healthBar2 = classicMap.getHealthBar2();
            getWorld().removeObject(medkit);
            if  (touchingMedkit == false){
                healthBar2.gainHealth();
                Greenfoot.playSound("heal.mp3");
                touchingMedkit = true;
            } else {
                touchingMedkit = false;
            }   
        } 
    }

    // bomb
    public void bomb (){
        int x = getX();
        int y = getY();
        rotation = getRotation();
        Actor bombKit = getOneIntersectingObject(BombKit.class);
        if  (bombKit != null){
            getWorld().removeObject(bombKit);
            haveBomb = true;
        }
        if(!lshift &&Greenfoot.isKeyDown("shift") && haveBomb){
            Bomb bomb2 = new Bomb (); 
            if (rotation == 90){
                getWorld().addObject(bomb2, x - 35 , y );
                lshift = true;
                haveBomb = false;
            }else if (rotation == 0){
                getWorld().addObject(bomb2, x , y +35);
                lshift = true;
                haveBomb = false;
            }else if (rotation == 180){
                getWorld().addObject(bomb2, x , y -35);
                lshift = true;
                haveBomb = false;
            }else if (rotation == 270){
                getWorld().addObject(bomb2, x + 35 , y);
                lshift = true;
                haveBomb = false;
            }  

        } else if (lshift && !Greenfoot.isKeyDown("l")){
            lshift = false;
        }

    }
}
