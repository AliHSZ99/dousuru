
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Cockroach here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cockroach extends Characters
{
    public boolean touchingBullet = true;
    public boolean touchingMedkit= false;
    public boolean touchingExplosion = true;
    public boolean xshift;
    public int rotation = 0;
    public boolean haveBomb = false;

    /**
     * Act - do whatever the Cockroach wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        Player1Keys();
        hitByBulletInClassic();
        medkit();
        bomb();
    }    

    public void hitByBulletInClassic(){
        Actor bullet2 = getOneIntersectingObject(Bullet2.class);

        if (bullet2 != null){
            getWorld().removeObject(bullet2);
            World myWorld = getWorld();
            ClassicMap classicMap = (ClassicMap)myWorld;
            HealthBar healthBar = classicMap.getHealthBar();
            if (touchingBullet == false){
                healthBar.loseHealth();
                Greenfoot.playSound("bodybullet.mp3");
                touchingBullet = true;
            }
        } else {
            touchingBullet = false;
        }
    }

    // Medkit powerup code. Removing it and using it
    public void medkit(){
        Actor medkit = getOneIntersectingObject(Medkit.class);
        if  (medkit != null ){
            World myWorld = getWorld();
            ClassicMap classicMap = (ClassicMap)myWorld;
            HealthBar healthBar = classicMap.getHealthBar();
            getWorld().removeObject(medkit);
            if  (touchingMedkit == false){
                healthBar.gainHealth();
                Greenfoot.playSound("heal.mp3");
                touchingMedkit = true;
            } else {
                touchingMedkit = false;
            }   
        } 
    }

    // bomb
    public void bomb (){
        int x = getX();
        int y = getY();
        rotation = getRotation();
        Actor bombKit = getOneIntersectingObject(BombKit.class);
        if (bombKit != null){
            getWorld().removeObject(bombKit);
            haveBomb = true;
        }
        if(!xshift &&Greenfoot.isKeyDown("space") && haveBomb){
            Bomb bomb = new Bomb (); 
            if (rotation == 90){
                getWorld().addObject(bomb, x - 35 , y );
                xshift = true;
                haveBomb = false;
            }else if (rotation == 0){
                getWorld().addObject(bomb, x , y +35);
                xshift = true;
                haveBomb = false;
            }else if (rotation == 180){
                getWorld().addObject(bomb, x , y -35);
                xshift = true;
                haveBomb = false;
            }else if (rotation == 270){
                getWorld().addObject(bomb, x + 35 , y);
                xshift = true;
                haveBomb = false;
            }  
        } else if (xshift && !Greenfoot.isKeyDown("x")){
            xshift = false;
        }
    }
}
