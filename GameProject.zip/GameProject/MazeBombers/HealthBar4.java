import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**      ****!THE CODES HERE ARE THE SAME IN HEALTHBAR2.****
 * Write a description of class HealthBar4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar4 extends Actor
{
    int health = 10;
    int healthWidth = 100;
    int healthHeight = 10;
    int pixelsPerHealth = (int) healthWidth/health;
    /**
     * Act - do whatever the HealthBar4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        healthUpdate();
        player1Win();
    } 
    
    public int getHealth(){
        return health;
    }
    
    public void healthUpdate(){
        setImage(new GreenfootImage(healthWidth +2 , healthHeight + 2));
        GreenfootImage myImage = getImage();
        myImage.setColor(Color.BLACK);
        myImage.drawRect(0, 0, healthWidth + 1, healthHeight + 1);
        myImage.setColor(Color.BLUE);
        myImage.fillRect(1, 1, health*pixelsPerHealth, healthHeight);
    }
    public void loseHealth4(){
        health--;
    }
    public void gainHealth(){
        health += 3;
    }
    public void player1Win (){
        if (health == 0){
            P1EndScreen end1 = new P1EndScreen();
            Greenfoot.setWorld(end1);
            
        }
    }
}
