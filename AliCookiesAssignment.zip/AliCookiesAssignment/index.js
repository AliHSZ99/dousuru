$(document).ready(function(){

    var url = "https://reqres.in/api/login";
    $("#loginbutton").click(function(){
        var obj = {};
        obj.email = $("#emailbox").val();
        obj.password = $("#passbox").val();

        $.post(url, obj, function(data){
            alert("Login Successful!")
            document.cookie = "token=" + data.token;
        }).fail(function(){
            alert("Your email and/or password is/are wrong...");
            $("#passbox").val("");
        });
    });

});