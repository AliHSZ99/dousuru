﻿
namespace RestaurantApplication
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.tunaSandwichPanel = new System.Windows.Forms.Panel();
            this.sandwichInfoLabel = new System.Windows.Forms.Label();
            this.tunaButtonsPanel = new System.Windows.Forms.Panel();
            this.sandwichCountLabel = new System.Windows.Forms.Label();
            this.addSandwichButton = new System.Windows.Forms.Label();
            this.sandwichInfoButton = new System.Windows.Forms.Label();
            this.removeSandwichButton = new System.Windows.Forms.Label();
            this.vegetableSoupPanel = new System.Windows.Forms.Panel();
            this.vegetableSoupInfoLabel = new System.Windows.Forms.Label();
            this.vegetableSoupButtonsPanel = new System.Windows.Forms.Panel();
            this.vegetableSoupCountLabel = new System.Windows.Forms.Label();
            this.vegetableSoupInfoButton = new System.Windows.Forms.Label();
            this.vegetableSoupAddButton = new System.Windows.Forms.Label();
            this.vegetableSoupRemoveButton = new System.Windows.Forms.Label();
            this.coffePanel = new System.Windows.Forms.Panel();
            this.coffeeInfoLabel = new System.Windows.Forms.Label();
            this.coffeeButtonsPanel = new System.Windows.Forms.Panel();
            this.coffeeCountLabel = new System.Windows.Forms.Label();
            this.coffeeInfoButton = new System.Windows.Forms.Label();
            this.coffeAddButton = new System.Windows.Forms.Label();
            this.coffeeRemoveButton = new System.Windows.Forms.Label();
            this.teaPanel = new System.Windows.Forms.Panel();
            this.teaInfoLabel = new System.Windows.Forms.Label();
            this.teaButtonsPanel = new System.Windows.Forms.Panel();
            this.teaCountLabel = new System.Windows.Forms.Label();
            this.teaInfoButton = new System.Windows.Forms.Label();
            this.teaAddButton = new System.Windows.Forms.Label();
            this.teaRemoveButton = new System.Windows.Forms.Label();
            this.waterPanel = new System.Windows.Forms.Panel();
            this.waterInfoLabel = new System.Windows.Forms.Label();
            this.waterButtonsPanel = new System.Windows.Forms.Panel();
            this.waterCountLabel = new System.Windows.Forms.Label();
            this.waterInfoButton = new System.Windows.Forms.Label();
            this.waterAddButton = new System.Windows.Forms.Label();
            this.waterRemoveButton = new System.Windows.Forms.Label();
            this.sidePanel = new System.Windows.Forms.Panel();
            this.aboutButton = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cartButton = new System.Windows.Forms.Label();
            this.rewardsButton = new System.Windows.Forms.Label();
            this.signinButton = new System.Windows.Forms.Label();
            this.menuButton = new System.Windows.Forms.Label();
            this.specialsButton = new System.Windows.Forms.Label();
            this.frenchLabel = new System.Windows.Forms.Label();
            this.englishLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pscLabel = new System.Windows.Forms.Label();
            this.maximizeButton = new System.Windows.Forms.Button();
            this.minimizeButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.chickenSaladButtonsPanel = new System.Windows.Forms.Panel();
            this.chickenSaladCountLabel = new System.Windows.Forms.Label();
            this.chickenSaladInfoButton = new System.Windows.Forms.Label();
            this.chickenSaladRemoveButton = new System.Windows.Forms.Label();
            this.chickenSaladAddButton = new System.Windows.Forms.Label();
            this.chickenSaladPanel = new System.Windows.Forms.Panel();
            this.chickenSaladInfoLabel = new System.Windows.Forms.Label();
            this.checkoutButton = new System.Windows.Forms.Label();
            this.rewardsUserControl1 = new RestaurantApplication.RewardsUserControl();
            this.specialsUserControl1 = new RestaurantApplication.SpecialsUserControl();
            this.loginUserControl1 = new RestaurantApplication.LoginUserControl();
            this.cartUserControl1 = new RestaurantApplication.CartUserControl();
            this.aboutUserControl1 = new RestaurantApplication.AboutUserControl();
            this.tunaSandwichPanel.SuspendLayout();
            this.tunaButtonsPanel.SuspendLayout();
            this.vegetableSoupPanel.SuspendLayout();
            this.vegetableSoupButtonsPanel.SuspendLayout();
            this.coffePanel.SuspendLayout();
            this.coffeeButtonsPanel.SuspendLayout();
            this.teaPanel.SuspendLayout();
            this.teaButtonsPanel.SuspendLayout();
            this.waterPanel.SuspendLayout();
            this.waterButtonsPanel.SuspendLayout();
            this.sidePanel.SuspendLayout();
            this.chickenSaladButtonsPanel.SuspendLayout();
            this.chickenSaladPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tunaSandwichPanel
            // 
            this.tunaSandwichPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(106)))), ((int)(((byte)(141)))));
            this.tunaSandwichPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.tunasandwich;
            this.tunaSandwichPanel.Controls.Add(this.sandwichInfoLabel);
            this.tunaSandwichPanel.Controls.Add(this.tunaButtonsPanel);
            this.tunaSandwichPanel.ForeColor = System.Drawing.Color.Black;
            this.tunaSandwichPanel.Location = new System.Drawing.Point(193, 25);
            this.tunaSandwichPanel.Name = "tunaSandwichPanel";
            this.tunaSandwichPanel.Size = new System.Drawing.Size(253, 220);
            this.tunaSandwichPanel.TabIndex = 1;
            this.tunaSandwichPanel.MouseEnter += new System.EventHandler(this.TunaSandwichPanel_MouseEnter_1);
            // 
            // sandwichInfoLabel
            // 
            this.sandwichInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.sandwichInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sandwichInfoLabel.ForeColor = System.Drawing.Color.White;
            this.sandwichInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.sandwichInfoLabel.Name = "sandwichInfoLabel";
            this.sandwichInfoLabel.Size = new System.Drawing.Size(253, 150);
            this.sandwichInfoLabel.TabIndex = 0;
            this.sandwichInfoLabel.Text = "A sandwich made from canned tuna. Combined with mayonnaise, celery and tomato. Pr" +
    "ice: $8.75";
            this.sandwichInfoLabel.Visible = false;
            // 
            // tunaButtonsPanel
            // 
            this.tunaButtonsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.tunaButtonsPanel.Controls.Add(this.sandwichCountLabel);
            this.tunaButtonsPanel.Controls.Add(this.addSandwichButton);
            this.tunaButtonsPanel.Controls.Add(this.sandwichInfoButton);
            this.tunaButtonsPanel.Controls.Add(this.removeSandwichButton);
            this.tunaButtonsPanel.Location = new System.Drawing.Point(0, 149);
            this.tunaButtonsPanel.Name = "tunaButtonsPanel";
            this.tunaButtonsPanel.Size = new System.Drawing.Size(253, 71);
            this.tunaButtonsPanel.TabIndex = 5;
            this.tunaButtonsPanel.Visible = false;
            this.tunaButtonsPanel.MouseLeave += new System.EventHandler(this.TunaButtonsPanel_MouseLeave);
            // 
            // sandwichCountLabel
            // 
            this.sandwichCountLabel.AutoSize = true;
            this.sandwichCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.sandwichCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sandwichCountLabel.ForeColor = System.Drawing.Color.White;
            this.sandwichCountLabel.Location = new System.Drawing.Point(71, 25);
            this.sandwichCountLabel.Name = "sandwichCountLabel";
            this.sandwichCountLabel.Size = new System.Drawing.Size(24, 25);
            this.sandwichCountLabel.TabIndex = 7;
            this.sandwichCountLabel.Text = "0";
            // 
            // addSandwichButton
            // 
            this.addSandwichButton.BackColor = System.Drawing.Color.Transparent;
            this.addSandwichButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addSandwichButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.addSandwichButton.Location = new System.Drawing.Point(108, 15);
            this.addSandwichButton.Name = "addSandwichButton";
            this.addSandwichButton.Size = new System.Drawing.Size(48, 43);
            this.addSandwichButton.TabIndex = 2;
            this.addSandwichButton.Click += new System.EventHandler(this.AddSandwichButton_Click);
            // 
            // sandwichInfoButton
            // 
            this.sandwichInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.sandwichInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sandwichInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.sandwichInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.sandwichInfoButton.Location = new System.Drawing.Point(188, 25);
            this.sandwichInfoButton.Name = "sandwichInfoButton";
            this.sandwichInfoButton.Size = new System.Drawing.Size(25, 28);
            this.sandwichInfoButton.TabIndex = 1;
            this.sandwichInfoButton.Click += new System.EventHandler(this.SandwichInfoButton_Click);
            // 
            // removeSandwichButton
            // 
            this.removeSandwichButton.BackColor = System.Drawing.Color.Transparent;
            this.removeSandwichButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.removeSandwichButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.removeSandwichButton.Location = new System.Drawing.Point(14, 15);
            this.removeSandwichButton.Name = "removeSandwichButton";
            this.removeSandwichButton.Size = new System.Drawing.Size(41, 45);
            this.removeSandwichButton.TabIndex = 0;
            this.removeSandwichButton.Click += new System.EventHandler(this.RemoveSandwichButton_Click);
            // 
            // vegetableSoupPanel
            // 
            this.vegetableSoupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(140)))), ((int)(((byte)(218)))));
            this.vegetableSoupPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.vegetablesoup;
            this.vegetableSoupPanel.Controls.Add(this.vegetableSoupInfoLabel);
            this.vegetableSoupPanel.Controls.Add(this.vegetableSoupButtonsPanel);
            this.vegetableSoupPanel.Location = new System.Drawing.Point(809, 25);
            this.vegetableSoupPanel.Name = "vegetableSoupPanel";
            this.vegetableSoupPanel.Size = new System.Drawing.Size(244, 220);
            this.vegetableSoupPanel.TabIndex = 3;
            this.vegetableSoupPanel.MouseEnter += new System.EventHandler(this.VegetableSoupPanel_MouseEnter);
            // 
            // vegetableSoupInfoLabel
            // 
            this.vegetableSoupInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.vegetableSoupInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vegetableSoupInfoLabel.ForeColor = System.Drawing.Color.White;
            this.vegetableSoupInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.vegetableSoupInfoLabel.Name = "vegetableSoupInfoLabel";
            this.vegetableSoupInfoLabel.Size = new System.Drawing.Size(253, 150);
            this.vegetableSoupInfoLabel.TabIndex = 7;
            this.vegetableSoupInfoLabel.Text = "A soup prepared using celery, carrots, onion, broccoli and water. Price: $8.25\r\n";
            this.vegetableSoupInfoLabel.Visible = false;
            // 
            // vegetableSoupButtonsPanel
            // 
            this.vegetableSoupButtonsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.vegetableSoupButtonsPanel.Controls.Add(this.vegetableSoupCountLabel);
            this.vegetableSoupButtonsPanel.Controls.Add(this.vegetableSoupInfoButton);
            this.vegetableSoupButtonsPanel.Controls.Add(this.vegetableSoupAddButton);
            this.vegetableSoupButtonsPanel.Controls.Add(this.vegetableSoupRemoveButton);
            this.vegetableSoupButtonsPanel.Location = new System.Drawing.Point(0, 149);
            this.vegetableSoupButtonsPanel.Name = "vegetableSoupButtonsPanel";
            this.vegetableSoupButtonsPanel.Size = new System.Drawing.Size(244, 71);
            this.vegetableSoupButtonsPanel.TabIndex = 5;
            this.vegetableSoupButtonsPanel.Visible = false;
            this.vegetableSoupButtonsPanel.MouseLeave += new System.EventHandler(this.VegetableSoupButtonsPanel_MouseLeave);
            // 
            // vegetableSoupCountLabel
            // 
            this.vegetableSoupCountLabel.AutoSize = true;
            this.vegetableSoupCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.vegetableSoupCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vegetableSoupCountLabel.ForeColor = System.Drawing.Color.White;
            this.vegetableSoupCountLabel.Location = new System.Drawing.Point(72, 25);
            this.vegetableSoupCountLabel.Name = "vegetableSoupCountLabel";
            this.vegetableSoupCountLabel.Size = new System.Drawing.Size(24, 25);
            this.vegetableSoupCountLabel.TabIndex = 8;
            this.vegetableSoupCountLabel.Text = "0";
            // 
            // vegetableSoupInfoButton
            // 
            this.vegetableSoupInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.vegetableSoupInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vegetableSoupInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.vegetableSoupInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.vegetableSoupInfoButton.Location = new System.Drawing.Point(187, 21);
            this.vegetableSoupInfoButton.Name = "vegetableSoupInfoButton";
            this.vegetableSoupInfoButton.Size = new System.Drawing.Size(25, 29);
            this.vegetableSoupInfoButton.TabIndex = 6;
            this.vegetableSoupInfoButton.Click += new System.EventHandler(this.VegetableSoupInfoButton_Click);
            // 
            // vegetableSoupAddButton
            // 
            this.vegetableSoupAddButton.BackColor = System.Drawing.Color.Transparent;
            this.vegetableSoupAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vegetableSoupAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.vegetableSoupAddButton.Location = new System.Drawing.Point(111, 15);
            this.vegetableSoupAddButton.Name = "vegetableSoupAddButton";
            this.vegetableSoupAddButton.Size = new System.Drawing.Size(48, 43);
            this.vegetableSoupAddButton.TabIndex = 6;
            this.vegetableSoupAddButton.Click += new System.EventHandler(this.VegetableSoupAddButton_Click);
            // 
            // vegetableSoupRemoveButton
            // 
            this.vegetableSoupRemoveButton.BackColor = System.Drawing.Color.Transparent;
            this.vegetableSoupRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.vegetableSoupRemoveButton.Enabled = false;
            this.vegetableSoupRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.vegetableSoupRemoveButton.Location = new System.Drawing.Point(16, 13);
            this.vegetableSoupRemoveButton.Name = "vegetableSoupRemoveButton";
            this.vegetableSoupRemoveButton.Size = new System.Drawing.Size(41, 45);
            this.vegetableSoupRemoveButton.TabIndex = 5;
            this.vegetableSoupRemoveButton.Click += new System.EventHandler(this.VegetableSoupRemoveButton_Click);
            // 
            // coffePanel
            // 
            this.coffePanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.coffee;
            this.coffePanel.Controls.Add(this.coffeeInfoLabel);
            this.coffePanel.Controls.Add(this.coffeeButtonsPanel);
            this.coffePanel.Location = new System.Drawing.Point(193, 325);
            this.coffePanel.Name = "coffePanel";
            this.coffePanel.Size = new System.Drawing.Size(244, 220);
            this.coffePanel.TabIndex = 4;
            this.coffePanel.MouseEnter += new System.EventHandler(this.CoffePanel_MouseEnter);
            // 
            // coffeeInfoLabel
            // 
            this.coffeeInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.coffeeInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coffeeInfoLabel.ForeColor = System.Drawing.Color.White;
            this.coffeeInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.coffeeInfoLabel.Name = "coffeeInfoLabel";
            this.coffeeInfoLabel.Size = new System.Drawing.Size(244, 150);
            this.coffeeInfoLabel.TabIndex = 7;
            this.coffeeInfoLabel.Text = "Flavourable And Aromatic Coffee. Crafted With Premium Roasted Coffee Beans. Price" +
    ": $1.50\r\n";
            this.coffeeInfoLabel.Visible = false;
            // 
            // coffeeButtonsPanel
            // 
            this.coffeeButtonsPanel.Controls.Add(this.coffeeCountLabel);
            this.coffeeButtonsPanel.Controls.Add(this.coffeeInfoButton);
            this.coffeeButtonsPanel.Controls.Add(this.coffeAddButton);
            this.coffeeButtonsPanel.Controls.Add(this.coffeeRemoveButton);
            this.coffeeButtonsPanel.Location = new System.Drawing.Point(0, 149);
            this.coffeeButtonsPanel.Name = "coffeeButtonsPanel";
            this.coffeeButtonsPanel.Size = new System.Drawing.Size(244, 71);
            this.coffeeButtonsPanel.TabIndex = 6;
            this.coffeeButtonsPanel.Visible = false;
            this.coffeeButtonsPanel.MouseLeave += new System.EventHandler(this.CoffeeButtonsPanel_MouseLeave);
            // 
            // coffeeCountLabel
            // 
            this.coffeeCountLabel.AutoSize = true;
            this.coffeeCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.coffeeCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coffeeCountLabel.ForeColor = System.Drawing.Color.White;
            this.coffeeCountLabel.Location = new System.Drawing.Point(71, 27);
            this.coffeeCountLabel.Name = "coffeeCountLabel";
            this.coffeeCountLabel.Size = new System.Drawing.Size(24, 25);
            this.coffeeCountLabel.TabIndex = 8;
            this.coffeeCountLabel.Text = "0";
            // 
            // coffeeInfoButton
            // 
            this.coffeeInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.coffeeInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.coffeeInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.coffeeInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.coffeeInfoButton.Location = new System.Drawing.Point(188, 22);
            this.coffeeInfoButton.Name = "coffeeInfoButton";
            this.coffeeInfoButton.Size = new System.Drawing.Size(25, 33);
            this.coffeeInfoButton.TabIndex = 4;
            this.coffeeInfoButton.Click += new System.EventHandler(this.CoffeeInfoButton_Click);
            // 
            // coffeAddButton
            // 
            this.coffeAddButton.BackColor = System.Drawing.Color.Transparent;
            this.coffeAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.coffeAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.coffeAddButton.Location = new System.Drawing.Point(108, 17);
            this.coffeAddButton.Name = "coffeAddButton";
            this.coffeAddButton.Size = new System.Drawing.Size(48, 43);
            this.coffeAddButton.TabIndex = 3;
            this.coffeAddButton.Click += new System.EventHandler(this.CoffeAddButton_Click);
            // 
            // coffeeRemoveButton
            // 
            this.coffeeRemoveButton.BackColor = System.Drawing.Color.Transparent;
            this.coffeeRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.coffeeRemoveButton.Enabled = false;
            this.coffeeRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.coffeeRemoveButton.Location = new System.Drawing.Point(14, 15);
            this.coffeeRemoveButton.Name = "coffeeRemoveButton";
            this.coffeeRemoveButton.Size = new System.Drawing.Size(41, 45);
            this.coffeeRemoveButton.TabIndex = 1;
            this.coffeeRemoveButton.Click += new System.EventHandler(this.CoffeeRemoveButton_Click);
            // 
            // teaPanel
            // 
            this.teaPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.tea;
            this.teaPanel.Controls.Add(this.teaInfoLabel);
            this.teaPanel.Controls.Add(this.teaButtonsPanel);
            this.teaPanel.Location = new System.Drawing.Point(499, 325);
            this.teaPanel.Name = "teaPanel";
            this.teaPanel.Size = new System.Drawing.Size(244, 220);
            this.teaPanel.TabIndex = 2;
            this.teaPanel.MouseEnter += new System.EventHandler(this.TeaPanel_MouseEnter);
            // 
            // teaInfoLabel
            // 
            this.teaInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.teaInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teaInfoLabel.ForeColor = System.Drawing.Color.White;
            this.teaInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.teaInfoLabel.Name = "teaInfoLabel";
            this.teaInfoLabel.Size = new System.Drawing.Size(244, 150);
            this.teaInfoLabel.TabIndex = 8;
            this.teaInfoLabel.Text = "An aromatic beverage prepared by pouring hot water over fresh leaves of Camellia " +
    "sinensis.               Price: $1.25\r\n\r\n";
            this.teaInfoLabel.Visible = false;
            // 
            // teaButtonsPanel
            // 
            this.teaButtonsPanel.Controls.Add(this.teaCountLabel);
            this.teaButtonsPanel.Controls.Add(this.teaInfoButton);
            this.teaButtonsPanel.Controls.Add(this.teaAddButton);
            this.teaButtonsPanel.Controls.Add(this.teaRemoveButton);
            this.teaButtonsPanel.Location = new System.Drawing.Point(0, 149);
            this.teaButtonsPanel.Name = "teaButtonsPanel";
            this.teaButtonsPanel.Size = new System.Drawing.Size(244, 71);
            this.teaButtonsPanel.TabIndex = 0;
            this.teaButtonsPanel.Visible = false;
            this.teaButtonsPanel.MouseLeave += new System.EventHandler(this.TeaButtonsPanel_MouseLeave);
            // 
            // teaCountLabel
            // 
            this.teaCountLabel.AutoSize = true;
            this.teaCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.teaCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teaCountLabel.ForeColor = System.Drawing.Color.White;
            this.teaCountLabel.Location = new System.Drawing.Point(70, 26);
            this.teaCountLabel.Name = "teaCountLabel";
            this.teaCountLabel.Size = new System.Drawing.Size(24, 25);
            this.teaCountLabel.TabIndex = 8;
            this.teaCountLabel.Text = "0";
            // 
            // teaInfoButton
            // 
            this.teaInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.teaInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teaInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.teaInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.teaInfoButton.Location = new System.Drawing.Point(185, 24);
            this.teaInfoButton.Name = "teaInfoButton";
            this.teaInfoButton.Size = new System.Drawing.Size(25, 31);
            this.teaInfoButton.TabIndex = 5;
            this.teaInfoButton.Click += new System.EventHandler(this.TeaInfoButton_Click);
            // 
            // teaAddButton
            // 
            this.teaAddButton.BackColor = System.Drawing.Color.Transparent;
            this.teaAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teaAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.teaAddButton.Location = new System.Drawing.Point(102, 15);
            this.teaAddButton.Name = "teaAddButton";
            this.teaAddButton.Size = new System.Drawing.Size(48, 43);
            this.teaAddButton.TabIndex = 3;
            this.teaAddButton.Click += new System.EventHandler(this.TeaAddButton_Click);
            // 
            // teaRemoveButton
            // 
            this.teaRemoveButton.BackColor = System.Drawing.Color.Transparent;
            this.teaRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teaRemoveButton.Enabled = false;
            this.teaRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.teaRemoveButton.Location = new System.Drawing.Point(18, 15);
            this.teaRemoveButton.Name = "teaRemoveButton";
            this.teaRemoveButton.Size = new System.Drawing.Size(41, 45);
            this.teaRemoveButton.TabIndex = 1;
            this.teaRemoveButton.Click += new System.EventHandler(this.TeaRemoveButton_Click);
            // 
            // waterPanel
            // 
            this.waterPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.water;
            this.waterPanel.Controls.Add(this.waterInfoLabel);
            this.waterPanel.Controls.Add(this.waterButtonsPanel);
            this.waterPanel.Location = new System.Drawing.Point(809, 325);
            this.waterPanel.Name = "waterPanel";
            this.waterPanel.Size = new System.Drawing.Size(244, 220);
            this.waterPanel.TabIndex = 2;
            this.waterPanel.MouseEnter += new System.EventHandler(this.WaterPanel_MouseEnter);
            // 
            // waterInfoLabel
            // 
            this.waterInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.waterInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waterInfoLabel.ForeColor = System.Drawing.Color.White;
            this.waterInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.waterInfoLabel.Name = "waterInfoLabel";
            this.waterInfoLabel.Size = new System.Drawing.Size(244, 150);
            this.waterInfoLabel.TabIndex = 9;
            this.waterInfoLabel.Text = "Water.  Stay Hydrated!!! Price: $1.00";
            this.waterInfoLabel.Visible = false;
            // 
            // waterButtonsPanel
            // 
            this.waterButtonsPanel.Controls.Add(this.waterCountLabel);
            this.waterButtonsPanel.Controls.Add(this.waterInfoButton);
            this.waterButtonsPanel.Controls.Add(this.waterAddButton);
            this.waterButtonsPanel.Controls.Add(this.waterRemoveButton);
            this.waterButtonsPanel.Location = new System.Drawing.Point(0, 146);
            this.waterButtonsPanel.Name = "waterButtonsPanel";
            this.waterButtonsPanel.Size = new System.Drawing.Size(244, 74);
            this.waterButtonsPanel.TabIndex = 0;
            this.waterButtonsPanel.MouseLeave += new System.EventHandler(this.WaterButtonsPanel_MouseLeave);
            // 
            // waterCountLabel
            // 
            this.waterCountLabel.AutoSize = true;
            this.waterCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.waterCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.waterCountLabel.ForeColor = System.Drawing.Color.White;
            this.waterCountLabel.Location = new System.Drawing.Point(72, 29);
            this.waterCountLabel.Name = "waterCountLabel";
            this.waterCountLabel.Size = new System.Drawing.Size(24, 25);
            this.waterCountLabel.TabIndex = 8;
            this.waterCountLabel.Text = "0";
            // 
            // waterInfoButton
            // 
            this.waterInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.waterInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.waterInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.waterInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.waterInfoButton.Location = new System.Drawing.Point(187, 25);
            this.waterInfoButton.Name = "waterInfoButton";
            this.waterInfoButton.Size = new System.Drawing.Size(25, 31);
            this.waterInfoButton.TabIndex = 6;
            this.waterInfoButton.Click += new System.EventHandler(this.WaterInfoButton_Click);
            // 
            // waterAddButton
            // 
            this.waterAddButton.BackColor = System.Drawing.Color.Transparent;
            this.waterAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.waterAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.waterAddButton.Location = new System.Drawing.Point(111, 16);
            this.waterAddButton.Name = "waterAddButton";
            this.waterAddButton.Size = new System.Drawing.Size(48, 43);
            this.waterAddButton.TabIndex = 3;
            this.waterAddButton.Click += new System.EventHandler(this.WaterAddButton_Click);
            // 
            // waterRemoveButton
            // 
            this.waterRemoveButton.BackColor = System.Drawing.Color.Transparent;
            this.waterRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.waterRemoveButton.Enabled = false;
            this.waterRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.waterRemoveButton.Location = new System.Drawing.Point(16, 16);
            this.waterRemoveButton.Name = "waterRemoveButton";
            this.waterRemoveButton.Size = new System.Drawing.Size(41, 45);
            this.waterRemoveButton.TabIndex = 1;
            this.waterRemoveButton.Click += new System.EventHandler(this.WaterRemoveButton_Click);
            // 
            // sidePanel
            // 
            this.sidePanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sidePanel.BackgroundImage")));
            this.sidePanel.Controls.Add(this.aboutButton);
            this.sidePanel.Controls.Add(this.label12);
            this.sidePanel.Controls.Add(this.cartButton);
            this.sidePanel.Controls.Add(this.rewardsButton);
            this.sidePanel.Controls.Add(this.signinButton);
            this.sidePanel.Controls.Add(this.menuButton);
            this.sidePanel.Controls.Add(this.specialsButton);
            this.sidePanel.Controls.Add(this.frenchLabel);
            this.sidePanel.Controls.Add(this.englishLabel);
            this.sidePanel.Controls.Add(this.label8);
            this.sidePanel.Controls.Add(this.label6);
            this.sidePanel.Controls.Add(this.label5);
            this.sidePanel.Controls.Add(this.label4);
            this.sidePanel.Controls.Add(this.label3);
            this.sidePanel.Controls.Add(this.label2);
            this.sidePanel.Controls.Add(this.label1);
            this.sidePanel.Controls.Add(this.pscLabel);
            this.sidePanel.Controls.Add(this.maximizeButton);
            this.sidePanel.Controls.Add(this.minimizeButton);
            this.sidePanel.Controls.Add(this.exitButton);
            this.sidePanel.Location = new System.Drawing.Point(0, 0);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(175, 572);
            this.sidePanel.TabIndex = 0;
            this.sidePanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SidePanel_MouseDown);
            this.sidePanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SidePanel_MouseMove);
            this.sidePanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.SidePanel_MouseUp);
            // 
            // aboutButton
            // 
            this.aboutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aboutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.aboutButton.Location = new System.Drawing.Point(37, 423);
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.Size = new System.Drawing.Size(135, 33);
            this.aboutButton.TabIndex = 19;
            this.aboutButton.Text = "About";
            this.aboutButton.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Snow;
            this.label12.Location = new System.Drawing.Point(19, 468);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(135, 1);
            this.label12.TabIndex = 18;
            // 
            // cartButton
            // 
            this.cartButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cartButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cartButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.cartButton.Location = new System.Drawing.Point(52, 366);
            this.cartButton.Name = "cartButton";
            this.cartButton.Size = new System.Drawing.Size(120, 35);
            this.cartButton.TabIndex = 17;
            this.cartButton.Text = "Cart";
            this.cartButton.Click += new System.EventHandler(this.CartButton_Click);
            // 
            // rewardsButton
            // 
            this.rewardsButton.BackColor = System.Drawing.Color.Transparent;
            this.rewardsButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rewardsButton.Enabled = false;
            this.rewardsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rewardsButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.rewardsButton.Location = new System.Drawing.Point(23, 314);
            this.rewardsButton.Name = "rewardsButton";
            this.rewardsButton.Size = new System.Drawing.Size(185, 34);
            this.rewardsButton.TabIndex = 16;
            this.rewardsButton.Text = "Rewards";
            this.rewardsButton.Click += new System.EventHandler(this.RewardsButton_Click);
            // 
            // signinButton
            // 
            this.signinButton.BackColor = System.Drawing.Color.Transparent;
            this.signinButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signinButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signinButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.signinButton.Location = new System.Drawing.Point(39, 257);
            this.signinButton.Name = "signinButton";
            this.signinButton.Size = new System.Drawing.Size(133, 33);
            this.signinButton.TabIndex = 15;
            this.signinButton.Text = "Sign In";
            this.signinButton.Click += new System.EventHandler(this.SigninButton_Click);
            // 
            // menuButton
            // 
            this.menuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuButton.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuButton.Location = new System.Drawing.Point(48, 198);
            this.menuButton.Name = "menuButton";
            this.menuButton.Size = new System.Drawing.Size(106, 35);
            this.menuButton.TabIndex = 14;
            this.menuButton.Text = "Menu";
            this.menuButton.Click += new System.EventHandler(this.MenuButton_Click);
            // 
            // specialsButton
            // 
            this.specialsButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.specialsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialsButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.specialsButton.Location = new System.Drawing.Point(34, 138);
            this.specialsButton.Name = "specialsButton";
            this.specialsButton.Size = new System.Drawing.Size(133, 35);
            this.specialsButton.TabIndex = 13;
            this.specialsButton.Text = "Specials";
            this.specialsButton.Click += new System.EventHandler(this.SpecialButton_Click);
            // 
            // frenchLabel
            // 
            this.frenchLabel.BackColor = System.Drawing.Color.Transparent;
            this.frenchLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.frenchLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frenchLabel.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.frenchLabel.Image = global::RestaurantApplication.Properties.Resources.franceLangOff;
            this.frenchLabel.Location = new System.Drawing.Point(96, 511);
            this.frenchLabel.Name = "frenchLabel";
            this.frenchLabel.Size = new System.Drawing.Size(47, 28);
            this.frenchLabel.TabIndex = 12;
            this.frenchLabel.Click += new System.EventHandler(this.FrenchLabel_Click);
            // 
            // englishLabel
            // 
            this.englishLabel.BackColor = System.Drawing.Color.Transparent;
            this.englishLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.englishLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.englishLabel.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.englishLabel.Image = global::RestaurantApplication.Properties.Resources.EnglishLang;
            this.englishLabel.Location = new System.Drawing.Point(29, 511);
            this.englishLabel.Name = "englishLabel";
            this.englishLabel.Size = new System.Drawing.Size(47, 28);
            this.englishLabel.TabIndex = 11;
            this.englishLabel.Click += new System.EventHandler(this.EnglishLabel_Click);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Image = global::RestaurantApplication.Properties.Resources.verticalline;
            this.label8.Location = new System.Drawing.Point(32, 504);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 45);
            this.label8.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Snow;
            this.label6.Location = new System.Drawing.Point(19, 411);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(135, 1);
            this.label6.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Snow;
            this.label5.Location = new System.Drawing.Point(19, 302);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 1);
            this.label5.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Snow;
            this.label4.Location = new System.Drawing.Point(19, 355);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 1);
            this.label4.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Snow;
            this.label3.Location = new System.Drawing.Point(17, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 1);
            this.label3.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Snow;
            this.label2.Location = new System.Drawing.Point(17, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(135, 1);
            this.label2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Snow;
            this.label1.Location = new System.Drawing.Point(17, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 1);
            this.label1.TabIndex = 5;
            // 
            // pscLabel
            // 
            this.pscLabel.BackColor = System.Drawing.Color.Transparent;
            this.pscLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.pscLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pscLabel.Image = global::RestaurantApplication.Properties.Resources.psLogoSmallerSmaller;
            this.pscLabel.Location = new System.Drawing.Point(33, 24);
            this.pscLabel.Name = "pscLabel";
            this.pscLabel.Size = new System.Drawing.Size(111, 97);
            this.pscLabel.TabIndex = 4;
            this.pscLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // maximizeButton
            // 
            this.maximizeButton.BackColor = System.Drawing.Color.Transparent;
            this.maximizeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.maximizeButton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.maximizeButton.FlatAppearance.BorderSize = 0;
            this.maximizeButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.maximizeButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.maximizeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.maximizeButton.ForeColor = System.Drawing.Color.Transparent;
            this.maximizeButton.Image = global::RestaurantApplication.Properties.Resources.MaximizeButton;
            this.maximizeButton.Location = new System.Drawing.Point(48, 3);
            this.maximizeButton.Name = "maximizeButton";
            this.maximizeButton.Size = new System.Drawing.Size(24, 20);
            this.maximizeButton.TabIndex = 3;
            this.maximizeButton.UseVisualStyleBackColor = false;
            this.maximizeButton.Click += new System.EventHandler(this.MaximizeButton_Click);
            // 
            // minimizeButton
            // 
            this.minimizeButton.BackColor = System.Drawing.Color.Transparent;
            this.minimizeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeButton.FlatAppearance.BorderSize = 0;
            this.minimizeButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.minimizeButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.minimizeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimizeButton.Image = global::RestaurantApplication.Properties.Resources.MinimizeIcon;
            this.minimizeButton.Location = new System.Drawing.Point(26, 3);
            this.minimizeButton.Name = "minimizeButton";
            this.minimizeButton.Size = new System.Drawing.Size(24, 20);
            this.minimizeButton.TabIndex = 2;
            this.minimizeButton.UseVisualStyleBackColor = false;
            this.minimizeButton.Click += new System.EventHandler(this.MinimizeButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Transparent;
            this.exitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exitButton.FlatAppearance.BorderSize = 0;
            this.exitButton.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.exitButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Image = global::RestaurantApplication.Properties.Resources.ExitIcon;
            this.exitButton.Location = new System.Drawing.Point(3, 3);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(24, 20);
            this.exitButton.TabIndex = 1;
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // chickenSaladButtonsPanel
            // 
            this.chickenSaladButtonsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.chickenSaladButtonsPanel.Controls.Add(this.chickenSaladCountLabel);
            this.chickenSaladButtonsPanel.Controls.Add(this.chickenSaladInfoButton);
            this.chickenSaladButtonsPanel.Controls.Add(this.chickenSaladRemoveButton);
            this.chickenSaladButtonsPanel.Controls.Add(this.chickenSaladAddButton);
            this.chickenSaladButtonsPanel.Location = new System.Drawing.Point(0, 149);
            this.chickenSaladButtonsPanel.Name = "chickenSaladButtonsPanel";
            this.chickenSaladButtonsPanel.Size = new System.Drawing.Size(250, 71);
            this.chickenSaladButtonsPanel.TabIndex = 0;
            this.chickenSaladButtonsPanel.Visible = false;
            this.chickenSaladButtonsPanel.MouseLeave += new System.EventHandler(this.ChickenSaladButtonsPanel_MouseLeave);
            // 
            // chickenSaladCountLabel
            // 
            this.chickenSaladCountLabel.AutoSize = true;
            this.chickenSaladCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.chickenSaladCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenSaladCountLabel.ForeColor = System.Drawing.Color.White;
            this.chickenSaladCountLabel.Location = new System.Drawing.Point(72, 26);
            this.chickenSaladCountLabel.Name = "chickenSaladCountLabel";
            this.chickenSaladCountLabel.Size = new System.Drawing.Size(24, 25);
            this.chickenSaladCountLabel.TabIndex = 8;
            this.chickenSaladCountLabel.Text = "0";
            // 
            // chickenSaladInfoButton
            // 
            this.chickenSaladInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.chickenSaladInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chickenSaladInfoButton.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.chickenSaladInfoButton.Image = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.chickenSaladInfoButton.Location = new System.Drawing.Point(191, 24);
            this.chickenSaladInfoButton.Name = "chickenSaladInfoButton";
            this.chickenSaladInfoButton.Size = new System.Drawing.Size(25, 28);
            this.chickenSaladInfoButton.TabIndex = 5;
            this.chickenSaladInfoButton.Click += new System.EventHandler(this.ChickenSaladInfoButton_Click);
            // 
            // chickenSaladRemoveButton
            // 
            this.chickenSaladRemoveButton.BackColor = System.Drawing.Color.Transparent;
            this.chickenSaladRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chickenSaladRemoveButton.Enabled = false;
            this.chickenSaladRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.chickenSaladRemoveButton.Location = new System.Drawing.Point(15, 15);
            this.chickenSaladRemoveButton.Name = "chickenSaladRemoveButton";
            this.chickenSaladRemoveButton.Size = new System.Drawing.Size(41, 45);
            this.chickenSaladRemoveButton.TabIndex = 4;
            this.chickenSaladRemoveButton.Click += new System.EventHandler(this.ChickenSaladRemoveButton_Click);
            // 
            // chickenSaladAddButton
            // 
            this.chickenSaladAddButton.BackColor = System.Drawing.Color.Transparent;
            this.chickenSaladAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chickenSaladAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.chickenSaladAddButton.Location = new System.Drawing.Point(108, 17);
            this.chickenSaladAddButton.Name = "chickenSaladAddButton";
            this.chickenSaladAddButton.Size = new System.Drawing.Size(48, 43);
            this.chickenSaladAddButton.TabIndex = 3;
            this.chickenSaladAddButton.Click += new System.EventHandler(this.ChickenSaladAddButton_Click);
            // 
            // chickenSaladPanel
            // 
            this.chickenSaladPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(131)))), ((int)(((byte)(140)))), ((int)(((byte)(192)))));
            this.chickenSaladPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chickenSaladPanel.BackgroundImage")));
            this.chickenSaladPanel.Controls.Add(this.chickenSaladInfoLabel);
            this.chickenSaladPanel.Controls.Add(this.chickenSaladButtonsPanel);
            this.chickenSaladPanel.Location = new System.Drawing.Point(493, 25);
            this.chickenSaladPanel.Name = "chickenSaladPanel";
            this.chickenSaladPanel.Size = new System.Drawing.Size(250, 220);
            this.chickenSaladPanel.TabIndex = 2;
            this.chickenSaladPanel.MouseEnter += new System.EventHandler(this.ChickenSaladPanel_MouseEnter);
            // 
            // chickenSaladInfoLabel
            // 
            this.chickenSaladInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.chickenSaladInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chickenSaladInfoLabel.ForeColor = System.Drawing.Color.White;
            this.chickenSaladInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.chickenSaladInfoLabel.Name = "chickenSaladInfoLabel";
            this.chickenSaladInfoLabel.Size = new System.Drawing.Size(250, 150);
            this.chickenSaladInfoLabel.TabIndex = 6;
            this.chickenSaladInfoLabel.Text = "A classic salad with chicken, mayonnaise, crisp \r\ncelery, green onion and lettuce" +
    ". Price: $7.55";
            this.chickenSaladInfoLabel.Visible = false;
            // 
            // checkoutButton
            // 
            this.checkoutButton.BackColor = System.Drawing.Color.Transparent;
            this.checkoutButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkoutButton.Enabled = false;
            this.checkoutButton.ForeColor = System.Drawing.Color.White;
            this.checkoutButton.Image = global::RestaurantApplication.Properties.Resources.menuCartAddButton;
            this.checkoutButton.Location = new System.Drawing.Point(526, 253);
            this.checkoutButton.Name = "checkoutButton";
            this.checkoutButton.Size = new System.Drawing.Size(197, 71);
            this.checkoutButton.TabIndex = 10;
            this.checkoutButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkoutButton.Click += new System.EventHandler(this.CheckoutButton_Click);
            // 
            // rewardsUserControl1
            // 
            this.rewardsUserControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.rewardsUserControl1.ForeColor = System.Drawing.Color.Black;
            this.rewardsUserControl1.Location = new System.Drawing.Point(173, 0);
            this.rewardsUserControl1.Name = "rewardsUserControl1";
            this.rewardsUserControl1.Size = new System.Drawing.Size(899, 572);
            this.rewardsUserControl1.TabIndex = 17;
            // 
            // specialsUserControl1
            // 
            this.specialsUserControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.specialsUserControl1.Location = new System.Drawing.Point(453, -347);
            this.specialsUserControl1.Name = "specialsUserControl1";
            this.specialsUserControl1.Size = new System.Drawing.Size(899, 572);
            this.specialsUserControl1.TabIndex = 16;
            // 
            // loginUserControl1
            // 
            this.loginUserControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.loginUserControl1.Location = new System.Drawing.Point(426, 411);
            this.loginUserControl1.MaximumSize = new System.Drawing.Size(899, 572);
            this.loginUserControl1.MinimumSize = new System.Drawing.Size(899, 572);
            this.loginUserControl1.Name = "loginUserControl1";
            this.loginUserControl1.Size = new System.Drawing.Size(899, 572);
            this.loginUserControl1.TabIndex = 15;
            // 
            // cartUserControl1
            // 
            this.cartUserControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.cartUserControl1.Location = new System.Drawing.Point(564, 337);
            this.cartUserControl1.Name = "cartUserControl1";
            this.cartUserControl1.Size = new System.Drawing.Size(899, 572);
            this.cartUserControl1.TabIndex = 14;
            // 
            // aboutUserControl1
            // 
            this.aboutUserControl1.BackColor = System.Drawing.Color.White;
            this.aboutUserControl1.Location = new System.Drawing.Point(175, 0);
            this.aboutUserControl1.Name = "aboutUserControl1";
            this.aboutUserControl1.Size = new System.Drawing.Size(899, 572);
            this.aboutUserControl1.TabIndex = 11;
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1074, 572);
            this.Controls.Add(this.rewardsUserControl1);
            this.Controls.Add(this.specialsUserControl1);
            this.Controls.Add(this.loginUserControl1);
            this.Controls.Add(this.cartUserControl1);
            this.Controls.Add(this.aboutUserControl1);
            this.Controls.Add(this.checkoutButton);
            this.Controls.Add(this.waterPanel);
            this.Controls.Add(this.teaPanel);
            this.Controls.Add(this.coffePanel);
            this.Controls.Add(this.vegetableSoupPanel);
            this.Controls.Add(this.chickenSaladPanel);
            this.Controls.Add(this.tunaSandwichPanel);
            this.Controls.Add(this.sidePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.tunaSandwichPanel.ResumeLayout(false);
            this.tunaButtonsPanel.ResumeLayout(false);
            this.tunaButtonsPanel.PerformLayout();
            this.vegetableSoupPanel.ResumeLayout(false);
            this.vegetableSoupButtonsPanel.ResumeLayout(false);
            this.vegetableSoupButtonsPanel.PerformLayout();
            this.coffePanel.ResumeLayout(false);
            this.coffeeButtonsPanel.ResumeLayout(false);
            this.coffeeButtonsPanel.PerformLayout();
            this.teaPanel.ResumeLayout(false);
            this.teaButtonsPanel.ResumeLayout(false);
            this.teaButtonsPanel.PerformLayout();
            this.waterPanel.ResumeLayout(false);
            this.waterButtonsPanel.ResumeLayout(false);
            this.waterButtonsPanel.PerformLayout();
            this.sidePanel.ResumeLayout(false);
            this.chickenSaladButtonsPanel.ResumeLayout(false);
            this.chickenSaladButtonsPanel.PerformLayout();
            this.chickenSaladPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button minimizeButton;
        private System.Windows.Forms.Button maximizeButton;
        private System.Windows.Forms.Label pscLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label frenchLabel;
        private System.Windows.Forms.Label englishLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label aboutButton;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label menuButton;
        private System.Windows.Forms.Label specialsButton;
        private System.Windows.Forms.Panel tunaSandwichPanel;
        private System.Windows.Forms.Panel vegetableSoupPanel;
        private System.Windows.Forms.Panel coffePanel;
        private System.Windows.Forms.Panel teaPanel;
        private System.Windows.Forms.Panel waterPanel;
        private System.Windows.Forms.Panel tunaButtonsPanel;
        private System.Windows.Forms.Panel chickenSaladButtonsPanel;
        private System.Windows.Forms.Panel chickenSaladPanel;
        private System.Windows.Forms.Panel vegetableSoupButtonsPanel;
        private System.Windows.Forms.Panel coffeeButtonsPanel;
        private System.Windows.Forms.Panel teaButtonsPanel;
        private System.Windows.Forms.Panel waterButtonsPanel;
        private System.Windows.Forms.Label removeSandwichButton;
        private System.Windows.Forms.Label sandwichInfoButton;
        private System.Windows.Forms.Label sandwichInfoLabel;
        private System.Windows.Forms.Label chickenSaladInfoLabel;
        private System.Windows.Forms.Label addSandwichButton;
        private System.Windows.Forms.Label chickenSaladRemoveButton;
        private System.Windows.Forms.Label chickenSaladAddButton;
        private System.Windows.Forms.Label chickenSaladInfoButton;
        private System.Windows.Forms.Label vegetableSoupInfoLabel;
        private System.Windows.Forms.Label vegetableSoupAddButton;
        private System.Windows.Forms.Label vegetableSoupRemoveButton;
        private System.Windows.Forms.Label vegetableSoupInfoButton;
        private System.Windows.Forms.Label coffeeInfoLabel;
        private System.Windows.Forms.Label coffeeInfoButton;
        private System.Windows.Forms.Label coffeAddButton;
        private System.Windows.Forms.Label coffeeRemoveButton;
        private System.Windows.Forms.Label teaInfoButton;
        private System.Windows.Forms.Label teaAddButton;
        private System.Windows.Forms.Label teaRemoveButton;
        private System.Windows.Forms.Label teaInfoLabel;
        private System.Windows.Forms.Label waterInfoLabel;
        private System.Windows.Forms.Label waterInfoButton;
        private System.Windows.Forms.Label waterAddButton;
        private System.Windows.Forms.Label waterRemoveButton;
        private System.Windows.Forms.Label sandwichCountLabel;
        private System.Windows.Forms.Label vegetableSoupCountLabel;
        private System.Windows.Forms.Label coffeeCountLabel;
        private System.Windows.Forms.Label teaCountLabel;
        private System.Windows.Forms.Label waterCountLabel;
        private System.Windows.Forms.Label chickenSaladCountLabel;
        private System.Windows.Forms.Label checkoutButton;
        private AboutUserControl aboutUserControl1;
        private CartUserControl cartUserControl1;
        private LoginUserControl loginUserControl1;
        private SpecialsUserControl specialsUserControl1;
        public System.Windows.Forms.Label rewardsButton;
        public System.Windows.Forms.Label signinButton;
        private RewardsUserControl rewardsUserControl1;
        public System.Windows.Forms.Label cartButton;
    }
}

