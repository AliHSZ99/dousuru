﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantApplication
{
    public partial class RewardsUserControl : UserControl
    {
        // data members/variables.
        private int firstTrioCount;
        private int iceCappuccinoCount;
        private int secondTrioCount;
        private bool isMoved = false;
        private static Account account;


        // constructor.
        public RewardsUserControl()
        {
            InitializeComponent();
            CloseAllPanels();
            CloseAllInfo();
            SetTransparency();

        }

        // Setting transparency in the panels for adding, removing and informations
        private void SetTransparency()
        {
            // transparent panels
            controlPanel1.BackColor = Color.FromArgb(125, Color.Black);
            controlPanel2.BackColor = Color.FromArgb(125, Color.Black);
            controlPanel3.BackColor = Color.FromArgb(125, Color.Black);

            // transparent information labels
            firstTrioInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            iceCappuccinoInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            secondTrioInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
        }

        // this method closes all reward panels with the buttons for add, remove and info.
        private void CloseAllPanels()
        {
            controlPanel1.Hide();
            controlPanel2.Hide();
            controlPanel3.Hide();
        }

        // Closes all info
        private void CloseAllInfo()
        {
            firstTrioInfoLabel.Hide();
            iceCappuccinoInfoLabel.Hide();
            secondTrioInfoLabel.Hide();
        }

        // method that activates when first trio info button is clicked.
        private void FirstTrioInfoButton_Click(object sender, EventArgs e)
        {
            firstTrioInfoLabel.Show();
        }

        // method that activates when ice cap info button is clicked.
        private void IceCappuccinoInfoButton_Click(object sender, EventArgs e)
        {
            iceCappuccinoInfoLabel.Show();
        }

        // method that activates when second trio info button is clicked.
        private void SecondTrioInfoButton_Click(object sender, EventArgs e)
        {
            secondTrioInfoLabel.Show();
        }

        // method shows the first reward panel and hides the rest on mouse enter.
        private void FirstRewardPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel1.Show();
            iceCappuccinoInfoLabel.Hide();
            secondTrioInfoLabel.Hide();
        }

        // method the shows the second reward panel and hides the rest on mouse enter.
        private void SecondRewardPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel2.Show();
            firstTrioInfoLabel.Hide();
            secondTrioInfoLabel.Hide();
        }

        // method that shows the third rewards panel and hides the rest on mouse enter.
        private void ThirdControlPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel3.Show();
            firstTrioInfoLabel.Hide();
            iceCappuccinoInfoLabel.Hide();
        }

        // method that hides the first control panel on mouse leave
        private void ControlPanel1_MouseLeave(object sender, EventArgs e)
        {
            firstTrioInfoLabel.Hide();
            controlPanel1.Hide();
        }

        // method that hides the second control panel on mouse leave.
        private void ControlPanel2_MouseLeave(object sender, EventArgs e)
        {
            iceCappuccinoInfoLabel.Hide();
            controlPanel2.Hide();
        }

        // method that hides the third control panel on mouse leave.
        private void ControlPanel3_MouseLeave(object sender, EventArgs e)
        {
            secondTrioInfoLabel.Hide();
            controlPanel3.Hide();
        }

        // method that will increment count of a food.
        public void IncrementCount(Panel removeButton, Label toIncrementLabel, int objectCount)
        {
            objectCount = Int32.Parse(toIncrementLabel.Text);
            objectCount++;
            toIncrementLabel.Text = objectCount.ToString();
            removeButton.BackgroundImage = Properties.Resources.MinusButton;
            removeButton.Enabled = true;
            addToCartLabel.Enabled = true;
            if (objectCount == 10 && isMoved == false)
            {
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X - 6, toIncrementLabel.Location.Y);
                isMoved = true;
            }
            else if (objectCount == 9 && isMoved == true)
            {
                isMoved = false;
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X + 6, toIncrementLabel.Location.Y);
            }
        }

        // method will decrement count of a food.
        public void DecrementCount(Panel removeButton, Label todecrementLabel, int objectCount)
        {
            objectCount = Int32.Parse(todecrementLabel.Text);

            if (objectCount <= 1)
            {
                removeButton.BackgroundImage = Properties.Resources.MinusZeroButton;
                objectCount--;
                removeButton.Enabled = false;
            }
            else
            {
                objectCount--;
            }

            todecrementLabel.Text = objectCount.ToString();
        }

        // method that will increment first trio by 1 on click.
        private void FirstTrioAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(firstTrioMinusZeroButton, firstTrioCounterLabel, firstTrioCount);
        }

        // method that will decrement first trio count by 1 on click.
        private void FirstTrioMinusZeroButton_Click(object sender, EventArgs e)
        {
            DecrementCount(firstTrioMinusZeroButton, firstTrioCounterLabel, firstTrioCount);
            IsZero();
        }

        // method that will increment ice cap by 1 on click. 
        private void IceCapuccinoAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(iceCappuccinoMinusZeroButton, iceCappuccinoCounterLabel, iceCappuccinoCount);
        }

        // method that will decrement ice cap by 1 on click.
        private void IceCappuccinoMinusZeroButton_Click(object sender, EventArgs e)
        {
            DecrementCount(iceCappuccinoMinusZeroButton, iceCappuccinoCounterLabel, iceCappuccinoCount);
            IsZero();
        }

        // method that will increment second trio by 1 on click.
        private void SecondTrioAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(secondTrioMinusZeroButton, secondTrioCounterLabel, secondTrioCount);
        }

        // method that will decrement second trio by 1 on click.
        private void SecondTrioMinusZeroButton_Click(object sender, EventArgs e)
        {
            DecrementCount(secondTrioMinusZeroButton, secondTrioCounterLabel, secondTrioCount);
            IsZero();
        }

        // method that checks if all counts are 0.
        private void IsZero()
        {
            firstTrioCount = Int32.Parse(firstTrioCounterLabel.Text);
            iceCappuccinoCount = Int32.Parse(iceCappuccinoCounterLabel.Text);
            secondTrioCount = Int32.Parse(secondTrioCounterLabel.Text);


            if (firstTrioCount == 0 && iceCappuccinoCount == 0 && secondTrioCount == 0)
            {
                addToCartLabel.Enabled = false;
            }
            else
            {
                addToCartLabel.Enabled = true;
            }
        }

        // method that retrieves the active account from the activeAccount.json file and returns an Account.
        private Account RetrieveActiveAccount()
        {
            using (StreamReader file = File.OpenText(@"..\Debug\activeAccount.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                Account accounts = (Account)serializer.Deserialize(file, typeof(Account));
                return accounts;
            }
        }

        // method that will update the points of the user when update points label is clicked. 
        private void UpdatePointsLabel_Click(object sender, EventArgs e)
        {
            Account account = RetrieveActiveAccount();

            userNameLabel.Text = account.Username;
            pointsLabel.Text = account.Points.ToString();
        }

        // method that will change the language to french if french flag is selected and when the mouse enters the user control.
        private void RewardsUserControl_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

            if (parentForm.cartButton.Text == "Chariot")
            {
                firstTrioInfoLabel.Text = "Ce spécial est un trio contenant le sandwich au thon et l'eau de notre menu. De plus, nous servons une soupe au poulet exclusive spéciale!";
                secondTrioInfoLabel.Text = "Ce spécial est un trio contenant trois éléments de notre menu: notre délicieuse salade de poulet, notre soupe aux légumes unique et le meilleur café de la ville.";
                iceCappuccinoInfoLabel.Text = "Nos Ice Cappuccino sont les meilleurs de la ville et ne peuvent être bu que si vous êtes un membre qui a 100 points. Il ne ressemble à aucune boisson que vous avez goûtée auparavant!";
                addToCartLabel.Image = Properties.Resources.rewardsCartAddButtonFR;
                updatePointsLabel.Image = Properties.Resources.updatePointsFR;
                userNameLabel.Text = "Utilisateur inconnu";
            }
        }

        // method that inserts a food to an existing list.
        private void InsertToList(List<Food> foods, Label foodCount, int typeOfFood)
        {
            int count = Int32.Parse(foodCount.Text);
            for (int i = 0; i < count; i++)
            {
                switch (typeOfFood)
                {
                    case 1:
                        foods.Add(new Food("Combo 1", 200m));
                        break;
                    case 2:
                        foods.Add(new Food("Ice Cappuccino", 100m));
                        break;
                    case 3:
                        foods.Add(new Food("Combo 2", 200m));
                        break;
                    default:
                        break;
                }
            }
        }

        // method that takes a list of foods that are rewards and adds them to the rewards.json file.
        private void InsertFoodToJsonFile(List<Food> foods)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\rewards.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, foods);
                }
            }
            catch (Exception)
            {
                File.Create("rewards.json");
            }
        }

        // method that retrieves food from a path given and return a Food List.
        private List<Food> RetrieveFoodFromJsonFile(string path)
        {
            try
            {
                using (StreamReader file = File.OpenText(path))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Food> foods = (List<Food>)serializer.Deserialize(file, typeof(List<Food>));
                    return foods;
                }
            }
            catch (Exception)
            {
                return new List<Food>();
            }
        }

        // methotd that insert an Account in the activeAccount.json file.
        private void InsertObjectToJsonFile(Account account)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\activeAccount.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, account);
                }
            }
            catch
            {
                File.Create("activeAccount.json");
            }
        }

        // variables.
        int comboOneCount = 0;
        int iceCapCount = 0;
        int combotwoCount = 0;
        int totalPoints = 0;

        // method that handles the add to cart button on click if it is enabled.
        private void AddToCartLabel_Click(object sender, EventArgs e)
        {
            Account ac = RetrieveActiveAccount();
            int points = ac.Points;

            comboOneCount = Int32.Parse(firstTrioCounterLabel.Text);
            iceCapCount = Int32.Parse(iceCappuccinoCounterLabel.Text);
            combotwoCount = Int32.Parse(secondTrioCounterLabel.Text);

            comboOneCount *= 200;
            iceCapCount *= 100;
            combotwoCount *= 200;
            totalPoints = comboOneCount + iceCapCount + combotwoCount;

            if (points >= totalPoints)
            {
                List<Food> foods = RetrieveFoodFromJsonFile(@"..\Debug\rewards.json");
                InsertToList(foods, firstTrioCounterLabel, 1);
                InsertToList(foods, iceCappuccinoCounterLabel, 2);
                InsertToList(foods, secondTrioCounterLabel, 3);
                InsertFoodToJsonFile(foods);

                ac.Points -= totalPoints;
                InsertObjectToJsonFile(ac);
                if (addToCartLabel.Image == Properties.Resources.rewardsCartAddButtonFR)
                {
                    MessageBox.Show("Bien Ajouté Dans Le Panier!", "Chariot",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                } 
                else
                {
                MessageBox.Show("Added To Cart Successfully!", "Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                if (addToCartLabel.Image == Properties.Resources.rewardsCartAddButtonFR)
                {
                    MessageBox.Show("Vous n'avez pas assez de points...", "Points manquants",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    MessageBox.Show("You do not have enough points...", "Lacking Points",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
