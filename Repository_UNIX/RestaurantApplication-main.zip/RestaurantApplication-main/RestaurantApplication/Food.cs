﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace RestaurantApplication
{
    [Serializable()]
    class Food : ISerializable
    {
        public string Type { get; set; }
        public decimal Price { get; set; }

        public Food(string foodType, decimal foodPrice)
        {
            Type = foodType;
            Price = foodPrice;
        }

        // Method to serialize the objects
        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Type", Type);
            info.AddValue("Price", Price);
        }

        // Method to deserialize or read the objects
        public Food(SerializationInfo info, StreamingContext context)
        {
            Type = (string)info.GetValue("Type", typeof(string));
            Price = (decimal)info.GetValue("Price", typeof(decimal));
        }
    }
}
