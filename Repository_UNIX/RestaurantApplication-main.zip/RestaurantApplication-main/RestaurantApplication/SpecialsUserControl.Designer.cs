﻿
namespace RestaurantApplication
{
    partial class SpecialsUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpecialsUserControl));
            this.cartButton = new System.Windows.Forms.Panel();
            this.thirdSpecialPanel = new System.Windows.Forms.Panel();
            this.controlPanel2 = new System.Windows.Forms.Panel();
            this.flowerCicleButtonsPanel = new System.Windows.Forms.Panel();
            this.flowerSicleCountLabel = new System.Windows.Forms.Label();
            this.flowerSicleAddButton = new System.Windows.Forms.Label();
            this.flowerSicleRemoveButton = new System.Windows.Forms.Label();
            this.flowerCicleInfoButton = new System.Windows.Forms.Panel();
            this.flowerSicleLabel = new System.Windows.Forms.Label();
            this.secondSpecialPanel = new System.Windows.Forms.Panel();
            this.controlPanel3 = new System.Windows.Forms.Panel();
            this.sandwichButtonsPanel = new System.Windows.Forms.Panel();
            this.sandwichAddButton = new System.Windows.Forms.Label();
            this.sandwichCountLabel = new System.Windows.Forms.Label();
            this.sandwichRemoveButton = new System.Windows.Forms.Label();
            this.sandwichInfoButton = new System.Windows.Forms.Panel();
            this.sandwichInfoLabel = new System.Windows.Forms.Label();
            this.firstSpecialPanel = new System.Windows.Forms.Panel();
            this.controlPanel1 = new System.Windows.Forms.Panel();
            this.watermelonButtonsPanel = new System.Windows.Forms.Panel();
            this.watermelonCountLabel = new System.Windows.Forms.Label();
            this.watermelonAddButton = new System.Windows.Forms.Label();
            this.watermelonRemoveButton = new System.Windows.Forms.Label();
            this.watermelonJInfoButton = new System.Windows.Forms.Panel();
            this.watermelonJInfoLabel = new System.Windows.Forms.Label();
            this.thirdSpecialPanel.SuspendLayout();
            this.controlPanel2.SuspendLayout();
            this.flowerCicleButtonsPanel.SuspendLayout();
            this.secondSpecialPanel.SuspendLayout();
            this.controlPanel3.SuspendLayout();
            this.sandwichButtonsPanel.SuspendLayout();
            this.firstSpecialPanel.SuspendLayout();
            this.controlPanel1.SuspendLayout();
            this.watermelonButtonsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // cartButton
            // 
            this.cartButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.cartOffButton;
            this.cartButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cartButton.Enabled = false;
            this.cartButton.Location = new System.Drawing.Point(475, 300);
            this.cartButton.Name = "cartButton";
            this.cartButton.Size = new System.Drawing.Size(252, 71);
            this.cartButton.TabIndex = 3;
            this.cartButton.Click += new System.EventHandler(this.CartButton_Click);
            // 
            // thirdSpecialPanel
            // 
            this.thirdSpecialPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.GrapeJuiceThyme;
            this.thirdSpecialPanel.Controls.Add(this.controlPanel2);
            this.thirdSpecialPanel.Controls.Add(this.flowerSicleLabel);
            this.thirdSpecialPanel.Location = new System.Drawing.Point(324, 401);
            this.thirdSpecialPanel.Name = "thirdSpecialPanel";
            this.thirdSpecialPanel.Size = new System.Drawing.Size(541, 153);
            this.thirdSpecialPanel.TabIndex = 2;
            this.thirdSpecialPanel.MouseEnter += new System.EventHandler(this.ThirdSpecialPanel_MouseEnter);
            // 
            // controlPanel2
            // 
            this.controlPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.controlPanel2.Controls.Add(this.flowerCicleButtonsPanel);
            this.controlPanel2.Controls.Add(this.flowerCicleInfoButton);
            this.controlPanel2.Location = new System.Drawing.Point(0, 76);
            this.controlPanel2.Name = "controlPanel2";
            this.controlPanel2.Size = new System.Drawing.Size(541, 77);
            this.controlPanel2.TabIndex = 1;
            this.controlPanel2.MouseLeave += new System.EventHandler(this.ControlPanel2_MouseLeave);
            // 
            // flowerCicleButtonsPanel
            // 
            this.flowerCicleButtonsPanel.BackColor = System.Drawing.Color.Transparent;
            this.flowerCicleButtonsPanel.Controls.Add(this.flowerSicleCountLabel);
            this.flowerCicleButtonsPanel.Controls.Add(this.flowerSicleAddButton);
            this.flowerCicleButtonsPanel.Controls.Add(this.flowerSicleRemoveButton);
            this.flowerCicleButtonsPanel.Location = new System.Drawing.Point(3, 1);
            this.flowerCicleButtonsPanel.Name = "flowerCicleButtonsPanel";
            this.flowerCicleButtonsPanel.Size = new System.Drawing.Size(293, 74);
            this.flowerCicleButtonsPanel.TabIndex = 1;
            // 
            // flowerSicleCountLabel
            // 
            this.flowerSicleCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.flowerSicleCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowerSicleCountLabel.ForeColor = System.Drawing.Color.Snow;
            this.flowerSicleCountLabel.Location = new System.Drawing.Point(112, 23);
            this.flowerSicleCountLabel.Name = "flowerSicleCountLabel";
            this.flowerSicleCountLabel.Size = new System.Drawing.Size(48, 36);
            this.flowerSicleCountLabel.TabIndex = 4;
            this.flowerSicleCountLabel.Text = "0";
            // 
            // flowerSicleAddButton
            // 
            this.flowerSicleAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowerSicleAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.flowerSicleAddButton.Location = new System.Drawing.Point(198, 17);
            this.flowerSicleAddButton.Name = "flowerSicleAddButton";
            this.flowerSicleAddButton.Size = new System.Drawing.Size(41, 44);
            this.flowerSicleAddButton.TabIndex = 4;
            this.flowerSicleAddButton.Click += new System.EventHandler(this.FlowerSicleAddButton_Click);
            // 
            // flowerSicleRemoveButton
            // 
            this.flowerSicleRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowerSicleRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.flowerSicleRemoveButton.Location = new System.Drawing.Point(19, 17);
            this.flowerSicleRemoveButton.Name = "flowerSicleRemoveButton";
            this.flowerSicleRemoveButton.Size = new System.Drawing.Size(41, 40);
            this.flowerSicleRemoveButton.TabIndex = 4;
            this.flowerSicleRemoveButton.Click += new System.EventHandler(this.FlowerSicleRemoveButton_Click);
            // 
            // flowerCicleInfoButton
            // 
            this.flowerCicleInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.flowerCicleInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.BiggerInfoButton;
            this.flowerCicleInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.flowerCicleInfoButton.Location = new System.Drawing.Point(462, 10);
            this.flowerCicleInfoButton.Name = "flowerCicleInfoButton";
            this.flowerCicleInfoButton.Size = new System.Drawing.Size(58, 59);
            this.flowerCicleInfoButton.TabIndex = 0;
            this.flowerCicleInfoButton.Click += new System.EventHandler(this.FlowerCicleInfoButton_Click);
            // 
            // flowerSicleLabel
            // 
            this.flowerSicleLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.flowerSicleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flowerSicleLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.flowerSicleLabel.Location = new System.Drawing.Point(0, -3);
            this.flowerSicleLabel.Name = "flowerSicleLabel";
            this.flowerSicleLabel.Size = new System.Drawing.Size(541, 79);
            this.flowerSicleLabel.TabIndex = 2;
            this.flowerSicleLabel.Text = "Our special flowercicles! Ingredients include sugar, strawberries, and lots of lo" +
    "ve. <3 Price: $1.25";
            // 
            // secondSpecialPanel
            // 
            this.secondSpecialPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.SecondSpecial;
            this.secondSpecialPanel.Controls.Add(this.controlPanel3);
            this.secondSpecialPanel.Controls.Add(this.sandwichInfoLabel);
            this.secondSpecialPanel.Location = new System.Drawing.Point(324, 19);
            this.secondSpecialPanel.Name = "secondSpecialPanel";
            this.secondSpecialPanel.Size = new System.Drawing.Size(541, 253);
            this.secondSpecialPanel.TabIndex = 1;
            this.secondSpecialPanel.MouseEnter += new System.EventHandler(this.SecondSpecialPanel_MouseEnter);
            // 
            // controlPanel3
            // 
            this.controlPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.controlPanel3.Controls.Add(this.sandwichButtonsPanel);
            this.controlPanel3.Controls.Add(this.sandwichInfoButton);
            this.controlPanel3.Location = new System.Drawing.Point(3, 174);
            this.controlPanel3.Name = "controlPanel3";
            this.controlPanel3.Size = new System.Drawing.Size(538, 79);
            this.controlPanel3.TabIndex = 0;
            this.controlPanel3.MouseLeave += new System.EventHandler(this.ControlPanel3_MouseLeave);
            // 
            // sandwichButtonsPanel
            // 
            this.sandwichButtonsPanel.BackColor = System.Drawing.Color.Transparent;
            this.sandwichButtonsPanel.Controls.Add(this.sandwichAddButton);
            this.sandwichButtonsPanel.Controls.Add(this.sandwichCountLabel);
            this.sandwichButtonsPanel.Controls.Add(this.sandwichRemoveButton);
            this.sandwichButtonsPanel.Location = new System.Drawing.Point(-3, 0);
            this.sandwichButtonsPanel.Name = "sandwichButtonsPanel";
            this.sandwichButtonsPanel.Size = new System.Drawing.Size(293, 79);
            this.sandwichButtonsPanel.TabIndex = 2;
            // 
            // sandwichAddButton
            // 
            this.sandwichAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sandwichAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.sandwichAddButton.Location = new System.Drawing.Point(204, 26);
            this.sandwichAddButton.Name = "sandwichAddButton";
            this.sandwichAddButton.Size = new System.Drawing.Size(38, 42);
            this.sandwichAddButton.TabIndex = 3;
            this.sandwichAddButton.Click += new System.EventHandler(this.SandwichAddButton_Click);
            // 
            // sandwichCountLabel
            // 
            this.sandwichCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.sandwichCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sandwichCountLabel.ForeColor = System.Drawing.Color.Snow;
            this.sandwichCountLabel.Location = new System.Drawing.Point(112, 31);
            this.sandwichCountLabel.Name = "sandwichCountLabel";
            this.sandwichCountLabel.Size = new System.Drawing.Size(48, 36);
            this.sandwichCountLabel.TabIndex = 3;
            this.sandwichCountLabel.Text = "0";
            // 
            // sandwichRemoveButton
            // 
            this.sandwichRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sandwichRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.sandwichRemoveButton.Location = new System.Drawing.Point(22, 26);
            this.sandwichRemoveButton.Name = "sandwichRemoveButton";
            this.sandwichRemoveButton.Size = new System.Drawing.Size(38, 42);
            this.sandwichRemoveButton.TabIndex = 3;
            this.sandwichRemoveButton.Click += new System.EventHandler(this.SandwichRemoveButton_Click);
            // 
            // sandwichInfoButton
            // 
            this.sandwichInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.sandwichInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.BiggerInfoButton;
            this.sandwichInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sandwichInfoButton.Location = new System.Drawing.Point(459, 9);
            this.sandwichInfoButton.Name = "sandwichInfoButton";
            this.sandwichInfoButton.Size = new System.Drawing.Size(58, 59);
            this.sandwichInfoButton.TabIndex = 1;
            this.sandwichInfoButton.Click += new System.EventHandler(this.SandwichInfoButton_Click);
            // 
            // sandwichInfoLabel
            // 
            this.sandwichInfoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.sandwichInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sandwichInfoLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.sandwichInfoLabel.Location = new System.Drawing.Point(2, -2);
            this.sandwichInfoLabel.Name = "sandwichInfoLabel";
            this.sandwichInfoLabel.Size = new System.Drawing.Size(539, 179);
            this.sandwichInfoLabel.TabIndex = 3;
            this.sandwichInfoLabel.Text = "Salad, tomatos, tuna, and bread on both sides to make a delicious sandwich on a s" +
    "unny day! Price: $4.45 ";
            // 
            // firstSpecialPanel
            // 
            this.firstSpecialPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("firstSpecialPanel.BackgroundImage")));
            this.firstSpecialPanel.Controls.Add(this.controlPanel1);
            this.firstSpecialPanel.Controls.Add(this.watermelonJInfoLabel);
            this.firstSpecialPanel.Location = new System.Drawing.Point(34, 19);
            this.firstSpecialPanel.Name = "firstSpecialPanel";
            this.firstSpecialPanel.Size = new System.Drawing.Size(261, 535);
            this.firstSpecialPanel.TabIndex = 0;
            this.firstSpecialPanel.MouseEnter += new System.EventHandler(this.FirstSpecialPanel_MouseEnter);
            // 
            // controlPanel1
            // 
            this.controlPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.controlPanel1.Controls.Add(this.watermelonButtonsPanel);
            this.controlPanel1.Controls.Add(this.watermelonJInfoButton);
            this.controlPanel1.Location = new System.Drawing.Point(0, 418);
            this.controlPanel1.Name = "controlPanel1";
            this.controlPanel1.Size = new System.Drawing.Size(261, 117);
            this.controlPanel1.TabIndex = 0;
            this.controlPanel1.MouseLeave += new System.EventHandler(this.ControlPanel1_MouseLeave);
            // 
            // watermelonButtonsPanel
            // 
            this.watermelonButtonsPanel.BackColor = System.Drawing.Color.Transparent;
            this.watermelonButtonsPanel.Controls.Add(this.watermelonCountLabel);
            this.watermelonButtonsPanel.Controls.Add(this.watermelonAddButton);
            this.watermelonButtonsPanel.Controls.Add(this.watermelonRemoveButton);
            this.watermelonButtonsPanel.Location = new System.Drawing.Point(3, 3);
            this.watermelonButtonsPanel.Name = "watermelonButtonsPanel";
            this.watermelonButtonsPanel.Size = new System.Drawing.Size(191, 111);
            this.watermelonButtonsPanel.TabIndex = 3;
            // 
            // watermelonCountLabel
            // 
            this.watermelonCountLabel.BackColor = System.Drawing.Color.Transparent;
            this.watermelonCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.watermelonCountLabel.ForeColor = System.Drawing.Color.Snow;
            this.watermelonCountLabel.Location = new System.Drawing.Point(77, 47);
            this.watermelonCountLabel.Name = "watermelonCountLabel";
            this.watermelonCountLabel.Size = new System.Drawing.Size(44, 36);
            this.watermelonCountLabel.TabIndex = 4;
            this.watermelonCountLabel.Text = "0";
            // 
            // watermelonAddButton
            // 
            this.watermelonAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.watermelonAddButton.Image = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.watermelonAddButton.Location = new System.Drawing.Point(127, 43);
            this.watermelonAddButton.Name = "watermelonAddButton";
            this.watermelonAddButton.Size = new System.Drawing.Size(38, 40);
            this.watermelonAddButton.TabIndex = 2;
            this.watermelonAddButton.Click += new System.EventHandler(this.WatermelonAddButton_Click);
            // 
            // watermelonRemoveButton
            // 
            this.watermelonRemoveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.watermelonRemoveButton.Image = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.watermelonRemoveButton.Location = new System.Drawing.Point(15, 43);
            this.watermelonRemoveButton.Name = "watermelonRemoveButton";
            this.watermelonRemoveButton.Size = new System.Drawing.Size(41, 40);
            this.watermelonRemoveButton.TabIndex = 0;
            this.watermelonRemoveButton.Click += new System.EventHandler(this.WatermelonRemoveButton_Click);
            // 
            // watermelonJInfoButton
            // 
            this.watermelonJInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.watermelonJInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.BiggerInfoButton;
            this.watermelonJInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.watermelonJInfoButton.Location = new System.Drawing.Point(200, 35);
            this.watermelonJInfoButton.Name = "watermelonJInfoButton";
            this.watermelonJInfoButton.Size = new System.Drawing.Size(58, 59);
            this.watermelonJInfoButton.TabIndex = 2;
            this.watermelonJInfoButton.Click += new System.EventHandler(this.WatermelonJInfoButton_Click);
            // 
            // watermelonJInfoLabel
            // 
            this.watermelonJInfoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.watermelonJInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.watermelonJInfoLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.watermelonJInfoLabel.Location = new System.Drawing.Point(0, -1);
            this.watermelonJInfoLabel.Name = "watermelonJInfoLabel";
            this.watermelonJInfoLabel.Size = new System.Drawing.Size(261, 424);
            this.watermelonJInfoLabel.TabIndex = 1;
            this.watermelonJInfoLabel.Text = "Limited Summer Edition! Since we know a lot of you are going to be outside in the" +
    " heat, we\'ve wonderfully crafted this drink which is made out of watermelon and " +
    "fresh lemonade! Price: $2.75";
            // 
            // SpecialsUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Controls.Add(this.cartButton);
            this.Controls.Add(this.thirdSpecialPanel);
            this.Controls.Add(this.secondSpecialPanel);
            this.Controls.Add(this.firstSpecialPanel);
            this.Name = "SpecialsUserControl";
            this.Size = new System.Drawing.Size(899, 572);
            this.MouseEnter += new System.EventHandler(this.SpecialsUserControl_MouseEnter);
            this.thirdSpecialPanel.ResumeLayout(false);
            this.controlPanel2.ResumeLayout(false);
            this.flowerCicleButtonsPanel.ResumeLayout(false);
            this.secondSpecialPanel.ResumeLayout(false);
            this.controlPanel3.ResumeLayout(false);
            this.sandwichButtonsPanel.ResumeLayout(false);
            this.firstSpecialPanel.ResumeLayout(false);
            this.controlPanel1.ResumeLayout(false);
            this.watermelonButtonsPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel firstSpecialPanel;
        private System.Windows.Forms.Panel secondSpecialPanel;
        private System.Windows.Forms.Panel thirdSpecialPanel;
        private System.Windows.Forms.Panel cartButton;
        private System.Windows.Forms.Panel controlPanel2;
        private System.Windows.Forms.Panel controlPanel3;
        private System.Windows.Forms.Panel controlPanel1;
        private System.Windows.Forms.Label watermelonJInfoLabel;
        private System.Windows.Forms.Label flowerSicleLabel;
        private System.Windows.Forms.Label sandwichInfoLabel;
        private System.Windows.Forms.Panel flowerCicleInfoButton;
        private System.Windows.Forms.Panel sandwichInfoButton;
        private System.Windows.Forms.Panel watermelonJInfoButton;
        private System.Windows.Forms.Panel flowerCicleButtonsPanel;
        private System.Windows.Forms.Panel sandwichButtonsPanel;
        private System.Windows.Forms.Panel watermelonButtonsPanel;
        private System.Windows.Forms.Label watermelonRemoveButton;
        private System.Windows.Forms.Label watermelonAddButton;
        private System.Windows.Forms.Label sandwichAddButton;
        private System.Windows.Forms.Label sandwichCountLabel;
        private System.Windows.Forms.Label sandwichRemoveButton;
        private System.Windows.Forms.Label flowerSicleCountLabel;
        private System.Windows.Forms.Label flowerSicleAddButton;
        private System.Windows.Forms.Label flowerSicleRemoveButton;
        private System.Windows.Forms.Label watermelonCountLabel;
    }
}
