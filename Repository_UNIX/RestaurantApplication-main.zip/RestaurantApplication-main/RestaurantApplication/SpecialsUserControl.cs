﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantApplication
{
    public partial class SpecialsUserControl : UserControl
    {
        // data members/variables.
        private int watermelonJCount = 0;
        private int sandwichCount = 0;
        private int flowerSicleCount = 0;
        private bool moved = false;

        // constructor.
        public SpecialsUserControl()
        {
            InitializeComponent();
            SetTransparency();
            CloseAllInfo();
            CloseAllPanels();
        }

        // method that sets the transparency of panels and labels.
        public void SetTransparency()
        {
            controlPanel1.BackColor = Color.FromArgb(125, Color.Black);
            controlPanel2.BackColor = Color.FromArgb(125, Color.Black);
            controlPanel3.BackColor = Color.FromArgb(125, Color.Black);

            watermelonJInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            sandwichInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            flowerSicleLabel.BackColor = Color.FromArgb(125, Color.Black);
        }

        // method that will hide all conrtol panels.
        private void CloseAllPanels()
        {
            controlPanel1.Hide();
            controlPanel2.Hide();
            controlPanel3.Hide();
        }

        // method that will close all information labels.
        private void CloseAllInfo()
        {
            watermelonJInfoLabel.Hide();
            sandwichInfoLabel.Hide();
            flowerSicleLabel.Hide();
        }

        // method that shows sandwich info when sandwich info button is clicked.
        private void SandwichInfoButton_Click(object sender, EventArgs e)
        {
            if (sandwichInfoLabel.Visible == true)
            {
                sandwichInfoLabel.Visible = false;
            }
            else
            {
                sandwichInfoLabel.Visible = true;
            }
        }

        // method that shows flowercicle info when flowercicle info button is clicked.
        private void FlowerCicleInfoButton_Click(object sender, EventArgs e)
        {
            if (flowerSicleLabel.Visible == true)
            {
                flowerSicleLabel.Visible = false;
            }
            else
            {
                flowerSicleLabel.Visible = true;
            }
        }

        // method that shows watermelon juice info when its info button is clicked.
        private void WatermelonJInfoButton_Click(object sender, EventArgs e)
        {
            if (watermelonJInfoLabel.Visible == true)
            {
               watermelonJInfoLabel.Visible = false;
            }
            else
            {
                watermelonJInfoLabel.Visible = true;
            }
        }

        // method that shows the first control panel and hides the rest.
        private void FirstSpecialPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel1.Show();
            flowerSicleLabel.Hide();
            sandwichInfoLabel.Hide();
        }

        // method that shows the 3rd control panel and hides the other labels.
        private void SecondSpecialPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel3.Show();
            flowerSicleLabel.Hide();
            watermelonJInfoLabel.Hide();
        }

        // method that shows the control panel and hides the other labels.
        private void ThirdSpecialPanel_MouseEnter(object sender, EventArgs e)
        {
            CloseAllPanels();
            controlPanel2.Show();
            watermelonJInfoLabel.Hide();
            sandwichInfoLabel.Hide();
        }

        // method that hides on mouse leave.
        private void ControlPanel1_MouseLeave(object sender, EventArgs e)
        {
            watermelonJInfoLabel.Hide();
            controlPanel1.Hide();
        }

        // method that hides on mouse leave.
        private void ControlPanel2_MouseLeave(object sender, EventArgs e)
        {
            flowerSicleLabel.Hide();
            controlPanel2.Hide();
        }

        // method that hides on mouse leave.
        private void ControlPanel3_MouseLeave(object sender, EventArgs e)
        {
            sandwichInfoLabel.Hide();
            controlPanel3.Hide();
        }

        // method that increments count of a food.
        public void IncrementCount(Label removeButton, Label toIncrementLabel, int objectCount)
        {
            Form parentForm = (this.Parent as Form);
            if (!cartButton.Enabled)
            {
                cartButton.Enabled = true;
                //don't use this if
                if (parentForm.cartButton.Text.Equals("Chariot"))
                {
                    cartButton.BackgroundImage = Properties.Resources.SpecialsAddToCartButtonFR;
                }
                else
                {
                    cartButton.BackgroundImage = Properties.Resources.addToCartButton;
                }
            }
            objectCount = Int32.Parse(toIncrementLabel.Text);
            objectCount++;
            toIncrementLabel.Text = objectCount.ToString();
            removeButton.Image = Properties.Resources.MinusButton;
            removeButton.Enabled = true;

            if (objectCount == 10 && moved == false)
            {
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X - 6, toIncrementLabel.Location.Y);
                moved = true;
            } else if (objectCount == 9 && moved == true)
            {
                moved = false;
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X + 6, toIncrementLabel.Location.Y);
            } 
        }

        // method that will decrement count of a food.
        public void DecrementCount(Label removeButton, Label todecrementLabel, int objectCount)
        {
            objectCount = Int32.Parse(todecrementLabel.Text);

            if (objectCount == 0)
            {
                removeButton.Image = Properties.Resources.MinusZeroButton;
                return;
            }

            if (objectCount <= 1)
            {
                removeButton.Image = Properties.Resources.MinusZeroButton;
                objectCount--;
                removeButton.Enabled = false;
            }
            else
            {
                removeButton.Image = Properties.Resources.MinusButton;
                objectCount--;
            }

            todecrementLabel.Text = objectCount.ToString();
        }

        // method that checks if all foods in the page counts are 0.
        private void IsZero()
        {

            int watermelonJCount = Int32.Parse(watermelonCountLabel.Text);
            int sandwichCount = Int32.Parse(sandwichCountLabel.Text);
            int flowerSicleCount = Int32.Parse(flowerSicleCountLabel.Text);
            Form parentForm = (this.Parent as Form);

            if (sandwichCount == 0 && watermelonJCount == 0 && flowerSicleCount == 0)
            { 
                if (parentForm.cartButton.Text.Equals("Chariot"))
                {
                    cartButton.BackgroundImage = Properties.Resources.SpecialsaddToCartButtonOffFR;   
                } else
                {
                    cartButton.BackgroundImage = Properties.Resources.cartOffButton;   
                }
                cartButton.Enabled = false;
            }
            else
            {
                cartButton.Enabled = true;
                if (parentForm.cartButton.Text.Equals("Chariot"))
                {
                    cartButton.BackgroundImage = Properties.Resources.SpecialsAddToCartButtonFR;
                }
                else
                {
                    cartButton.BackgroundImage = Properties.Resources.addToCartButton;
                }
            }
        }

        // method the increments watermelon count by 1 on click of the watermelon.
        private void WatermelonAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(watermelonRemoveButton, watermelonCountLabel, watermelonJCount);
        }

        // method that decrements watermelon count by 1 on click of the add button for the sicle.
        private void FlowerSicleAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(flowerSicleRemoveButton, flowerSicleCountLabel, flowerSicleCount);
        }

        // method that increments sandwich count by 1 by clicking the sandwich add button.
        private void SandwichAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(sandwichRemoveButton, sandwichCountLabel, sandwichCount);
        }

        // method that decrements watermelon count by 1 when the remove button watermelon is clicked.
        private void WatermelonRemoveButton_Click(object sender, EventArgs e)
        {
            DecrementCount(watermelonRemoveButton, watermelonCountLabel, watermelonJCount);
            IsZero();
        }

        // method that decrements sandwich by 1 when sandwich remove button is clicked.
        private void SandwichRemoveButton_Click(object sender, EventArgs e)
        {
            DecrementCount(sandwichRemoveButton, sandwichCountLabel, sandwichCount);
            IsZero();
        }

        // method that decrements flowersicle by 1 when flowersicle remove button is clicked.
        private void FlowerSicleRemoveButton_Click(object sender, EventArgs e)
        {
            DecrementCount(flowerSicleRemoveButton, flowerSicleCountLabel, flowerSicleCount);
            IsZero();
        }

        // methot that inserts a special food to an existing list.
        private void InsertToList(List<Food> foods, Label foodCount, int typeOfFood)
        {
            int count = Int32.Parse(foodCount.Text);
            for (int i = 0; i < count; i++)
            {
                switch (typeOfFood)
                {
                    case 1:
                        foods.Add(new Food("Watermelon Drink", 2.75m));
                        break;
                    case 2:
                        foods.Add(new Food("Sandwich", 4.45m));
                        break;
                    case 3:
                        foods.Add(new Food("Flowersicle", 1.25m));
                        break;
                    default:
                        break;
                }
            }
        }

        // method that retrieves foods from json file based on path argument and return a Food List.
        private List<Food> RetrieveFoodFromJsonFile(string path)
        {
            try
            {
                using (StreamReader file = File.OpenText(path))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Food> foods = (List<Food>)serializer.Deserialize(file, typeof(List<Food>));
                    return foods;
                }
            }
            catch (Exception)
            {
                return new List<Food>();
            }
        }

        // method that add the items to the cart by adding everything to food json file.
        private void CartButton_Click(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);
            List<Food> foods = RetrieveFoodFromJsonFile(@"..\Debug\food.json");
            InsertToList(foods, sandwichCountLabel, 2);
            InsertToList(foods, watermelonCountLabel, 1);
            InsertToList(foods, flowerSicleCountLabel, 3);
            InsertFoodToJsonFile(foods);

            if (parentForm.cartButton.Text == "Chariot")
            {
                MessageBox.Show("Ajouté avec succès", "Chariot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cartButton.BackgroundImage = Properties.Resources.SpecialsaddToCartButtonOffFR;
                ResetFoodCount();
            }
            else
            {
                MessageBox.Show("Added Successfully", "Cart", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cartButton.BackgroundImage = Properties.Resources.cartOffButton;
                ResetFoodCount();
            }
        }

        // method that resets the food counts.
        public void ResetFoodCount()
        {
            flowerSicleCountLabel.Text = "0";
            sandwichCountLabel.Text = "0";
            watermelonCountLabel.Text = "0";
            flowerSicleRemoveButton.Enabled = false;
            sandwichRemoveButton.Enabled = false;
            watermelonRemoveButton.Enabled = false;
        }

        // method that insert List of Food into the food.json file.
        private void InsertFoodToJsonFile(List<Food> foods)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\food.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, foods);
                }
            }
            catch (Exception)
            {
                File.Create("food.json");
            }
        }

        // method that changes the language to french if the french flag is selected and on mouse enter in the user control.
        private void SpecialsUserControl_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

                if (parentForm.cartButton.Text.Equals("Chariot")) { 
                    IsZero();
                    cartButton.Width = 363;
                cartButton.Location = new Point
            (475 - 50, cartButton.Location.Y);
                watermelonJInfoLabel.Text = "Édition limitée d'été! Puisque nous savons que beaucoup d'entre vous vont être dehors dans la chaleur, nous avons merveilleusement conçu cette boisson à base de pastèque et de limonade fraîche! Prix: $2.75";
                    sandwichInfoLabel.Text = "Salade, tomates, thon et pain des deux côtés pour faire un délicieux sandwich par une journée ensoleillée! Prix: $4.45";
                    flowerSicleLabel.Text = "Nos fleurettes spéciales! Les ingrédients comprennent le sucre, les fraises et beaucoup d'amour. <3 Prix: $1.25";
                            
                }
        }
    }
}
