﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantApplication
{
    public partial class AboutUserControl : UserControl
    {

        // constructor. 
        public AboutUserControl()
        {
            InitializeComponent();
        }

        // the mouse enter method to change the language to french.
        private void AboutUserControl_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

            if (parentForm.cartButton.Text == "Chariot")
            {
                jeremieLabel.Image = Properties.Resources.JeremieAboutFR;
                aliLabel.Image = Properties.Resources.AliAboutFR;
                vincentLabel.Image = Properties.Resources.VincentAboutFR;
                usLabel.Image = Properties.Resources.BoysAndAppAboutFR;
            }
        }
    }
}
