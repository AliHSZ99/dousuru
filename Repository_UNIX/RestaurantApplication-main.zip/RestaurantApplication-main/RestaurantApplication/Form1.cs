﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;
using System.Globalization;
using System.Threading;


namespace RestaurantApplication
{
    public partial class Form : System.Windows.Forms.Form
    {
        // data members and variables.
        public Form ParentForm { get; set; }
        int sandwichCount = 0;
        int chickenSaladCount = 0;
        int vegetableSoupCount = 0;
        int coffeeCount = 0;
        int teaCount = 0;
        int waterCount = 0;
        private bool isMoved = false;
        public bool isLoggedIn = true;
        public bool isFrench = false;

        //Method that set all the Panels into a transparent.
        public void SetTransparency()
        {
            tunaButtonsPanel.BackColor = Color.FromArgb(125, Color.Black);
            chickenSaladButtonsPanel.BackColor = Color.FromArgb(140, Color.Black);
            vegetableSoupButtonsPanel.BackColor = Color.FromArgb(125, Color.Black);
            coffeeButtonsPanel.BackColor = Color.FromArgb(125, Color.Black);
            teaButtonsPanel.BackColor = Color.FromArgb(125, Color.Black);
            waterButtonsPanel.BackColor = Color.FromArgb(125, Color.Black);
            sandwichInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            chickenSaladInfoLabel.BackColor = Color.FromArgb(140, Color.Black);
            vegetableSoupInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            coffeeInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            teaInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
            waterInfoLabel.BackColor = Color.FromArgb(125, Color.Black);
        }

        // The Form Constructor.
        public Form()
        {
            InitializeComponent();
            SetTransparency();
            CloseAllPanels();
             rewardsUserControl1.Location = new Point(175, 2);
            cartUserControl1.Location = new Point(175, 2);
            loginUserControl1.Location = new Point(175, 2);
            specialsUserControl1.Location = new Point(175, 2);
            specialsUserControl1.Show();
        }

        // Method that closes the application when the red button is clicked.
        private void ExitButton_Click(object sender, EventArgs e)
        {
            try
            {
                File.Delete("food.json");
                File.Delete("rewards.json");
                File.Delete("activeAccount.json");
                Application.Exit();
            }
            catch (Exception)
            {
                Application.Exit();
            }
        }

        // Method that minimizes the application when the yellow button is clicked.
        private void MinimizeButton_Click(object sender, EventArgs e)
        {
                this.WindowState = FormWindowState.Minimized;
        }

        // Method that maximizes the application when the green button is clicked. 
        private void MaximizeButton_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
            }
        }

        // data members that will be used to drag the form around.
        private bool mouseDown;
        private Point lastLocation;

        //The following are methods to allow users to drag the form arround.
        // Mouse Down for form.
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        // Mouse Move for form.
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        // Mouse Up for Form.
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        // Mouse Down for side panel.
        private void SidePanel_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastLocation = e.Location;
        }

        // Mouse Up for side panel.
        private void SidePanel_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }

        // Mouse Move for side panel.
        private void SidePanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastLocation.X) + e.X, (this.Location.Y - lastLocation.Y) + e.Y);

                this.Update();
            }
        }

        // Method that checks if the Mouse is inside the tunaSanwich Panel.
        private void TunaSandwichPanel_MouseEnter_1(object sender, EventArgs e)
        {
            tunaButtonsPanel.Show();
            chickenSaladButtonsPanel.Hide();
            coffeeButtonsPanel.Hide();
            teaButtonsPanel.Hide();
            waterButtonsPanel.Hide();
        }

        //Method that checks if the Mouse leaves the TunaButton Panel.
        private void TunaButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            tunaButtonsPanel.Hide();
            sandwichInfoLabel.Hide();
        }

        // Method that checks if the Mouse enters the Chicken Salad panel.
        private void ChickenSaladPanel_MouseEnter(object sender, EventArgs e)
        {
            tunaButtonsPanel.Hide();
            vegetableSoupButtonsPanel.Hide();
            chickenSaladButtonsPanel.Show();
            coffeeButtonsPanel.Hide();
            teaButtonsPanel.Hide();
            waterButtonsPanel.Hide();
        }

        // Method that checks if the mouse leave the chicken salad buttons panel.
        private void ChickenSaladButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            chickenSaladButtonsPanel.Hide();
            chickenSaladInfoLabel.Hide();
        }

        // method that checks if the mouse enters the vegetable soup panel.
        private void VegetableSoupPanel_MouseEnter(object sender, EventArgs e)
        {
            chickenSaladButtonsPanel.Hide();
            vegetableSoupButtonsPanel.Show();
            teaButtonsPanel.Hide();
            waterButtonsPanel.Hide();

        }

        // method that checks if the mouse leaves the vegetable soup buttons panel.
        private void VegetableSoupButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            vegetableSoupButtonsPanel.Hide();
            vegetableSoupInfoLabel.Hide();
        }

        // method that checks if the mouse enters the coffee panel.
        private void CoffePanel_MouseEnter(object sender, EventArgs e)
        {
            coffeeButtonsPanel.Show();
            teaButtonsPanel.Hide();
        }

        // method that checks if the mouse leaves the coffee buttons panel.
        private void CoffeeButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            coffeeButtonsPanel.Hide();
            coffeeInfoLabel.Hide();
        }

        // method that checks if the mouse enters the tea panel.
        private void TeaPanel_MouseEnter(object sender, EventArgs e)
        {
            coffeeButtonsPanel.Hide();
            teaButtonsPanel.Show();
            waterButtonsPanel.Hide();

        }

        // method that checks if the mouse leaves the tea buttons panel.
        private void TeaButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            teaButtonsPanel.Hide();
            teaInfoLabel.Hide();
        }

        // method that checks if the mouse leave the water buttons panel
        private void WaterButtonsPanel_MouseLeave(object sender, EventArgs e)
        {
            waterButtonsPanel.Hide();
            waterInfoLabel.Hide();
        }

        // method that checks if the mouse enters the water panel
        private void WaterPanel_MouseEnter(object sender, EventArgs e)
        {
            waterButtonsPanel.Show();
            teaButtonsPanel.Hide();
        }

        // Method that shows sandwich info if the info button is clicked.
        private void SandwichInfoButton_Click(object sender, EventArgs e)
        {
            if (sandwichInfoLabel.Visible == true)
            {
                sandwichInfoLabel.Visible = false;
            } else
            {
                sandwichInfoLabel.Visible = true;
            }
        }

        // method that shows the chicken salad info if the info button is clicked. 
        private void ChickenSaladInfoButton_Click(object sender, EventArgs e)
        {
            if (chickenSaladInfoLabel.Visible == true)
            {
                chickenSaladInfoLabel.Visible = false;
            }
            else
            {
                chickenSaladInfoLabel.Visible = true;
            }
        }

        // method shows vegetable soup info if the vegetable soup info button is clicked.
        private void VegetableSoupInfoButton_Click(object sender, EventArgs e)
        {
            if (vegetableSoupInfoLabel.Visible == true)
            {
                vegetableSoupInfoLabel.Visible = false;
            }
            else
            {
                vegetableSoupInfoLabel.Visible = true;
            }

        }

        // method that shows the coffee info when the info button is clicked.
        private void CoffeeInfoButton_Click(object sender, EventArgs e)
        {
            if (coffeeInfoLabel.Visible == true)
            {
                coffeeInfoLabel.Visible = false;
            }
            else
            {
                coffeeInfoLabel.Visible = true;
            }
        }

        // method that shows tea info when tea info button is clicked. 
        private void TeaInfoButton_Click(object sender, EventArgs e)
        {
            if (teaInfoLabel.Visible == true)
            {
                teaInfoLabel.Visible = false;
            }
            else
            {
                teaInfoLabel.Visible = true;
            }
        }

        // method that shows water info when water info is clicked. 
        private void WaterInfoButton_Click(object sender, EventArgs e)
        {
            if (waterInfoLabel.Visible == true)
            {
                waterInfoLabel.Visible = false;
            }
            else
            {
                waterInfoLabel.Visible = true;
            }
        }

        // Add a food count. This method is used to place the food counts well and to increment their counts.
        public void IncrementCount(Label removeButton,Label toIncrementLabel, int objectCount) {
            objectCount = Int32.Parse(toIncrementLabel.Text);
            objectCount++;
            toIncrementLabel.Text = objectCount.ToString();
            removeButton.Image = Properties.Resources.MinusButton;
            removeButton.Enabled = true;
            checkoutButton.Enabled = true;
            if (objectCount == 10 && isMoved == false)
            {
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X - 6, toIncrementLabel.Location.Y);
                isMoved = true;
            }
            else if (objectCount == 9 && isMoved == true)
            {
                isMoved = false;
                toIncrementLabel.Location = new Point(toIncrementLabel.Location.X + 6, toIncrementLabel.Location.Y);
            }
        }

        // Check if all the food count is 0 
        private void IsZero()
        {
            int sandwichCount = Int32.Parse(sandwichCountLabel.Text);
            int chickenSaladCount = Int32.Parse(chickenSaladCountLabel.Text);
            int vegetableSoupCount = Int32.Parse(vegetableSoupCountLabel.Text);
            int coffeeCount = Int32.Parse(coffeeCountLabel.Text);
            int teaCount = Int32.Parse(teaCountLabel.Text);
            int waterCount = Int32.Parse(waterCountLabel.Text);


            if (sandwichCount == 0 && chickenSaladCount == 0 && vegetableSoupCount == 0 && coffeeCount == 0 && teaCount == 0 && waterCount == 0)
            {
                checkoutButton.Enabled = false;
            } else
            {
                checkoutButton.Enabled = true;
            }
        }

        // Removes a food count.
        public void DecremmentCount(Label removeButton, Label todecrementLabel, int objectCount)
        {
            objectCount = Int32.Parse(todecrementLabel.Text);

            if (objectCount == 0)
            {
                removeButton.Image = Properties.Resources.MinusZeroButton;
                return;
            }

            if (objectCount <= 1)
            {
                removeButton.Image = Properties.Resources.MinusZeroButton;
                objectCount--;
                removeButton.Enabled = false;
            } else
            {
                objectCount--;
            }
            todecrementLabel.Text = objectCount.ToString();
           
        }

        // method that increments the sandwich count by 1 when the add sandwich button is clicked. 
        private void AddSandwichButton_Click(object sender, EventArgs e)
        {
            IncrementCount(removeSandwichButton, sandwichCountLabel, sandwichCount);
        }

        // method that decrements the sandwich count by 1 when the remove sandwich button is clicked. 
        private void RemoveSandwichButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(removeSandwichButton, sandwichCountLabel, sandwichCount);
            IsZero();
        }

        // method that increments the chicken salad count by 1 when the chicken salad add button is clicked.
        private void ChickenSaladAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(chickenSaladRemoveButton, chickenSaladCountLabel, chickenSaladCount);
        }

        // method that decrements the chicken salad count by 1 when the chicken salad remove button is clicked. 
        private void ChickenSaladRemoveButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(chickenSaladRemoveButton, chickenSaladCountLabel, chickenSaladCount);
            IsZero();
        }

        // method that increments vegetables soup count by 1 when the vegetable soup add button is clicked. 
        private void VegetableSoupAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(vegetableSoupRemoveButton, vegetableSoupCountLabel, vegetableSoupCount);
        }

        // method that decrements vegetable soup count by 1 when the vegetable soup remove button is clicked. 
        private void VegetableSoupRemoveButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(vegetableSoupRemoveButton, vegetableSoupCountLabel, vegetableSoupCount);
            IsZero();
        }

        // method that increments the coffee count by 1 when coffee add button is clicked. 
        private void CoffeAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(coffeeRemoveButton, coffeeCountLabel, coffeeCount);
        }

        // method that decrements the coffe count by 1 when coffee remove button is clicked.
        private void CoffeeRemoveButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(coffeeRemoveButton, coffeeCountLabel, coffeeCount);
            IsZero();

        }

        // method that increments tea count by 1 when tea add button is clicked. 
        private void TeaAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(teaRemoveButton, teaCountLabel, teaCount);
        }

        // method that decrements tea count by 1 when tea remove button is clicked.
        private void TeaRemoveButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(teaRemoveButton, teaCountLabel, teaCount);
            IsZero();
        }

        // method that increments water count by 1 when water add button is clicked. 
        private void WaterAddButton_Click(object sender, EventArgs e)
        {
            IncrementCount(waterRemoveButton, waterCountLabel, waterCount);
        }

        // method that decrements water count by 1 when water remove button is clicked. 
        private void WaterRemoveButton_Click(object sender, EventArgs e)
        {
            DecremmentCount(waterRemoveButton, waterCountLabel, waterCount);
            IsZero();
        }

        // Method to insert all the food objects in a list 
        private void InsertToList(List<Food> foods, Label foodCount, int typeOfFood)
        {
            int count = Int32.Parse(foodCount.Text);
            for (int i = 0; i < count; i++)
            {
                switch (typeOfFood)
                {
                    case 1:
                        foods.Add(new Food("Tuna Sandwich", 8.75m));
                        break;
                    case 2:
                        foods.Add(new Food("Chicken Salad", 7.55m));
                        break;
                    case 3:
                        foods.Add(new Food("Vegetable Soup", 8.25m));
                        break;
                    case 4:
                        foods.Add(new Food("Coffee", 1.50m));
                        break;
                    case 5:
                        foods.Add(new Food("Tea", 1.25m));
                        break;
                    case 6:
                        foods.Add(new Food("Water", 1.00m));
                        break;
                    default:
                        break;
                }
            }
        }

        // Method that inserts a list of foods to a JSON file called food.json.
        private void InsertFoodToJsonFile(List<Food> foods)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\food.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, foods);
                }
            }

            catch (Exception)
            {
                File.Create("food.json");
            }
        }
        
        // Insert List of Account Into A Json File inside a file called accounts.json.
        private void InsertListToJsonFile(List<Account> accounts)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\accounts.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, accounts);
                }
            }

            catch (Exception)
            {
                File.Create("accounts.json");
            }
        }

        // method that retrieves foods from a json file and returns a List of Food.
        private List<Food> RetrieveFoodFromJsonFile(string path)
        {

            try
            {
                using (StreamReader file = File.OpenText(path))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Food> foods = (List<Food>)serializer.Deserialize(file, typeof(List<Food>));
                    return foods;
                }
            }
            catch (Exception)
            {
                return new List<Food>();
            }
        } 

        // Checks out all the food. This method will insert all the selected foods inside the Food.ser file. 
        // This file will store all the informations about the food such as the name quantity and price of the food. 
        // If theres an active user, this method will also update the 
        private void CheckoutButton_Click(object sender, EventArgs e)
        {
            List<Food> foods = RetrieveFoodFromJsonFile(@"..\Debug\food.json");
            InsertToList(foods, sandwichCountLabel, 1);
            InsertToList(foods, chickenSaladCountLabel, 2);
            InsertToList(foods, vegetableSoupCountLabel, 3);
            InsertToList(foods, coffeeCountLabel, 4);
            InsertToList(foods, teaCountLabel, 5);
            InsertToList(foods, waterCountLabel, 6);
            InsertFoodToJsonFile(foods);

            if (cartButton.Text == "Chariot")
            {
                MessageBox.Show("Ajouté avec succès", "Chariot", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetFoodCount();
            } else
            {
                MessageBox.Show("Added Successfully", "Cart", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetFoodCount();
            }
        }

        // Resets the food count labels for menu items.
        public void ResetFoodCount()
        {
            sandwichCountLabel.Text = "0";
            chickenSaladCountLabel.Text = "0";
            vegetableSoupCountLabel.Text = "0";
            waterCountLabel.Text = "0";
            teaCountLabel.Text = "0";
            coffeeCountLabel.Text = "0";
            checkoutButton.Enabled = false;
            removeSandwichButton.Enabled = false;
            chickenSaladRemoveButton.Enabled = false;
            vegetableSoupRemoveButton.Enabled = false;
            teaRemoveButton.Enabled = false;
            coffeeRemoveButton.Enabled = false;
            waterRemoveButton.Enabled = false;
        }

        // A method that close all the panels.
        private void CloseAllPanels()
        {
            loginUserControl1.Hide();
            aboutUserControl1.Hide();
            rewardsUserControl1.Hide();
            cartUserControl1.Hide();
            specialsUserControl1.Hide();
            HideMenu();
        }

        // method that changes label colors to white.
        private void ChangeAllLabelsColor()
        {
            signinButton.ForeColor = Color.White;
            rewardsButton.ForeColor = Color.White;
            specialsButton.ForeColor = Color.White;
            menuButton.ForeColor = Color.White;
            cartButton.ForeColor = Color.White;
            aboutButton.ForeColor = Color.White;
        }

        // method that hides the menu so other user controls can be displayed.
        private void HideMenu()
        {
            tunaSandwichPanel.Hide();
            chickenSaladPanel.Hide();
            vegetableSoupPanel.Hide();
            coffePanel.Hide();
            teaPanel.Hide();
            waterPanel.Hide();
            checkoutButton.Hide();
        }

        // method that shows the menu.
        private void ShowMenu()
        {
            tunaSandwichPanel.Show();
            chickenSaladPanel.Show();
            vegetableSoupPanel.Show();
            coffePanel.Show();
            teaPanel.Show();
            waterPanel.Show();
            checkoutButton.Show();
        }

        // method that opens the menu when the menu button is clicked. 
        private void MenuButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            ShowMenu();
            menuButton.ForeColor = Color.FromArgb(207, 189, 125);

        }

        // method that opens the about page when the about page is clicked. 
        private void AboutButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            aboutUserControl1.Show();
            aboutButton.ForeColor = Color.FromArgb(207, 189, 125);
        }

        // method that opens the sign in page when the sign in button is clicked. 
        private void SigninButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            loginUserControl1.Show();
            signinButton.ForeColor = Color.FromArgb(207, 189, 125);

            if (signinButton.Text == "Sign Out" || signinButton.Text == "Déconnexion")
            {
                rewardsButton.Enabled = false;
                File.Delete("activeAccount.json");
                Application.Restart();
            }

            isLoggedIn = true;
        }

        // method that opens the rewards page if it is enabled and clicked. 
        private void RewardsButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            rewardsUserControl1.Show();
            rewardsButton.ForeColor = Color.FromArgb(207, 189, 125);
        }

        // method that opens the cart page when the Cart button is clicked. 
        private void CartButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            cartUserControl1.Show();
            cartButton.ForeColor = Color.FromArgb(207, 189, 125);
        }

        // method that opens the Specials page when the Specials button is clicked. 
        private void SpecialButton_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            ChangeAllLabelsColor();
            specialsUserControl1.Show();
            specialsButton.ForeColor = Color.FromArgb(207, 189, 125);
        }

        // method that change the language when the French flag label is clicked. 
        private void FrenchLabel_Click(object sender, EventArgs e)
        {
            specialsButton.Text = "Spéciaux";
            rewardsButton.Text = "Récompenses";
            if (signinButton.Text == "Sign Out")
            {
                signinButton.Location = new Point(4, 257);
                signinButton.Width = 200;
                signinButton.Text = "Déconnexion";
            } else
            {
                signinButton.Text = "Connexion";
                signinButton.Location = new Point
                (39 - 24, signinButton.Location.Y);
                signinButton.Width = 200;
            }
            cartButton.Text = "Chariot";
            aboutButton.Text = "À propos";
            frenchLabel.Image = Properties.Resources.frenchLang;
            isFrench = true;

            specialsButton.Location = new Point
                (34 - 10, specialsButton.Location.Y);
            rewardsButton.Location = new Point
                (23 - 10, rewardsButton.Location.Y);
            cartButton.Location = new Point
                (52 - 15, cartButton.Location.Y);
            aboutButton.Location = new Point
                (37 - 9, aboutButton.Location.Y);
            rewardsButton.Font = new Font("Microsoft Sans Serif", 16);
            englishLabel.Image = Properties.Resources.EnglishLangOff;
            checkoutButton.Image = Properties.Resources.menuAddToCartFRButton;
            checkoutButton.Width = 270;
            checkoutButton.Location = new Point
                (checkoutButton.Location.X - 40, checkoutButton.Location.Y);

            chickenSaladInfoLabel.Text = "Une salade classique avec du poulet, de la mayonnaise, du céleri croquant, de l'oignon vert et de la laitue. Prix: $7.55";
            sandwichInfoLabel.Text = "Un sandwich à base de thon en conserve. Combiné avec de la mayonnaise, du céleri et de la tomate. Prix: $8.75";
            vegetableSoupInfoLabel.Text = "Une soupe préparée avec du céleri, des carottes, des oignons, du brocoli et de l'eau. Prix: $8.25";
            waterInfoLabel.Text = "L'eau. Restez hydraté!!!     Prix: $1.00";
            teaInfoLabel.Text = "Une boisson aromatique préparée en versant de l'eau chaude sur des feuilles fraîches de Camellia sinensis Prix: $1.50";
            coffeeInfoLabel.Text = "Café savoureux et aromatique. Fabriqué avec des grains de café torréfiés de première qualité.            Prix: $1.25";
        }

        // method that switched the language to english when the english label is clicked.
        private void EnglishLabel_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}