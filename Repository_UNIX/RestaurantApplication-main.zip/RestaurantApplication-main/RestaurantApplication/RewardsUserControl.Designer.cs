﻿
namespace RestaurantApplication
{
    partial class RewardsUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.updatePointsLabel = new System.Windows.Forms.Label();
            this.addToCartLabel = new System.Windows.Forms.Label();
            this.thirdControlPanel = new System.Windows.Forms.Panel();
            this.secondTrioInfoLabel = new System.Windows.Forms.Label();
            this.controlPanel3 = new System.Windows.Forms.Panel();
            this.secondTrioMinusZeroButton = new System.Windows.Forms.Panel();
            this.secondTrioPointsLabel = new System.Windows.Forms.Label();
            this.secondTrioInfoButton = new System.Windows.Forms.Panel();
            this.secondTrioCounterLabel = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.secondTrioAddButton = new System.Windows.Forms.Panel();
            this.secondRewardPanel = new System.Windows.Forms.Panel();
            this.iceCappuccinoInfoLabel = new System.Windows.Forms.Label();
            this.controlPanel2 = new System.Windows.Forms.Panel();
            this.iceCappuccinoMinusZeroButton = new System.Windows.Forms.Panel();
            this.iceCappuccinoPointsLabel = new System.Windows.Forms.Label();
            this.iceCappuccinoInfoButton = new System.Windows.Forms.Panel();
            this.iceCappuccinoCounterLabel = new System.Windows.Forms.Label();
            this.verticalLine2 = new System.Windows.Forms.Panel();
            this.iceCapuccinoAddButton = new System.Windows.Forms.Panel();
            this.firstRewardPanel = new System.Windows.Forms.Panel();
            this.controlPanel1 = new System.Windows.Forms.Panel();
            this.firstTrioMinusZeroButton = new System.Windows.Forms.Panel();
            this.firstTrioPointsLabel = new System.Windows.Forms.Label();
            this.firstTrioCounterLabel = new System.Windows.Forms.Label();
            this.firstTrioInfoButton = new System.Windows.Forms.Panel();
            this.vericalLinePanel = new System.Windows.Forms.Panel();
            this.firstTrioAddButton = new System.Windows.Forms.Panel();
            this.firstTrioInfoLabel = new System.Windows.Forms.Label();
            this.pointsPanel = new System.Windows.Forms.Panel();
            this.pointsLabel = new System.Windows.Forms.Label();
            this.currentPointsLabel = new System.Windows.Forms.Label();
            this.userNameLabel = new System.Windows.Forms.Label();
            this.thirdControlPanel.SuspendLayout();
            this.controlPanel3.SuspendLayout();
            this.secondRewardPanel.SuspendLayout();
            this.controlPanel2.SuspendLayout();
            this.firstRewardPanel.SuspendLayout();
            this.controlPanel1.SuspendLayout();
            this.pointsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // updatePointsLabel
            // 
            this.updatePointsLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.updatePointsLabel.Image = global::RestaurantApplication.Properties.Resources.updatePoints;
            this.updatePointsLabel.Location = new System.Drawing.Point(254, 179);
            this.updatePointsLabel.Name = "updatePointsLabel";
            this.updatePointsLabel.Size = new System.Drawing.Size(177, 35);
            this.updatePointsLabel.TabIndex = 6;
            this.updatePointsLabel.Click += new System.EventHandler(this.UpdatePointsLabel_Click);
            // 
            // addToCartLabel
            // 
            this.addToCartLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addToCartLabel.Enabled = false;
            this.addToCartLabel.Image = global::RestaurantApplication.Properties.Resources.rewardsCartAddButton;
            this.addToCartLabel.Location = new System.Drawing.Point(461, 180);
            this.addToCartLabel.Name = "addToCartLabel";
            this.addToCartLabel.Size = new System.Drawing.Size(200, 34);
            this.addToCartLabel.TabIndex = 5;
            this.addToCartLabel.Click += new System.EventHandler(this.AddToCartLabel_Click);
            // 
            // thirdControlPanel
            // 
            this.thirdControlPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.TrioTwoRewards;
            this.thirdControlPanel.Controls.Add(this.secondTrioInfoLabel);
            this.thirdControlPanel.Controls.Add(this.controlPanel3);
            this.thirdControlPanel.Location = new System.Drawing.Point(603, 220);
            this.thirdControlPanel.Name = "thirdControlPanel";
            this.thirdControlPanel.Size = new System.Drawing.Size(260, 320);
            this.thirdControlPanel.TabIndex = 3;
            this.thirdControlPanel.MouseEnter += new System.EventHandler(this.ThirdControlPanel_MouseEnter);
            // 
            // secondTrioInfoLabel
            // 
            this.secondTrioInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondTrioInfoLabel.ForeColor = System.Drawing.Color.White;
            this.secondTrioInfoLabel.Location = new System.Drawing.Point(3, 0);
            this.secondTrioInfoLabel.Name = "secondTrioInfoLabel";
            this.secondTrioInfoLabel.Size = new System.Drawing.Size(257, 250);
            this.secondTrioInfoLabel.TabIndex = 1;
            this.secondTrioInfoLabel.Text = "This special is a trio containing three items from our menu: our delicious chicke" +
    "n salad, our unique vegetable soup and the best coffee in town.";
            // 
            // controlPanel3
            // 
            this.controlPanel3.Controls.Add(this.secondTrioMinusZeroButton);
            this.controlPanel3.Controls.Add(this.secondTrioPointsLabel);
            this.controlPanel3.Controls.Add(this.secondTrioInfoButton);
            this.controlPanel3.Controls.Add(this.secondTrioCounterLabel);
            this.controlPanel3.Controls.Add(this.panel2);
            this.controlPanel3.Controls.Add(this.secondTrioAddButton);
            this.controlPanel3.Location = new System.Drawing.Point(3, 250);
            this.controlPanel3.Name = "controlPanel3";
            this.controlPanel3.Size = new System.Drawing.Size(257, 70);
            this.controlPanel3.TabIndex = 0;
            this.controlPanel3.MouseLeave += new System.EventHandler(this.ControlPanel3_MouseLeave);
            // 
            // secondTrioMinusZeroButton
            // 
            this.secondTrioMinusZeroButton.BackColor = System.Drawing.Color.Transparent;
            this.secondTrioMinusZeroButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.secondTrioMinusZeroButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.secondTrioMinusZeroButton.Enabled = false;
            this.secondTrioMinusZeroButton.Location = new System.Drawing.Point(18, 16);
            this.secondTrioMinusZeroButton.Name = "secondTrioMinusZeroButton";
            this.secondTrioMinusZeroButton.Size = new System.Drawing.Size(37, 39);
            this.secondTrioMinusZeroButton.TabIndex = 9;
            this.secondTrioMinusZeroButton.Click += new System.EventHandler(this.SecondTrioMinusZeroButton_Click);
            // 
            // secondTrioPointsLabel
            // 
            this.secondTrioPointsLabel.AutoSize = true;
            this.secondTrioPointsLabel.BackColor = System.Drawing.Color.Transparent;
            this.secondTrioPointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondTrioPointsLabel.ForeColor = System.Drawing.Color.White;
            this.secondTrioPointsLabel.Location = new System.Drawing.Point(212, 56);
            this.secondTrioPointsLabel.Name = "secondTrioPointsLabel";
            this.secondTrioPointsLabel.Size = new System.Drawing.Size(47, 12);
            this.secondTrioPointsLabel.TabIndex = 8;
            this.secondTrioPointsLabel.Text = "200 points";
            // 
            // secondTrioInfoButton
            // 
            this.secondTrioInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.secondTrioInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.secondTrioInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.secondTrioInfoButton.Location = new System.Drawing.Point(207, 25);
            this.secondTrioInfoButton.Name = "secondTrioInfoButton";
            this.secondTrioInfoButton.Size = new System.Drawing.Size(20, 20);
            this.secondTrioInfoButton.TabIndex = 7;
            this.secondTrioInfoButton.Click += new System.EventHandler(this.SecondTrioInfoButton_Click);
            // 
            // secondTrioCounterLabel
            // 
            this.secondTrioCounterLabel.AutoSize = true;
            this.secondTrioCounterLabel.BackColor = System.Drawing.Color.Transparent;
            this.secondTrioCounterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secondTrioCounterLabel.ForeColor = System.Drawing.Color.White;
            this.secondTrioCounterLabel.Location = new System.Drawing.Point(79, 26);
            this.secondTrioCounterLabel.Name = "secondTrioCounterLabel";
            this.secondTrioCounterLabel.Size = new System.Drawing.Size(18, 20);
            this.secondTrioCounterLabel.TabIndex = 6;
            this.secondTrioCounterLabel.Text = "0";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = global::RestaurantApplication.Properties.Resources.verticalline;
            this.panel2.Location = new System.Drawing.Point(177, 9);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 53);
            this.panel2.TabIndex = 4;
            // 
            // secondTrioAddButton
            // 
            this.secondTrioAddButton.BackColor = System.Drawing.Color.Transparent;
            this.secondTrioAddButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.secondTrioAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.secondTrioAddButton.Location = new System.Drawing.Point(121, 16);
            this.secondTrioAddButton.Name = "secondTrioAddButton";
            this.secondTrioAddButton.Size = new System.Drawing.Size(37, 39);
            this.secondTrioAddButton.TabIndex = 3;
            this.secondTrioAddButton.Click += new System.EventHandler(this.SecondTrioAddButton_Click);
            // 
            // secondRewardPanel
            // 
            this.secondRewardPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.IceCapuccinos;
            this.secondRewardPanel.Controls.Add(this.iceCappuccinoInfoLabel);
            this.secondRewardPanel.Controls.Add(this.controlPanel2);
            this.secondRewardPanel.Location = new System.Drawing.Point(320, 220);
            this.secondRewardPanel.Name = "secondRewardPanel";
            this.secondRewardPanel.Size = new System.Drawing.Size(260, 320);
            this.secondRewardPanel.TabIndex = 2;
            this.secondRewardPanel.MouseEnter += new System.EventHandler(this.SecondRewardPanel_MouseEnter);
            // 
            // iceCappuccinoInfoLabel
            // 
            this.iceCappuccinoInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iceCappuccinoInfoLabel.ForeColor = System.Drawing.Color.White;
            this.iceCappuccinoInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.iceCappuccinoInfoLabel.Name = "iceCappuccinoInfoLabel";
            this.iceCappuccinoInfoLabel.Size = new System.Drawing.Size(260, 250);
            this.iceCappuccinoInfoLabel.TabIndex = 1;
            this.iceCappuccinoInfoLabel.Text = "Our Ice Cappuccino\'s are the best in town and can only be drank if you are a memb" +
    "er that has 100 points. It is unlike any drink you have tasted before!";
            // 
            // controlPanel2
            // 
            this.controlPanel2.Controls.Add(this.iceCappuccinoMinusZeroButton);
            this.controlPanel2.Controls.Add(this.iceCappuccinoPointsLabel);
            this.controlPanel2.Controls.Add(this.iceCappuccinoInfoButton);
            this.controlPanel2.Controls.Add(this.iceCappuccinoCounterLabel);
            this.controlPanel2.Controls.Add(this.verticalLine2);
            this.controlPanel2.Controls.Add(this.iceCapuccinoAddButton);
            this.controlPanel2.Location = new System.Drawing.Point(0, 250);
            this.controlPanel2.Name = "controlPanel2";
            this.controlPanel2.Size = new System.Drawing.Size(260, 70);
            this.controlPanel2.TabIndex = 0;
            this.controlPanel2.MouseLeave += new System.EventHandler(this.ControlPanel2_MouseLeave);
            // 
            // iceCappuccinoMinusZeroButton
            // 
            this.iceCappuccinoMinusZeroButton.BackColor = System.Drawing.Color.Transparent;
            this.iceCappuccinoMinusZeroButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.iceCappuccinoMinusZeroButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iceCappuccinoMinusZeroButton.Enabled = false;
            this.iceCappuccinoMinusZeroButton.Location = new System.Drawing.Point(17, 16);
            this.iceCappuccinoMinusZeroButton.Name = "iceCappuccinoMinusZeroButton";
            this.iceCappuccinoMinusZeroButton.Size = new System.Drawing.Size(37, 39);
            this.iceCappuccinoMinusZeroButton.TabIndex = 8;
            this.iceCappuccinoMinusZeroButton.Click += new System.EventHandler(this.IceCappuccinoMinusZeroButton_Click);
            // 
            // iceCappuccinoPointsLabel
            // 
            this.iceCappuccinoPointsLabel.AutoSize = true;
            this.iceCappuccinoPointsLabel.BackColor = System.Drawing.Color.Transparent;
            this.iceCappuccinoPointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iceCappuccinoPointsLabel.ForeColor = System.Drawing.Color.White;
            this.iceCappuccinoPointsLabel.Location = new System.Drawing.Point(212, 56);
            this.iceCappuccinoPointsLabel.Name = "iceCappuccinoPointsLabel";
            this.iceCappuccinoPointsLabel.Size = new System.Drawing.Size(47, 12);
            this.iceCappuccinoPointsLabel.TabIndex = 7;
            this.iceCappuccinoPointsLabel.Text = "100 points";
            // 
            // iceCappuccinoInfoButton
            // 
            this.iceCappuccinoInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.iceCappuccinoInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.iceCappuccinoInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iceCappuccinoInfoButton.Location = new System.Drawing.Point(207, 25);
            this.iceCappuccinoInfoButton.Name = "iceCappuccinoInfoButton";
            this.iceCappuccinoInfoButton.Size = new System.Drawing.Size(20, 20);
            this.iceCappuccinoInfoButton.TabIndex = 6;
            this.iceCappuccinoInfoButton.Click += new System.EventHandler(this.IceCappuccinoInfoButton_Click);
            // 
            // iceCappuccinoCounterLabel
            // 
            this.iceCappuccinoCounterLabel.AutoSize = true;
            this.iceCappuccinoCounterLabel.BackColor = System.Drawing.Color.Transparent;
            this.iceCappuccinoCounterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iceCappuccinoCounterLabel.ForeColor = System.Drawing.Color.White;
            this.iceCappuccinoCounterLabel.Location = new System.Drawing.Point(79, 26);
            this.iceCappuccinoCounterLabel.Name = "iceCappuccinoCounterLabel";
            this.iceCappuccinoCounterLabel.Size = new System.Drawing.Size(18, 20);
            this.iceCappuccinoCounterLabel.TabIndex = 5;
            this.iceCappuccinoCounterLabel.Text = "0";
            // 
            // verticalLine2
            // 
            this.verticalLine2.BackColor = System.Drawing.Color.Transparent;
            this.verticalLine2.BackgroundImage = global::RestaurantApplication.Properties.Resources.verticalline;
            this.verticalLine2.Location = new System.Drawing.Point(177, 9);
            this.verticalLine2.Name = "verticalLine2";
            this.verticalLine2.Size = new System.Drawing.Size(1, 53);
            this.verticalLine2.TabIndex = 3;
            // 
            // iceCapuccinoAddButton
            // 
            this.iceCapuccinoAddButton.BackColor = System.Drawing.Color.Transparent;
            this.iceCapuccinoAddButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.iceCapuccinoAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iceCapuccinoAddButton.Location = new System.Drawing.Point(122, 16);
            this.iceCapuccinoAddButton.Name = "iceCapuccinoAddButton";
            this.iceCapuccinoAddButton.Size = new System.Drawing.Size(37, 39);
            this.iceCapuccinoAddButton.TabIndex = 2;
            this.iceCapuccinoAddButton.Click += new System.EventHandler(this.IceCapuccinoAddButton_Click);
            // 
            // firstRewardPanel
            // 
            this.firstRewardPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.TrioOneRewards;
            this.firstRewardPanel.Controls.Add(this.controlPanel1);
            this.firstRewardPanel.Controls.Add(this.firstTrioInfoLabel);
            this.firstRewardPanel.Location = new System.Drawing.Point(34, 220);
            this.firstRewardPanel.Name = "firstRewardPanel";
            this.firstRewardPanel.Size = new System.Drawing.Size(260, 320);
            this.firstRewardPanel.TabIndex = 1;
            this.firstRewardPanel.MouseEnter += new System.EventHandler(this.FirstRewardPanel_MouseEnter);
            // 
            // controlPanel1
            // 
            this.controlPanel1.Controls.Add(this.firstTrioMinusZeroButton);
            this.controlPanel1.Controls.Add(this.firstTrioPointsLabel);
            this.controlPanel1.Controls.Add(this.firstTrioCounterLabel);
            this.controlPanel1.Controls.Add(this.firstTrioInfoButton);
            this.controlPanel1.Controls.Add(this.vericalLinePanel);
            this.controlPanel1.Controls.Add(this.firstTrioAddButton);
            this.controlPanel1.Location = new System.Drawing.Point(3, 250);
            this.controlPanel1.Name = "controlPanel1";
            this.controlPanel1.Size = new System.Drawing.Size(258, 70);
            this.controlPanel1.TabIndex = 0;
            this.controlPanel1.MouseLeave += new System.EventHandler(this.ControlPanel1_MouseLeave);
            // 
            // firstTrioMinusZeroButton
            // 
            this.firstTrioMinusZeroButton.BackColor = System.Drawing.Color.Transparent;
            this.firstTrioMinusZeroButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.MinusZeroButton;
            this.firstTrioMinusZeroButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.firstTrioMinusZeroButton.Enabled = false;
            this.firstTrioMinusZeroButton.Location = new System.Drawing.Point(16, 16);
            this.firstTrioMinusZeroButton.Name = "firstTrioMinusZeroButton";
            this.firstTrioMinusZeroButton.Size = new System.Drawing.Size(37, 39);
            this.firstTrioMinusZeroButton.TabIndex = 1;
            this.firstTrioMinusZeroButton.Click += new System.EventHandler(this.FirstTrioMinusZeroButton_Click);
            // 
            // firstTrioPointsLabel
            // 
            this.firstTrioPointsLabel.AutoSize = true;
            this.firstTrioPointsLabel.BackColor = System.Drawing.Color.Transparent;
            this.firstTrioPointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstTrioPointsLabel.ForeColor = System.Drawing.Color.White;
            this.firstTrioPointsLabel.Location = new System.Drawing.Point(212, 56);
            this.firstTrioPointsLabel.Name = "firstTrioPointsLabel";
            this.firstTrioPointsLabel.Size = new System.Drawing.Size(47, 12);
            this.firstTrioPointsLabel.TabIndex = 5;
            this.firstTrioPointsLabel.Text = "200 points";
            // 
            // firstTrioCounterLabel
            // 
            this.firstTrioCounterLabel.AutoSize = true;
            this.firstTrioCounterLabel.BackColor = System.Drawing.Color.Transparent;
            this.firstTrioCounterLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstTrioCounterLabel.ForeColor = System.Drawing.Color.White;
            this.firstTrioCounterLabel.Location = new System.Drawing.Point(76, 27);
            this.firstTrioCounterLabel.Name = "firstTrioCounterLabel";
            this.firstTrioCounterLabel.Size = new System.Drawing.Size(18, 20);
            this.firstTrioCounterLabel.TabIndex = 4;
            this.firstTrioCounterLabel.Text = "0";
            // 
            // firstTrioInfoButton
            // 
            this.firstTrioInfoButton.BackColor = System.Drawing.Color.Transparent;
            this.firstTrioInfoButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.InfoButton;
            this.firstTrioInfoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.firstTrioInfoButton.Location = new System.Drawing.Point(204, 25);
            this.firstTrioInfoButton.Name = "firstTrioInfoButton";
            this.firstTrioInfoButton.Size = new System.Drawing.Size(20, 20);
            this.firstTrioInfoButton.TabIndex = 3;
            this.firstTrioInfoButton.Click += new System.EventHandler(this.FirstTrioInfoButton_Click);
            // 
            // vericalLinePanel
            // 
            this.vericalLinePanel.BackColor = System.Drawing.Color.Transparent;
            this.vericalLinePanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.verticalline;
            this.vericalLinePanel.Location = new System.Drawing.Point(174, 9);
            this.vericalLinePanel.Name = "vericalLinePanel";
            this.vericalLinePanel.Size = new System.Drawing.Size(1, 53);
            this.vericalLinePanel.TabIndex = 2;
            // 
            // firstTrioAddButton
            // 
            this.firstTrioAddButton.BackColor = System.Drawing.Color.Transparent;
            this.firstTrioAddButton.BackgroundImage = global::RestaurantApplication.Properties.Resources.PlusButton;
            this.firstTrioAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.firstTrioAddButton.Location = new System.Drawing.Point(117, 17);
            this.firstTrioAddButton.Name = "firstTrioAddButton";
            this.firstTrioAddButton.Size = new System.Drawing.Size(37, 39);
            this.firstTrioAddButton.TabIndex = 1;
            this.firstTrioAddButton.Click += new System.EventHandler(this.FirstTrioAddButton_Click);
            // 
            // firstTrioInfoLabel
            // 
            this.firstTrioInfoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.firstTrioInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstTrioInfoLabel.ForeColor = System.Drawing.Color.White;
            this.firstTrioInfoLabel.Location = new System.Drawing.Point(3, 0);
            this.firstTrioInfoLabel.Name = "firstTrioInfoLabel";
            this.firstTrioInfoLabel.Size = new System.Drawing.Size(258, 250);
            this.firstTrioInfoLabel.TabIndex = 0;
            this.firstTrioInfoLabel.Text = "This special is a trio containing the tuna sandwich and water from our menu. Addi" +
    "tionally, we serve a special exclusive chicken soup!";
            // 
            // pointsPanel
            // 
            this.pointsPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.balanceRewards;
            this.pointsPanel.Controls.Add(this.pointsLabel);
            this.pointsPanel.Controls.Add(this.currentPointsLabel);
            this.pointsPanel.Controls.Add(this.userNameLabel);
            this.pointsPanel.Location = new System.Drawing.Point(210, 5);
            this.pointsPanel.Name = "pointsPanel";
            this.pointsPanel.Size = new System.Drawing.Size(493, 172);
            this.pointsPanel.TabIndex = 0;
            // 
            // pointsLabel
            // 
            this.pointsLabel.AutoSize = true;
            this.pointsLabel.BackColor = System.Drawing.Color.Transparent;
            this.pointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 50.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pointsLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(197)))), ((int)(((byte)(146)))));
            this.pointsLabel.Location = new System.Drawing.Point(7, 85);
            this.pointsLabel.Name = "pointsLabel";
            this.pointsLabel.Size = new System.Drawing.Size(148, 76);
            this.pointsLabel.TabIndex = 2;
            this.pointsLabel.Text = "N/A";
            // 
            // currentPointsLabel
            // 
            this.currentPointsLabel.AutoSize = true;
            this.currentPointsLabel.BackColor = System.Drawing.Color.Transparent;
            this.currentPointsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentPointsLabel.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.currentPointsLabel.Location = new System.Drawing.Point(20, 73);
            this.currentPointsLabel.Name = "currentPointsLabel";
            this.currentPointsLabel.Size = new System.Drawing.Size(46, 13);
            this.currentPointsLabel.TabIndex = 1;
            this.currentPointsLabel.Text = "Points:";
            // 
            // userNameLabel
            // 
            this.userNameLabel.AutoSize = true;
            this.userNameLabel.BackColor = System.Drawing.Color.Transparent;
            this.userNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameLabel.Location = new System.Drawing.Point(18, 13);
            this.userNameLabel.Name = "userNameLabel";
            this.userNameLabel.Size = new System.Drawing.Size(164, 25);
            this.userNameLabel.TabIndex = 0;
            this.userNameLabel.Text = "Unknown User";
            // 
            // RewardsUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Controls.Add(this.updatePointsLabel);
            this.Controls.Add(this.addToCartLabel);
            this.Controls.Add(this.thirdControlPanel);
            this.Controls.Add(this.secondRewardPanel);
            this.Controls.Add(this.firstRewardPanel);
            this.Controls.Add(this.pointsPanel);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "RewardsUserControl";
            this.Size = new System.Drawing.Size(899, 572);
            this.MouseEnter += new System.EventHandler(this.RewardsUserControl_MouseEnter);
            this.thirdControlPanel.ResumeLayout(false);
            this.controlPanel3.ResumeLayout(false);
            this.controlPanel3.PerformLayout();
            this.secondRewardPanel.ResumeLayout(false);
            this.controlPanel2.ResumeLayout(false);
            this.controlPanel2.PerformLayout();
            this.firstRewardPanel.ResumeLayout(false);
            this.controlPanel1.ResumeLayout(false);
            this.controlPanel1.PerformLayout();
            this.pointsPanel.ResumeLayout(false);
            this.pointsPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pointsPanel;
        private System.Windows.Forms.Label pointsLabel;
        private System.Windows.Forms.Label currentPointsLabel;
        private System.Windows.Forms.Label userNameLabel;
        private System.Windows.Forms.Panel firstRewardPanel;
        private System.Windows.Forms.Panel secondRewardPanel;
        private System.Windows.Forms.Panel thirdControlPanel;
        private System.Windows.Forms.Panel controlPanel1;
        private System.Windows.Forms.Panel controlPanel3;
        private System.Windows.Forms.Panel controlPanel2;
        private System.Windows.Forms.Panel vericalLinePanel;
        private System.Windows.Forms.Panel firstTrioAddButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel secondTrioAddButton;
        private System.Windows.Forms.Panel iceCappuccinoInfoButton;
        private System.Windows.Forms.Label iceCappuccinoCounterLabel;
        private System.Windows.Forms.Panel verticalLine2;
        private System.Windows.Forms.Panel iceCapuccinoAddButton;
        private System.Windows.Forms.Label firstTrioCounterLabel;
        private System.Windows.Forms.Panel firstTrioInfoButton;
        private System.Windows.Forms.Panel secondTrioInfoButton;
        private System.Windows.Forms.Label secondTrioCounterLabel;
        private System.Windows.Forms.Label secondTrioPointsLabel;
        private System.Windows.Forms.Label iceCappuccinoPointsLabel;
        private System.Windows.Forms.Label firstTrioInfoLabel;
        private System.Windows.Forms.Label firstTrioPointsLabel;
        private System.Windows.Forms.Label iceCappuccinoInfoLabel;
        private System.Windows.Forms.Label secondTrioInfoLabel;
        private System.Windows.Forms.Panel secondTrioMinusZeroButton;
        private System.Windows.Forms.Panel iceCappuccinoMinusZeroButton;
        private System.Windows.Forms.Panel firstTrioMinusZeroButton;
        private System.Windows.Forms.Label addToCartLabel;
        private System.Windows.Forms.Label updatePointsLabel;
    }
}
