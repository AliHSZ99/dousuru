﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace RestaurantApplication
{
    [Serializable()]
    class Account : ISerializable, IEquatable<Account>
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public int Points { get; set; }

        public Account(string newUsername, string newPassword, int initialPoints)
        {
            Username = newUsername;
            Password = newPassword;
            Points = initialPoints;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Username", Username);
            info.AddValue("Password", Password);
            info.AddValue("Points", Points);
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as Account);
        }

        public bool Equals(Account other)
        {
            return other != null &&
                   Username == other.Username;
        }

        public override int GetHashCode()
        {
            int hashCode = 568732665;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Username);
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Password);
            return hashCode;
        }

        public Account(SerializationInfo info, StreamingContext context)
        {
            Username = (string)info.GetValue("Username", typeof(string));
            Password = (string)info.GetValue("Password", typeof(string));
            Points = (int)info.GetValue("Points", typeof(int));
        }
    }
}
