﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace RestaurantApplication
{
    public partial class LoginUserControl : UserControl
    {
        private bool PassNotValid = true;
        public LoginUserControl()
        {
            InitializeComponent();
        }

        // method that checks if an account exists.
        private bool IsAccountExist(Account newaccount, List<Account> accounts)
        {
            if (accounts.Contains(newaccount))
            {
                return true;
            } else
            {
                return false;
            }
        }
        
        // method that insert an account to the activeAccount.json file.
        private void InsertObjectToJsonFile(Account account)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\activeAccount.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, account);
                }
            } 
            catch (Exception)
            {
                File.Create("activeAccount.json");
            }
        }
        
        // method that insert List of Account into the accounts.json file.
        private void InsertListToJsonFile(List<Account> accounts)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\accounts.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, accounts);
                }
            }
            catch (Exception)
            {
                File.Create("accounts.json");
            }
        }

        // method that retrieves accounts from accounts.json file and returns a list of it.
        private List<Account> RetrieveListFromJsonFile()
        {
            try
            {
                using (StreamReader file = File.OpenText(@"..\Debug\accounts.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Account> accounts = (List<Account>)serializer.Deserialize(file, typeof(List<Account>));
                    return accounts;
                }
            } catch (Exception)
            {
                return new List<Account>();
            }
        }

        // method for register button click.
        private void RegisterButton_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(usernameTextBox.Text) && String.IsNullOrEmpty(passwordTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Veuillez saisir un nom d'utilisateur et un mot de passe", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Username and A Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (String.IsNullOrEmpty(passwordTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Veuillez entrer un mot de passe", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (String.IsNullOrEmpty(usernameTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Merci d'entrer un nom d'utilisateur", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                List<Account> accounts = RetrieveListFromJsonFile();
                Account newAccount = new Account(usernameTextBox.Text, passwordTextBox.Text, 0);
                
                if ((accounts.Count == 0))
                {
                    accounts.Add(newAccount);
                    InsertListToJsonFile(accounts);
                }
                else
                {
                    accounts = RetrieveListFromJsonFile();
                    if (IsAccountExist(newAccount, accounts))
                    {
                        if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                        {
                           MessageBox.Show("Ce nom d'utilisateur est déjà pris", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        } else
                        {
                            MessageBox.Show("This username is already taken", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        accounts.Add(newAccount);
                        InsertListToJsonFile(accounts);
                        if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                        {
                            MessageBox.Show("Compte créé", "Inscrit(e)", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Account Created", "Registered", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        // method that activates when the login button is clicked.
        private void LoginButton_Click(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

            if (String.IsNullOrEmpty(usernameTextBox.Text) && String.IsNullOrEmpty(passwordTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Veuillez saisir un nom d'utilisateur et un mot de passe", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Username and A Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (String.IsNullOrEmpty(passwordTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Veuillez entrer un mot de passe", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (String.IsNullOrEmpty(usernameTextBox.Text))
            {
                if (showPasswordCheckBox.Text == "Montrer le mot de passe")
                {
                    MessageBox.Show("Merci d'entrer un nom d'utilisateur", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Please Enter A Username", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                Account newAccount = new Account(usernameTextBox.Text, passwordTextBox.Text, 0);
                List<Account> accounts = RetrieveListFromJsonFile();
                
                foreach (Account account in accounts)
                {
                    if (account.Username.Equals(newAccount.Username) && account.Password.Equals(newAccount.Password))
                    {
                        InsertObjectToJsonFile(account);
                        parentForm.rewardsButton.Enabled = true;
                        parentForm.signinButton.Location = new Point(28, 257);
                        if (parentForm.cartButton.Text.Equals("Chariot"))
                        {
                            MessageBox.Show("Connecté avec succès", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            parentForm.signinButton.Text = "Déconnexion";
                            parentForm.signinButton.Location = new Point(4, 257);
                            parentForm.signinButton.Width = 200;
                            PassNotValid = false;
                            break;
                        }
                        else
                        {
                            parentForm.signinButton.Text = "Sign Out";
                            MessageBox.Show("Logged in successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            registerButton.Enabled = false;
                            loginButton.Enabled = false;
                            usernameTextBox.Text = "";
                            passwordTextBox.Text = "";
                            usernameTextBox.Enabled = false;
                            passwordTextBox.Enabled = false;
                            showPasswordCheckBox.Checked = false;
                            showPasswordCheckBox.Enabled = false;
                            PassNotValid = false;
                            break;
                        }
                    }
                }

                if (PassNotValid)
                {
                    if (parentForm.cartButton.Text.Equals("Chariot"))
                    {
                        MessageBox.Show("Ce compte n'éxiste pas", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        MessageBox.Show("This account does not exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            } 
        }

        // method that switches language to french if french flag is selected and mouse enters the user control.
        private void LoginUserControl_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);
            if (parentForm.cartButton.Text.Equals("Chariot"))
            {
                usernameLabel.Text = "Nom d'utilisateur";
                passwordLabel.Text = "Mot de passe";
                loginButton.Image = Properties.Resources.LoginButtonFR;
                registerButton.Image = Properties.Resources.RegisterButtonFR;
                showPasswordCheckBox.Text = "Montrer le mot de passe";
            }
        }

        // method that shows the password when the checkbox is checked and hides it when it is not.
        private void ShowPasswordCheckBox_CheckStateChanged(object sender, EventArgs e)
        {
            if (showPasswordCheckBox.Checked == true)
            {
                passwordTextBox.UseSystemPasswordChar = false;
            }
            else
            {
                passwordTextBox.UseSystemPasswordChar = true;
            }
        }
    }
}
