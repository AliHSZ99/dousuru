﻿
namespace RestaurantApplication
{
    partial class AboutUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aliLabel = new System.Windows.Forms.Label();
            this.usLabel = new System.Windows.Forms.Label();
            this.vincentLabel = new System.Windows.Forms.Label();
            this.jeremieLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // aliLabel
            // 
            this.aliLabel.Image = global::RestaurantApplication.Properties.Resources.AliAbouts;
            this.aliLabel.Location = new System.Drawing.Point(25, 201);
            this.aliLabel.Name = "aliLabel";
            this.aliLabel.Size = new System.Drawing.Size(410, 177);
            this.aliLabel.TabIndex = 7;
            // 
            // usLabel
            // 
            this.usLabel.Image = global::RestaurantApplication.Properties.Resources.BoysAndAppAbout;
            this.usLabel.Location = new System.Drawing.Point(458, 18);
            this.usLabel.Name = "usLabel";
            this.usLabel.Size = new System.Drawing.Size(417, 540);
            this.usLabel.TabIndex = 6;
            // 
            // vincentLabel
            // 
            this.vincentLabel.Image = global::RestaurantApplication.Properties.Resources.VincentAbout;
            this.vincentLabel.Location = new System.Drawing.Point(25, 392);
            this.vincentLabel.Name = "vincentLabel";
            this.vincentLabel.Size = new System.Drawing.Size(410, 165);
            this.vincentLabel.TabIndex = 5;
            // 
            // jeremieLabel
            // 
            this.jeremieLabel.Image = global::RestaurantApplication.Properties.Resources.JeremieAbout;
            this.jeremieLabel.Location = new System.Drawing.Point(25, 22);
            this.jeremieLabel.Name = "jeremieLabel";
            this.jeremieLabel.Size = new System.Drawing.Size(410, 165);
            this.jeremieLabel.TabIndex = 4;
            // 
            // AboutUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.aliLabel);
            this.Controls.Add(this.usLabel);
            this.Controls.Add(this.vincentLabel);
            this.Controls.Add(this.jeremieLabel);
            this.Name = "AboutUserControl";
            this.Size = new System.Drawing.Size(899, 572);
            this.MouseEnter += new System.EventHandler(this.AboutUserControl_MouseEnter);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label jeremieLabel;
        private System.Windows.Forms.Label vincentLabel;
        private System.Windows.Forms.Label usLabel;
        private System.Windows.Forms.Label aliLabel;
    }
}
