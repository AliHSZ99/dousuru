﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Newtonsoft.Json;
using System.Text.RegularExpressions;

namespace RestaurantApplication
{
    public partial class CartUserControl : UserControl
    {

        // constructor.
        public CartUserControl()
        {
            InitializeComponent();
        }

        // variales.
        private decimal total = 0;
        private decimal taxPercent = 0.15m;

        // method to display the review of the order. 
        private void ReviewOrderLabel_Click(object sender, EventArgs e)
        {
            total = 0;
            orderTextBox.Clear();

            List<Food> foods = RetrieveListFromJsonFile(@"..\Debug\food.json");
            List<Food> rewardFoods = RetrieveListFromJsonFile(@"..\Debug\rewards.json");
            if (foods.Count == 0 && rewardFoods.Count == 0)
            {
                if (summaryLabel.Text == "RÉCAPITULATIF")
                {
                    MessageBox.Show("Il n'y a rien à montrer", "Panier Vide",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else
                {
                    MessageBox.Show("There is nothing to show yet", "Empty Cart",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            } else
            {
                foreach (var food in foods)
                {
                    orderTextBox.AppendText($"1 {food.Type} - {food.Price:C}\r\n");
                    total += food.Price;
                }

                foreach (var reward in rewardFoods)
                {
                    orderTextBox.AppendText($"1 {reward.Type} - {reward.Price} points\r\n");
                }

                total = (total * taxPercent) + total;
                if (summaryLabel.Text == "RÉCAPITULATIF")
                {
                    orderTextBox.AppendText($"\r\n\r\nPrix total: {total:C}");
                } else
                {
                orderTextBox.AppendText($"\r\n\r\nTotal Price: {total:C}");
                }
            }
        }

        // method that retrieves foods from json file and returns them in a Food List.
        private List<Food> RetrieveListFromJsonFile(string path)
        {

            try
            {
                using (StreamReader file = File.OpenText(path))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Food> foods = (List<Food>)serializer.Deserialize(file, typeof(List<Food>));
                    return foods;
                }
            }
            catch (Exception)
            {
                return new List<Food>();
            }
        }

        // method that retrieve the active account from activeAccount.json.
        private Account RetrieveActiveAccount()
        {
            using (StreamReader file = File.OpenText(@"..\Debug\activeAccount.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                Account accounts = (Account)serializer.Deserialize(file, typeof(Account));
                return accounts;
            }
        }

        // method that insert an the active user's account information in the json file called activeAccount.json.
        private void InsertObjectToJsonFile(Account account)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\activeAccount.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, account);
                }
            }
            catch
            {
                File.Create("activeAccount.json");
            }
        }

        // method that changes language to french if french flag is selected and the mouse enters the user control. 
        private void CartUserControl_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

            if (parentForm.cartButton.Text == "Chariot")
            {
                summaryLabel.Text = "RÉCAPITULATIF";
                paymentMethodLabel.Text = "MODE DE PAIEMENT";
                phoneNumberLabel.Text = "Numéro de téléphone";
                addressLabel.Text = "Adresse";
                cardNumberLabel.Text = "Numéro de carte";
                extraInfoLabel.Text = "Informations Extra";
                confirmOrderLabel.Image = Properties.Resources.OrderConfirmFR;
                reviewOrderLabel.Image = Properties.Resources.ReivewSummaryFR;
            }
        }

        // method that changes the language when the mouse enters the cart panel.
        private void CartPanel_MouseEnter(object sender, EventArgs e)
        {
            Form parentForm = (this.Parent as Form);

            if (parentForm.cartButton.Text == "Chariot")
            {
                summaryLabel.Text = "RÉCAPITULATIF";
                paymentMethodLabel.Text = "MODE DE PAIEMENT";
                phoneNumberLabel.Text = "Numéro de téléphone";
                addressLabel.Text = "Adresse";
                cardNumberLabel.Text = "Numéro de carte";
                extraInfoLabel.Text = "Informations supplémentaires";
                deliveryRButton.Text = "Livraison";
                pickupRButton.Text = "Ramassage";
                readyToOrderLabel.Text = "Prêt à commander?";
                confirmOrderLabel.Image = Properties.Resources.OrderConfirmFR;
                reviewOrderLabel.Image = Properties.Resources.ReivewSummaryFR;
                emptyCartLabel.Image = Properties.Resources.emptyCartFR;
            }
        }

        // method that empties the cart when the empty cart label is clicked.
        private void EmptyCartLabel_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists("food.json") && !File.Exists("rewards.json"))
                {
                    if (summaryLabel.Text == "RÉCAPITULATIF")
                    {
                        MessageBox.Show("Le panier est déjà vide", "Vide",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("The cart is already empty", "Empty",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                } else
                {
                    File.Delete("food.json");
                    File.Delete("rewards.json");
                    MessageBox.Show("Cart emptied successfully", "Empty",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                orderTextBox.Clear();
                if (File.Exists("activeAccount.json"))
                {
                    Account ac = RetrieveActiveAccount();
                    List<Food> rewards = RetrieveListFromJsonFile(@"..\Debug\rewards.json");
                    foreach (var reward in rewards)
                    {
                        ac.Points += (int)reward.Price;
                    }
                    InsertObjectToJsonFile(ac);
                }
            }
            catch (Exception)
            {
            }
        }

        // A method that add points to the users with accounts whenever they buy a product
        private void AddPoints()
        {
            Account activeAccount = RetrieveActiveAccount();
            List<Food> foods = RetrieveListFromJsonFile(@"..\Debug\food.json");

            for (var i = 0; i < foods.Count; i++)
            {
                activeAccount.Points += 20;
            }

            InsertObjectToJsonFile(activeAccount);
        }

        // method that gets the accounts from json file and returns the information as Account List.
        private List<Account> RetrieveAccountsFromJsonFile(string path)
        {
            try
            {
                using (StreamReader file = File.OpenText(path))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    List<Account> accounts = (List<Account>)serializer.Deserialize(file, typeof(List<Account>));
                    return accounts;
                }
            }
            catch (Exception)
            {
                return new List<Account>();
            }
        }

        // method that inserts List of Account to the accounts.json file.
        private void InsertListToJsonFile(List<Account> accounts)
        {
            try
            {
                using (StreamWriter file = File.CreateText(@"..\Debug\accounts.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, accounts);
                }
            }
            catch (Exception)
            {
                File.Create("accounts.json");
            }
        }

        // method to print the receipt to the receipt.txt file.
        private void PrintReceipt()
        {
            List<Food> foods = RetrieveListFromJsonFile(@"..\Debug\food.json");
            List<Food> rewardFoods = RetrieveListFromJsonFile(@"..\Debug\rewards.json");
            Random rd = new Random();
            int deliverytime = rd.Next(20, 35);
            int deliveryFee = 5;
            DateTime today = DateTime.Now;
            total = 0;
            try
            {
                using (StreamWriter sr = new StreamWriter(@"..\Debug\receipt.txt"))
                {
                    string receipt = "             Order Confirmation            \n";
                    receipt += "         Problem Solver's Restaurant\n";
                    receipt += "        We hope you enjoy your order!\n\n";
                    receipt += "---------------------------------------------\n";
                    if (pickupRButton.Checked)
                    {
                        receipt += ($"Type: Pick up Order\n");
                    } else
                    {
                        receipt += ($"Type: Delivery Order\n");
                        receipt += ($"Delivery Time: {deliverytime} mins\n");
                        receipt += ($"Address: {addressTextBox.Text}\n");
                    }

                    receipt += ($"Date: {today.ToString("f")}\n");
                    receipt += ($"Phone Number:{phoneNumberTextBox.Text}\n");
                    receipt += ($"Payment: MasterCard\n");
                    receipt += "---------------------------------------------\n";

                    foreach (var food in foods)
                    {
                        receipt += ($"\t  1 {food.Type} - {food.Price:C}\r\n");
                        total += food.Price;
                    }

                    foreach (var reward in rewardFoods)
                    {
                        receipt += ($"\t  1 {reward.Type} - {reward.Price} points\r\n");
                    }
                
                    total = (total * taxPercent) + total;
                   
                    if (summaryLabel.Text == "RÉCAPITULATIF")
                    {
                        if (deliveryRButton.Checked)
                        {
                            total += deliveryFee;
                            receipt += ($"\n\tFrais de livraison: {deliveryFee:C}");
                        }
                        receipt += ($"\r\tTaux: {(total * taxPercent):C}\n\n\t  Prix total: {total:C}");
                    }
                    else
                    {
                        if (deliveryRButton.Checked)
                        {
                            total += deliveryFee;
                            receipt += ($"\n\tDelivery Fee: {deliveryFee:C}");
                        }
                        receipt += ($"\r\tTax: {(total * taxPercent):C}\n\tTotal Price: {total:C}");
                    }
                    receipt += "\n---------------------------------------------\n";

                    if (String.IsNullOrWhiteSpace(extraInfoTextBox.Text))
                    {
                        receipt += "\nExtra Info: N/A";
                    } else
                    {
                        receipt += ($"\nExtra Info: {extraInfoTextBox.Text}");
                    }
                    
                    receipt += "\n---------------------------------------------\n";


                    sr.WriteLine(receipt);
                    sr.Close();
                }
            }
            catch (Exception)
            {
                File.Create("receipt.txt");
            }
        }


        // method that confirms order if all conditions are met. 
        private void ConfirmOrderLabel_Click(object sender, EventArgs e)
        {
            List<Food> foods = RetrieveListFromJsonFile(@"..\Debug\food.json");
            List<Food> rewardFoods = RetrieveListFromJsonFile(@"..\Debug\rewards.json");
            if (foods.Count == 0 && rewardFoods.Count == 0)
            {
                if (summaryLabel.Text == "RÉCAPITULATIF")
                {
                    MessageBox.Show("On ne peut pas confirmer votre commande puisqu'il n'y a rien à traiter", "Vide",
                     MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else
                {
                    MessageBox.Show("We cannot confirm your order because there is nothing to process.", "Empty",
                     MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            } 
            else
            {
                string phoneNumberPattern = @"^\(?\d{3}\)?-? *\d{3}-? *-?\d{4}$";
                string creditCardPattern = @"^(\d){16}$";
                string civPattern = @"^(\d){3}$";
                Regex phoneNumberRegex = new Regex(phoneNumberPattern);
                Regex creditCardRegex = new Regex(creditCardPattern);
                Regex civRegex = new Regex(civPattern);
                Match isPhoneValid = phoneNumberRegex.Match(phoneNumberTextBox.Text);
                Match isCreditCardValid = creditCardRegex.Match(cardNumberTextBox.Text);
                Match iscivValid = civRegex.Match(civTextBox.Text);
                if (String.IsNullOrWhiteSpace(phoneNumberTextBox.Text) && String.IsNullOrWhiteSpace(addressTextBox.Text) 
                    && String.IsNullOrWhiteSpace(cardNumberTextBox.Text) && String.IsNullOrWhiteSpace(civTextBox.Text))
                {
                    MessageBox.Show("Please fill up your payment method information.", "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (String.IsNullOrWhiteSpace(phoneNumberTextBox.Text))
                {
                    MessageBox.Show("Please enter your phone number.", "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!isPhoneValid.Success)
                {
                    MessageBox.Show("Please enter a valid phone number.", "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
                else if (String.IsNullOrWhiteSpace(cardNumberTextBox.Text))
                {
                    MessageBox.Show("Please enter your credit card number.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else if (!isCreditCardValid.Success)
                {
                    MessageBox.Show("Please enter a valid credit card number.", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (String.IsNullOrWhiteSpace(civTextBox.Text))
                {
                    MessageBox.Show("Please enter your CVV number.", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (!iscivValid.Success)
                {
                    MessageBox.Show("Please enter a valid CVV number.", "Error",
                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (File.Exists("activeAccount.json"))
                    {
                        AddPoints();
                        Account activeaccount = RetrieveActiveAccount();
                        List<Account> accounts = RetrieveAccountsFromJsonFile(@"..\Debug\accounts.json");
                        foreach (Account account in accounts)
                        {
                            if (account.Equals(activeaccount))
                            {
                                account.Points = activeaccount.Points;
                            }
                        }

                        InsertListToJsonFile(accounts);
                        PrintReceipt();
                        MessageBox.Show("Order Confirmed.", "Success",
                         MessageBoxButtons.OK, MessageBoxIcon.Information);
                    } else
                    {
                        PrintReceipt();
                        MessageBox.Show("Order Confirmed.", "Success",
                  MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        // method that to select the pickup ratio button.
        private void PickupRButton_CheckedChanged(object sender, EventArgs e)
        {
            addressTextBox.Text = "";
            addressTextBox.Enabled = false;
        }

        // method to pick the delivery radio button.
        private void DeliveryRButton_CheckedChanged(object sender, EventArgs e)
        {
            addressTextBox.Enabled = true;
            if (deliveryRButton.Checked)
            {
                MessageBox.Show("Delivery comes with an extra $5 fee", "Warning!",
                     MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
