﻿
namespace RestaurantApplication
{
    partial class CartUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CartUserControl));
            this.readyToOrderLabel = new System.Windows.Forms.Label();
            this.cartPanel = new System.Windows.Forms.Panel();
            this.emptyCartLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.deliveryRButton = new System.Windows.Forms.RadioButton();
            this.pickupRButton = new System.Windows.Forms.RadioButton();
            this.reviewOrderLabel = new System.Windows.Forms.Label();
            this.confirmOrderLabel = new System.Windows.Forms.Label();
            this.extraInfoTextBox = new System.Windows.Forms.TextBox();
            this.extraInfoLabel = new System.Windows.Forms.Label();
            this.civTextBox = new System.Windows.Forms.TextBox();
            this.civLabel = new System.Windows.Forms.Label();
            this.cardNumberTextBox = new System.Windows.Forms.TextBox();
            this.cardNumberLabel = new System.Windows.Forms.Label();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.addressLabel = new System.Windows.Forms.Label();
            this.phoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.paymentMethodLabel = new System.Windows.Forms.Label();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.summaryLabel = new System.Windows.Forms.Label();
            this.orderTextBox = new System.Windows.Forms.TextBox();
            this.cartPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // readyToOrderLabel
            // 
            this.readyToOrderLabel.AutoSize = true;
            this.readyToOrderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.readyToOrderLabel.ForeColor = System.Drawing.Color.White;
            this.readyToOrderLabel.Location = new System.Drawing.Point(285, 28);
            this.readyToOrderLabel.Name = "readyToOrderLabel";
            this.readyToOrderLabel.Size = new System.Drawing.Size(301, 42);
            this.readyToOrderLabel.TabIndex = 0;
            this.readyToOrderLabel.Text = "Ready to order?";
            // 
            // cartPanel
            // 
            this.cartPanel.BackgroundImage = global::RestaurantApplication.Properties.Resources.cartRectangle;
            this.cartPanel.Controls.Add(this.emptyCartLabel);
            this.cartPanel.Controls.Add(this.panel1);
            this.cartPanel.Controls.Add(this.reviewOrderLabel);
            this.cartPanel.Controls.Add(this.confirmOrderLabel);
            this.cartPanel.Controls.Add(this.extraInfoTextBox);
            this.cartPanel.Controls.Add(this.extraInfoLabel);
            this.cartPanel.Controls.Add(this.civTextBox);
            this.cartPanel.Controls.Add(this.civLabel);
            this.cartPanel.Controls.Add(this.cardNumberTextBox);
            this.cartPanel.Controls.Add(this.cardNumberLabel);
            this.cartPanel.Controls.Add(this.addressTextBox);
            this.cartPanel.Controls.Add(this.addressLabel);
            this.cartPanel.Controls.Add(this.phoneNumberTextBox);
            this.cartPanel.Controls.Add(this.paymentMethodLabel);
            this.cartPanel.Controls.Add(this.phoneNumberLabel);
            this.cartPanel.Controls.Add(this.summaryLabel);
            this.cartPanel.Controls.Add(this.orderTextBox);
            this.cartPanel.Location = new System.Drawing.Point(0, 96);
            this.cartPanel.Name = "cartPanel";
            this.cartPanel.Size = new System.Drawing.Size(899, 476);
            this.cartPanel.TabIndex = 0;
            this.cartPanel.MouseEnter += new System.EventHandler(this.CartPanel_MouseEnter);
            // 
            // emptyCartLabel
            // 
            this.emptyCartLabel.BackColor = System.Drawing.Color.Transparent;
            this.emptyCartLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.emptyCartLabel.Image = ((System.Drawing.Image)(resources.GetObject("emptyCartLabel.Image")));
            this.emptyCartLabel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.emptyCartLabel.Location = new System.Drawing.Point(594, 384);
            this.emptyCartLabel.Name = "emptyCartLabel";
            this.emptyCartLabel.Size = new System.Drawing.Size(120, 25);
            this.emptyCartLabel.TabIndex = 17;
            this.emptyCartLabel.Click += new System.EventHandler(this.EmptyCartLabel_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.deliveryRButton);
            this.panel1.Controls.Add(this.pickupRButton);
            this.panel1.Location = new System.Drawing.Point(124, 370);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(354, 100);
            this.panel1.TabIndex = 16;
            // 
            // deliveryRButton
            // 
            this.deliveryRButton.AutoSize = true;
            this.deliveryRButton.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.deliveryRButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deliveryRButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deliveryRButton.Location = new System.Drawing.Point(16, 31);
            this.deliveryRButton.Name = "deliveryRButton";
            this.deliveryRButton.Size = new System.Drawing.Size(100, 29);
            this.deliveryRButton.TabIndex = 1;
            this.deliveryRButton.Text = "Delivery";
            this.deliveryRButton.UseVisualStyleBackColor = true;
            this.deliveryRButton.CheckedChanged += new System.EventHandler(this.DeliveryRButton_CheckedChanged);
            // 
            // pickupRButton
            // 
            this.pickupRButton.Checked = true;
            this.pickupRButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pickupRButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickupRButton.Location = new System.Drawing.Point(179, 31);
            this.pickupRButton.Name = "pickupRButton";
            this.pickupRButton.Size = new System.Drawing.Size(162, 29);
            this.pickupRButton.TabIndex = 0;
            this.pickupRButton.TabStop = true;
            this.pickupRButton.Text = "Pickup";
            this.pickupRButton.UseVisualStyleBackColor = true;
            this.pickupRButton.CheckedChanged += new System.EventHandler(this.PickupRButton_CheckedChanged);
            // 
            // reviewOrderLabel
            // 
            this.reviewOrderLabel.BackColor = System.Drawing.Color.Transparent;
            this.reviewOrderLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.reviewOrderLabel.Image = global::RestaurantApplication.Properties.Resources.ReivewSummary;
            this.reviewOrderLabel.Location = new System.Drawing.Point(727, 381);
            this.reviewOrderLabel.Name = "reviewOrderLabel";
            this.reviewOrderLabel.Size = new System.Drawing.Size(116, 30);
            this.reviewOrderLabel.TabIndex = 15;
            this.reviewOrderLabel.Click += new System.EventHandler(this.ReviewOrderLabel_Click);
            // 
            // confirmOrderLabel
            // 
            this.confirmOrderLabel.BackColor = System.Drawing.Color.Transparent;
            this.confirmOrderLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.confirmOrderLabel.Image = global::RestaurantApplication.Properties.Resources.OrderConfirm;
            this.confirmOrderLabel.Location = new System.Drawing.Point(590, 412);
            this.confirmOrderLabel.Name = "confirmOrderLabel";
            this.confirmOrderLabel.Size = new System.Drawing.Size(262, 53);
            this.confirmOrderLabel.TabIndex = 14;
            this.confirmOrderLabel.Click += new System.EventHandler(this.ConfirmOrderLabel_Click);
            // 
            // extraInfoTextBox
            // 
            this.extraInfoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extraInfoTextBox.Location = new System.Drawing.Point(139, 258);
            this.extraInfoTextBox.Multiline = true;
            this.extraInfoTextBox.Name = "extraInfoTextBox";
            this.extraInfoTextBox.Size = new System.Drawing.Size(253, 106);
            this.extraInfoTextBox.TabIndex = 13;
            // 
            // extraInfoLabel
            // 
            this.extraInfoLabel.AutoSize = true;
            this.extraInfoLabel.BackColor = System.Drawing.Color.Transparent;
            this.extraInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extraInfoLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.extraInfoLabel.Location = new System.Drawing.Point(136, 239);
            this.extraInfoLabel.Name = "extraInfoLabel";
            this.extraInfoLabel.Size = new System.Drawing.Size(78, 20);
            this.extraInfoLabel.TabIndex = 12;
            this.extraInfoLabel.Text = "Extra Info";
            // 
            // civTextBox
            // 
            this.civTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.civTextBox.Location = new System.Drawing.Point(398, 196);
            this.civTextBox.Multiline = true;
            this.civTextBox.Name = "civTextBox";
            this.civTextBox.Size = new System.Drawing.Size(67, 28);
            this.civTextBox.TabIndex = 11;
            // 
            // civLabel
            // 
            this.civLabel.AutoSize = true;
            this.civLabel.BackColor = System.Drawing.Color.Transparent;
            this.civLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.civLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.civLabel.Location = new System.Drawing.Point(413, 178);
            this.civLabel.Name = "civLabel";
            this.civLabel.Size = new System.Drawing.Size(42, 20);
            this.civLabel.TabIndex = 10;
            this.civLabel.Text = "CVV";
            // 
            // cardNumberTextBox
            // 
            this.cardNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardNumberTextBox.Location = new System.Drawing.Point(140, 196);
            this.cardNumberTextBox.Multiline = true;
            this.cardNumberTextBox.Name = "cardNumberTextBox";
            this.cardNumberTextBox.Size = new System.Drawing.Size(252, 28);
            this.cardNumberTextBox.TabIndex = 9;
            // 
            // cardNumberLabel
            // 
            this.cardNumberLabel.AutoSize = true;
            this.cardNumberLabel.BackColor = System.Drawing.Color.Transparent;
            this.cardNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardNumberLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.cardNumberLabel.Location = new System.Drawing.Point(136, 178);
            this.cardNumberLabel.Name = "cardNumberLabel";
            this.cardNumberLabel.Size = new System.Drawing.Size(103, 20);
            this.cardNumberLabel.TabIndex = 8;
            this.cardNumberLabel.Text = "Card Number";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Enabled = false;
            this.addressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressTextBox.Location = new System.Drawing.Point(140, 135);
            this.addressTextBox.Multiline = true;
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(252, 28);
            this.addressTextBox.TabIndex = 7;
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.BackColor = System.Drawing.Color.Transparent;
            this.addressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.addressLabel.Location = new System.Drawing.Point(136, 117);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(68, 20);
            this.addressLabel.TabIndex = 6;
            this.addressLabel.Text = "Address";
            // 
            // phoneNumberTextBox
            // 
            this.phoneNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumberTextBox.Location = new System.Drawing.Point(140, 75);
            this.phoneNumberTextBox.Multiline = true;
            this.phoneNumberTextBox.Name = "phoneNumberTextBox";
            this.phoneNumberTextBox.Size = new System.Drawing.Size(252, 28);
            this.phoneNumberTextBox.TabIndex = 5;
            // 
            // paymentMethodLabel
            // 
            this.paymentMethodLabel.AutoSize = true;
            this.paymentMethodLabel.BackColor = System.Drawing.Color.Transparent;
            this.paymentMethodLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.paymentMethodLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.paymentMethodLabel.Location = new System.Drawing.Point(51, 3);
            this.paymentMethodLabel.Name = "paymentMethodLabel";
            this.paymentMethodLabel.Size = new System.Drawing.Size(442, 51);
            this.paymentMethodLabel.TabIndex = 4;
            this.paymentMethodLabel.Text = "PAYMENT METHOD";
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.BackColor = System.Drawing.Color.Transparent;
            this.phoneNumberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNumberLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.phoneNumberLabel.Location = new System.Drawing.Point(136, 57);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(115, 20);
            this.phoneNumberLabel.TabIndex = 3;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // summaryLabel
            // 
            this.summaryLabel.AutoSize = true;
            this.summaryLabel.BackColor = System.Drawing.Color.Transparent;
            this.summaryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.summaryLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(63)))), ((int)(((byte)(63)))));
            this.summaryLabel.Location = new System.Drawing.Point(599, 15);
            this.summaryLabel.Name = "summaryLabel";
            this.summaryLabel.Size = new System.Drawing.Size(239, 29);
            this.summaryLabel.TabIndex = 1;
            this.summaryLabel.Text = "ORDER SUMMARY";
            // 
            // orderTextBox
            // 
            this.orderTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.orderTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.orderTextBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.orderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderTextBox.Location = new System.Drawing.Point(585, 59);
            this.orderTextBox.Multiline = true;
            this.orderTextBox.Name = "orderTextBox";
            this.orderTextBox.ReadOnly = true;
            this.orderTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.orderTextBox.Size = new System.Drawing.Size(275, 305);
            this.orderTextBox.TabIndex = 0;
            // 
            // CartUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(53)))), ((int)(((byte)(53)))));
            this.Controls.Add(this.readyToOrderLabel);
            this.Controls.Add(this.cartPanel);
            this.Name = "CartUserControl";
            this.Size = new System.Drawing.Size(899, 572);
            this.MouseEnter += new System.EventHandler(this.CartUserControl_MouseEnter);
            this.cartPanel.ResumeLayout(false);
            this.cartPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel cartPanel;
        private System.Windows.Forms.Label summaryLabel;
        private System.Windows.Forms.TextBox orderTextBox;
        private System.Windows.Forms.Label readyToOrderLabel;
        private System.Windows.Forms.TextBox extraInfoTextBox;
        private System.Windows.Forms.Label extraInfoLabel;
        private System.Windows.Forms.TextBox civTextBox;
        private System.Windows.Forms.Label civLabel;
        private System.Windows.Forms.TextBox cardNumberTextBox;
        private System.Windows.Forms.Label cardNumberLabel;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.TextBox phoneNumberTextBox;
        private System.Windows.Forms.Label paymentMethodLabel;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.Label confirmOrderLabel;
        private System.Windows.Forms.Label reviewOrderLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton deliveryRButton;
        private System.Windows.Forms.RadioButton pickupRButton;
        private System.Windows.Forms.Label emptyCartLabel;
    }
}
