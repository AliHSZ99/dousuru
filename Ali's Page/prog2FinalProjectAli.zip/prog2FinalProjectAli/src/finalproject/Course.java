package finalproject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * The Course Class.
 *
 * @author Ali Zoubeidi
 */
public class Course implements Serializable {

    // data members
    private String name;
    private int maxStuAmount;
    private Teacher teacher;
    private List<Student> regsStudents;
    private List<Double> finalScores;

    /**
     * Constructor with name and teacher.
     *
     * @param name the input course name
     * @param teacher the input teacher of the course
     */
    public Course(String name, Teacher teacher) {
        this.name = name;
        this.maxStuAmount = 2;
        this.teacher = teacher;
        this.regsStudents = new ArrayList<>();
        this.finalScores = new ArrayList<>();
    }

    /**
     * toString method
     *
     * @return a nice string
     */
    @Override
    public String toString() {
        String str = "";

        str += String.format("%s %s\n", "Course:", name);
        str += String.format("%s %d\n", "Maximum Capacity:", maxStuAmount);
        str += String.format("%s %s\n", "Teacher:", teacher.getName());

        return str;
    }

    // getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxStuAmount() {
        return maxStuAmount;
    }

    public void setMaxStuAmount(int maxStuAmount) {
        this.maxStuAmount = maxStuAmount;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public List<Student> getRegsStudents() {
        return regsStudents;
    }

    public void setRegsStudents(List<Student> regsStudents) {
        this.regsStudents = regsStudents;
    }

    public List<Double> getFinalScores() {
        return finalScores;
    }

    public void setFinalScores(List<Double> finalScores) {
        this.finalScores = finalScores;
    }

}
