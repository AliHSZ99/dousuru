package finalproject;

import java.util.ArrayList;
import java.util.List;

/**
 * The Student Class.
 *
 * @author Ali Zoubeidi
 */
public class Student extends User {

    // data member and ID of the next student.
    private List<Course> regsCourses;
    protected static int nextId;

    /**
     * Constructor with name.
     *
     * @param name the input name of a student
     */
    public Student(String name) {
        super(name);
        this.regsCourses = new ArrayList<>();
        generateId();
    }

    /**
     * The generateId method for student. The formatting should be as follows:
     * "S0001", "S0002"...
     */
    @Override
    protected void generateId() {
        super.id = String.format("S%04d", nextId++);
    }

    /**
     * toString method
     *
     * @return a nice string
     */
    @Override
    public String toString() {
        String str = "";
        str += super.toString();
        str += "Registered Courses:\n";
        for (Course regsCourse : regsCourses) {
            str += String.format("\t%s\n", regsCourse.getName());
        }
        return str;
    }

    // getter and setter
    public List<Course> getRegsCourses() {
        return regsCourses;
    }

    public void setRegsCourses(List<Course> regsCourses) {
        this.regsCourses = regsCourses;
    }

}
