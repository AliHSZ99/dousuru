package finalproject;

/**
 * The Admin Class.
 *
 * @author Ali Zoubeidi
 */
public class Admin extends User {

    // the ID of the next admin
    private static int nextId = 1;

    /**
     * Constructor with name.
     *
     * @param name the input name.
     */
    public Admin(String name) {
        super(name);
        generateId();
    }

    /**
     * The generateId method for admin. The formatting should be as follows:
     * "A0001", "A0002"...
     */
    @Override
    protected void generateId() {
        super.id = String.format("A%04d", nextId++);
    }

    /**
     * toString method
     *
     * @return a nice string
     */
    @Override
    public String toString() {
        return super.toString();
    }

}
