package finalproject;

import java.util.ArrayList;
import java.util.List;

/**
 * The Teacher Class.
 *
 * @author Ali Zoubeidi
 */
public class Teacher extends User {

    // data member and the next ID of a teacher
    private List<Course> teachingCourses;
    protected static int nextId;

    /**
     * Constructor with name.
     *
     * @param name the input teacher name
     */
    public Teacher(String name) {
        super(name);
        this.teachingCourses = new ArrayList<>();
        generateId();
    }

    /**
     * The generateId method for teacher. The formatting should be as follows:
     * "T0001", "T0002"...
     */
    @Override
    protected void generateId() {
        super.id = String.format("T%04d", nextId++);
    }

    /**
     * toString method
     *
     * @return a nice string
     */
    @Override
    public String toString() {
        String str = "";
        str += super.toString();
        
        str += "Teaching Courses:\n"; 
        for (Course teachingCourse : teachingCourses) {
            str += String.format("\t%s\n", teachingCourse.getName());       
        }

        return str;
    }

    // getter and setter
    public List<Course> getTeachingCourses() {
        return teachingCourses;
    }

    public void setTeachingCourses(List<Course> teachingCourses) {
        this.teachingCourses = teachingCourses;
    }

}
