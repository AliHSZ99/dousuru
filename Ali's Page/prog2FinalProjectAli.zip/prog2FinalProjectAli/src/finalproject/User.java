package finalproject;

import java.io.Serializable;
import java.util.Objects;

/**
 * The User Class.
 *
 * @author Ali Zoubeidi
 */
public abstract class User implements Serializable {

    // data members
    protected String id;
    protected String name;
    protected String password;

    /**
     * Constructor with name as a parameter
     *
     * @param name the input name of user
     */
    public User(String name) {
        this.name = name;
        this.password = "1234";
    }

    /**
     * Abstract method to generate user ID's
     */
    protected abstract void generateId();

    /**
     * hash code with ID.
     *
     * @return hash
     */
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.id);
        return hash;
    }

    /**
     * equals method with ID.
     *
     * @param obj the input object
     * @return true if the ID's are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final User other = (User) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    /**
     * the toString method
     *
     * @return a nice string
     */
    @Override
    public String toString() {
        String str = "";

        str += String.format("%s %s\n", "ID:", id);
        str += String.format("%s %s\n", "Name:", name);

        return str;
    }

    // getters and setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
